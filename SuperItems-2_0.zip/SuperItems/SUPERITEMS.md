# SuperItems 2.0

Make custom **items, armor, armor sets, enemies, minibosses, bosses, loot pools and spawners** in game. Everything uses the same command style as SuperItems 1.x: an id, then `--flags`. Commands are typed on one line. Examples below are wrapped only to be readable. Everything after a flag, up to the next flag, is its value, so values can hold spaces and whole commands. A flag can be repeated.

Permission: `superitems.admin` (operators by default). Aliases: `/sitems`, `/si`.
Type a group name alone (`/superitems mob`) to see its commands.

## Command map

| Group | Commands |
| --- | --- |
| *(items, same as 1.x)* | `create` `edit` `delete` `give` `list` `info` `reload` |
| `armor` | `create` `edit` `delete` `give` `list` `info` |
| `set` | `create` `edit` `delete` `list` `info` |
| `mob` | `create` `edit` `delete` `list` `info` `spawn` `kill` `active` |
| `loot` | `create` `edit` `delete` `list` `info` `roll` `drop` `test` |
| `spawner` | `create` `edit` `delete` `list` `info` |

Use `none` as a value on `edit` to clear a flag (`--on_hit none`). Text supports `&` color codes or MiniMessage tags like `<green>`. On `create`/`edit`, a wrong flag changes nothing.

Create things in dependency order: items/armor, then sets and loot tables, then mobs, then spawners. Commands check that referenced ids exist.

## Items (everything from 1.x, plus more)

All 1.x flags still work: `--name --description --material --model --glow --on_right_click --on_left_click --consume --cooldown --cancel`.

New item flags:

| Flag | Meaning |
| --- | --- |
| `--damage min-max` | Melee hits with the item deal a random amount in that range. Scaled by attack charge, so spam clicking does not deal full damage. |
| `--attribute "name amount [add\|mult\|mult_total] [slot]"` | Attribute bonus. Repeatable. Slot defaults to the slot the material is worn in, or the main hand. Giving any attribute replaces the base item's default attributes, so state every stat you want. |
| `--unbreakable` | Cannot lose durability |
| `--color #rrggbb` | Dye for leather armor |
| `--on_hit <cmd>` | Runs when the holder or wearer hits something. `%target%` is the victim's UUID, `%targetname%` its name |
| `--on_damaged <cmd>` | Runs when the holder or wearer takes entity damage. `%attacker%` is the damager's UUID |
| `--on_equip <cmd>` / `--on_unequip <cmd>` | Runs when the item becomes worn or held, or stops |
| `--while_worn <cmd>` and `--interval s` | Repeats while worn or held (default every 2 s) |
| `--trigger_cooldown s` | Cooldown shared by `on_hit` and `on_damaged` |

"Worn or held" means an armor slot, the main hand, or the off hand.

## Armor

`/superitems armor create` is the same data as items, limited to wearable materials, with shortcuts:

```
/superitems armor create crown --piece helmet --tier netherite --name &6King's Crown --armor 4 --toughness 3 --health 6 --unbreakable
```

`--piece helmet|chestplate|leggings|boots` with `--tier leather|chainmail|iron|golden|diamond|netherite` picks the material (or give `--material`). Stat shortcuts: `--armor --toughness --health --speed --knockback_resistance` (each adds that amount). For percentages use `--attribute "speed 0.15 mult"`. Armor is stored in `items.yml`; `/superitems give` also works on it.

### Sets

```
/superitems set create kings --pieces crown,plate,greaves,sabatons --name &6King's Regalia --description &7Wear the full set.
  --bonus 2 effect give @s minecraft:resistance 3 0 true --bonus 4 effect give @s minecraft:strength 3 1 true
  --on_activate 4 title @s title "Full set!" --on_deactivate 4 title @s title "Set broken"
```

* `--pieces` item ids (comma separated). Only armor-slot pieces count.
* `--bonus "<n> <command>"` repeats every `--interval` seconds (default 2) while at least *n* pieces are worn. Effects should last a little longer than the interval.
* `--on_activate` / `--on_deactivate` run once when the wearer reaches or drops below *n* pieces.
* `--description` lines are added to the lore of every piece the next time it is given.

## Mobs

Tiers: `enemy`, `miniboss`, `boss`. The tier only sets defaults: minibosses and bosses do not despawn, and bosses get a boss bar. Every default can be overridden.

```
/superitems mob create skeleton_king --tier boss --type wither_skeleton --name &4&lSkeleton King
  --health 800 --damage 14 --speed 1.2x --armor 10 --toughness 4 --kb_resist 0.8 --scale 1.5
  --mainhand blade --helmet crown --effect resistance 1 infinite
  --timer 12 summon minecraft:skeleton ~ ~ ~
  --phase 50 effect give @s minecraft:speed infinite 2 true
  --phase 50 title @a[distance=..40] title "ENRAGED"
  --on_hit effect give %target% minecraft:slowness 3 1
  --loot king_loot --xp 300-500 --vanilla_drops false
  --spawn_message &4The Skeleton King rises at %x% %y% %z%! --death_message &aThe Skeleton King was slain by %killer%! --announce server
  --bar_color purple --bar_style 10
```

| Group | Flags |
| --- | --- |
| Identity | `--tier --type --name --size` (slime size) `--baby --glow --silent --invulnerable --invisible --ai --gravity --persistent --name_visible` |
| Stats | `--health --damage --speed --armor --toughness --knockback_resistance --follow_range --scale`, or any attribute with `--attribute "name value"`. Speed (or any value) may end in `x` to multiply the vanilla value, e.g. `1.5x` |
| Gear | `--mainhand --offhand --helmet --chestplate --leggings --boots` (a SuperItems item/armor id or a vanilla material), `--equipment_drop percent` (default 0) |
| Spawn | `--effect "name [amplifier] [seconds\|infinite]"`, `--rider <mobId>` (another mob rides this one), `--on_spawn` |
| Combat | `--on_hit` (mob hits something), `--on_damaged`, `--on_death`, `--on_kill`, `--trigger_cooldown s` |
| Abilities | `--timer "seconds command"` (repeats while a player is within `--active_range`, default 64; 0 = always), `--phase "percent command"` (once, when health falls to that percent) |
| Boss bar | `--bossbar --bar_color pink\|blue\|red\|green\|yellow\|purple\|white --bar_style progress\|6\|10\|12\|20 --bar_range blocks --bar_title text` |
| Drops | `--loot <table>` (repeatable), `--xp min-max`, `--vanilla_drops true\|false` |
| Messages | `--spawn_message --death_message` with `--announce world\|server\|none` |
| Natural spawns | `--replace <entityType> <percent>` swaps that percent of natural spawns for this mob; `--worlds a,b` limits it |

### How mob commands run

* A plain line runs **as the mob, at the mob**, so `@s` is the mob and `~ ~ ~` is its position.
* `target:<cmd>` runs as the nearby player involved (the one hit, hitting, or nearest). `player:<cmd>` runs with that player's permissions. `raw:<cmd>` runs from the console exactly as written.
* Placeholders: `%mob%` (UUID, works as a selector), `%mobid%`, `%x% %y% %z%`, `%world%`, `%player%`, `%target%` and `%targetname%` (the other party), `%killer%` (death messages and `on_death`).
* `on_death` runs from the console at the place of death, because the mob is gone.

Mobs are tagged in their NBT, so they survive restarts. Edits to behavior (commands, timers, phases, loot, boss bar) apply to live mobs; name, gear and stats apply to newly spawned mobs.

Other mob commands: `spawn <id> [amount] [world x y z]`, `kill [id]` (removes without drops), `active` (counts live mobs).

## Loot tables (pools)

```
/superitems loot create king_loot --rolls 1-2 --chance 100 --deliver drop
  --entry 50 vanilla:bone 5-12
  --entry 10 item:blade
  --entry 5 item:crown chance=50
  --entry 3 command:give %player% minecraft:golden_apple 2
  --entry 1 table:rare_gems
  --entry 30 nothing
  --always 1 vanilla:experience_bottle 3-6
```

An entry is `weight kind:ref [amount] [chance=percent]`. Kinds: `item:<id>` (SuperItems item or armor), `vanilla:<material>`, `table:<id>` (roll another table, so pools nest), `command:<text>` (`%player%`, `%amount%` available), `nothing`. Each of `--rolls` picks one weighted entry; `--always` entries are rolled once every time using only their own chance. `--chance` is the chance the whole table gives anything. `--deliver inventory` puts mob loot straight into the killer's inventory.

On `loot edit`, `--entry` and `--always` **add** to the existing lines. Use `--entry none --entry ...` to replace them.

* `loot roll <table> [player] [times]` gives the result to a player.
* `loot drop <table> [world x y z]` drops it in the world.
* `loot test <table> [times]` simulates rolls and prints totals and drop rates, giving nothing, so you can tune weights.

## Spawner points

```
/superitems spawner create crypt --mob skeleton_king --here --interval 600 --max 1 --range 48
```

Flags: `--mob`, `--here` or `--location x y z [world]`, `--interval` (seconds between waves, default 30), `--amount` (per wave, default 1), `--max` (alive at once from this spawner, default 3), `--radius` (scatter, default 3), `--range` (only works while a player is this close, default 32; 0 = always), `--enabled`.

## Files

`plugins/SuperItems/`: `items.yml` (items and armor), `sets.yml`, `mobs.yml`, `loot.yml`, `spawners.yml`, `config.yml`. Edit by hand, then `/superitems reload`.

`config.yml`: `default-material`, `cooldown-message`, `damage-indicators` and `damage-indicator-format` (floating damage numbers on custom mobs and on hits with `--damage` items), `natural-replacement`.

## Code layout

Each subcommand is its own class in `dev.superitems.command`. Items, armor, sets, mobs, loot tables and spawners each implement `Kind<T>`; the shared `CreateSubcommand`, `EditSubcommand`, `DeleteSubcommand`, `InfoSubcommand` and `ListSubcommand` work for all of them. To add a new kind of thing, implement `Kind<T>`, add a `FlagSpec` in `Specs`, and register a `GroupSubcommand` in `SuperItems.onEnable`.

* `mob`: `MobManager` (spawn, track, timers, phases, boss bars), `MobListener` (death, loot, natural replacement)
* `loot`: `LootEntry` (line parser), `LootRoller`
* `listener`: `ItemUseListener` (clicks), `CombatListener` (damage ranges, hit triggers, damage numbers), `WearTracker` (equip, while worn, sets)
* `action.ActionRunner` runs every command line for players and mobs
