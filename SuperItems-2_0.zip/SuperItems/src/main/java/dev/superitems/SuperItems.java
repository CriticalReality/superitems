package dev.superitems;

import dev.superitems.action.ActionRunner;
import dev.superitems.action.CooldownTracker;
import dev.superitems.command.ArmorKind;
import dev.superitems.command.CreateSubcommand;
import dev.superitems.command.DeleteSubcommand;
import dev.superitems.command.EditSubcommand;
import dev.superitems.command.GiveSubcommand;
import dev.superitems.command.GroupSubcommand;
import dev.superitems.command.InfoSubcommand;
import dev.superitems.command.ItemKind;
import dev.superitems.command.ListSubcommand;
import dev.superitems.command.LootDropSubcommand;
import dev.superitems.command.LootKind;
import dev.superitems.command.LootRollSubcommand;
import dev.superitems.command.LootTestSubcommand;
import dev.superitems.command.MobActiveSubcommand;
import dev.superitems.command.MobKillSubcommand;
import dev.superitems.command.MobKind;
import dev.superitems.command.MobSpawnSubcommand;
import dev.superitems.command.ReloadSubcommand;
import dev.superitems.command.SetKind;
import dev.superitems.command.SpawnerKind;
import dev.superitems.command.Subcommand;
import dev.superitems.command.SuperItemsCommand;
import dev.superitems.item.ItemFactory;
import dev.superitems.item.ItemStore;
import dev.superitems.item.SetStore;
import dev.superitems.listener.CombatListener;
import dev.superitems.listener.ItemUseListener;
import dev.superitems.listener.MobListener;
import dev.superitems.listener.WearTracker;
import dev.superitems.loot.LootRoller;
import dev.superitems.loot.LootStore;
import dev.superitems.mob.MobManager;
import dev.superitems.mob.MobStore;
import dev.superitems.spawner.SpawnerStore;
import dev.superitems.spawner.SpawnerTask;
import dev.superitems.store.YamlStore;
import dev.superitems.util.Text;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.logging.Level;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

/** Custom items, armor, armor sets, enemies, minibosses, bosses, loot pools and spawners, all made in game. */
public class SuperItems extends JavaPlugin {
    private ItemStore items;
    private SetStore sets;
    private MobStore mobs;
    private LootStore loot;
    private SpawnerStore spawners;
    private ItemFactory factory;
    private ActionRunner runner;
    private CooldownTracker cooldowns;
    private MobManager manager;
    private LootRoller roller;
    private WearTracker wear;
    private SpawnerTask spawnerTask;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        items = new ItemStore(new File(getDataFolder(), "items.yml"), getLogger());
        sets = new SetStore(new File(getDataFolder(), "sets.yml"), getLogger());
        mobs = new MobStore(new File(getDataFolder(), "mobs.yml"), getLogger());
        loot = new LootStore(new File(getDataFolder(), "loot.yml"), getLogger());
        spawners = new SpawnerStore(new File(getDataFolder(), "spawners.yml"), getLogger());
        items.load();
        sets.load();
        mobs.load();
        loot.load();
        spawners.load();
        factory = new ItemFactory(this);
        runner = new ActionRunner(getLogger());
        cooldowns = new CooldownTracker();
        manager = new MobManager(this);
        roller = new LootRoller(this);
        wear = new WearTracker(this);
        spawnerTask = new SpawnerTask(this);

        getServer().getPluginManager().registerEvents(new ItemUseListener(this), this);
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new MobListener(this), this);

        ItemKind itemKind = new ItemKind(this);
        ArmorKind armorKind = new ArmorKind(this);
        SetKind setKind = new SetKind(this);
        MobKind mobKind = new MobKind(this);
        LootKind lootKind = new LootKind(this);
        SpawnerKind spawnerKind = new SpawnerKind(this);

        SuperItemsCommand command = new SuperItemsCommand(List.<Subcommand>of(
                new CreateSubcommand<>(itemKind),
                new EditSubcommand<>(itemKind),
                new DeleteSubcommand<>(itemKind),
                new GiveSubcommand(this),
                new ListSubcommand<>(itemKind),
                new InfoSubcommand<>(itemKind),
                new ReloadSubcommand(this),
                new GroupSubcommand("armor", "Armor pieces with stats and triggers", List.of(
                        new CreateSubcommand<>(armorKind),
                        new EditSubcommand<>(armorKind),
                        new DeleteSubcommand<>(armorKind),
                        new GiveSubcommand(this, "/superitems armor", definition -> dev.superitems.item.Armor.isWearable(definition.getMaterial())),
                        new ListSubcommand<>(armorKind),
                        new InfoSubcommand<>(armorKind))),
                new GroupSubcommand("set", "Armor sets with bonuses for wearing several pieces", List.of(
                        new CreateSubcommand<>(setKind),
                        new EditSubcommand<>(setKind),
                        new DeleteSubcommand<>(setKind),
                        new ListSubcommand<>(setKind),
                        new InfoSubcommand<>(setKind))),
                new GroupSubcommand("mob", "Enemies, minibosses and bosses", List.of(
                        new CreateSubcommand<>(mobKind),
                        new EditSubcommand<>(mobKind),
                        new DeleteSubcommand<>(mobKind),
                        new ListSubcommand<>(mobKind),
                        new InfoSubcommand<>(mobKind),
                        new MobSpawnSubcommand(this),
                        new MobKillSubcommand(this),
                        new MobActiveSubcommand(this))),
                new GroupSubcommand("loot", "Loot tables (loot pools)", List.of(
                        new CreateSubcommand<>(lootKind),
                        new EditSubcommand<>(lootKind),
                        new DeleteSubcommand<>(lootKind),
                        new ListSubcommand<>(lootKind),
                        new InfoSubcommand<>(lootKind),
                        new LootRollSubcommand(this),
                        new LootDropSubcommand(this),
                        new LootTestSubcommand(this))),
                new GroupSubcommand("spawner", "Spawner points that keep spawning a mob", List.of(
                        new CreateSubcommand<>(spawnerKind),
                        new EditSubcommand<>(spawnerKind),
                        new DeleteSubcommand<>(spawnerKind),
                        new ListSubcommand<>(spawnerKind),
                        new InfoSubcommand<>(spawnerKind)))));
        PluginCommand pluginCommand = Objects.requireNonNull(getCommand("superitems"));
        pluginCommand.setExecutor(command);
        pluginCommand.setTabCompleter(command);

        // One half-second heartbeat drives timers, phases, boss bars, spawner points and worn-item triggers.
        getServer().getScheduler().runTaskTimer(this, this::heartbeat, 20L, 10L);
        manager.scanLoaded();
        getLogger().info("Loaded " + items.ids().size() + " item(s), " + sets.ids().size() + " set(s), " + mobs.ids().size()
                + " mob(s), " + loot.ids().size() + " loot table(s), " + spawners.ids().size() + " spawner(s).");
    }

    @Override
    public void onDisable() {
        if (manager != null) {
            manager.shutdown();
        }
    }

    private void heartbeat() {
        try {
            manager.tick();
            spawnerTask.tick();
            wear.tick();
        } catch (RuntimeException e) {
            getLogger().log(Level.SEVERE, "SuperItems heartbeat failed", e);
        }
    }

    /** The item and armor definitions. */
    public ItemStore items() {
        return items;
    }

    /** The armor set definitions. */
    public SetStore sets() {
        return sets;
    }

    /** The mob definitions. */
    public MobStore mobs() {
        return mobs;
    }

    /** The loot tables. */
    public LootStore loot() {
        return loot;
    }

    /** The spawner points. */
    public SpawnerStore spawners() {
        return spawners;
    }

    /** Builds and recognizes item stacks. */
    public ItemFactory factory() {
        return factory;
    }

    /** Runs commands for items, mobs and loot. */
    public ActionRunner runner() {
        return runner;
    }

    /** Per player item cooldowns. */
    public CooldownTracker cooldowns() {
        return cooldowns;
    }

    /** Spawns and tracks custom mobs. */
    public MobManager manager() {
        return manager;
    }

    /** Rolls loot tables. */
    public LootRoller roller() {
        return roller;
    }

    /** Watches worn and held items. */
    public WearTracker wear() {
        return wear;
    }

    /** Runs spawner points. */
    public SpawnerTask spawnerTask() {
        return spawnerTask;
    }

    /** Reloads config.yml and every data file from disk. */
    public void reloadAll() {
        reloadConfig();
        items.load();
        sets.load();
        mobs.load();
        loot.load();
        spawners.load();
        manager.rebind();
        manager.scanLoaded();
        wear.reset();
        spawnerTask.reset();
    }

    /** Material used by create when no material flag is given. */
    public Material defaultMaterial() {
        Material material = Material.matchMaterial(getConfig().getString("default-material", "STICK"));
        return material != null && material.isItem() && !material.isAir() ? material : Material.STICK;
    }

    /** Saves items.yml and tells the sender when it fails. */
    public boolean saveItems(CommandSender sender) {
        return save(items, "items.yml", sender);
    }

    /** Saves sets.yml and tells the sender when it fails. */
    public boolean saveSets(CommandSender sender) {
        return save(sets, "sets.yml", sender);
    }

    /** Saves mobs.yml and tells the sender when it fails. */
    public boolean saveMobs(CommandSender sender) {
        return save(mobs, "mobs.yml", sender);
    }

    /** Saves loot.yml and tells the sender when it fails. */
    public boolean saveLoot(CommandSender sender) {
        return save(loot, "loot.yml", sender);
    }

    /** Saves spawners.yml and tells the sender when it fails. */
    public boolean saveSpawners(CommandSender sender) {
        return save(spawners, "spawners.yml", sender);
    }

    private boolean save(YamlStore<?> store, String fileName, CommandSender sender) {
        try {
            store.save();
            return true;
        } catch (IOException e) {
            getLogger().log(Level.SEVERE, "Could not save " + fileName, e);
            Text.error(sender, "Could not save " + fileName + " (see console). The change works until the next restart.");
            return false;
        }
    }
}
