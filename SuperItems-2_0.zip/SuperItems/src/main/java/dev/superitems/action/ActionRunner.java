package dev.superitems.action;

import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

/**
 * Runs command lines for items, armor, sets, mobs and loot.
 *
 * <p>For a player (items, armor, loot): a plain line runs from the console as the player, standing where they
 * stand, so selectors like @p, @s and relative coordinates work. {@code player:} runs as the player with their own
 * permissions. {@code raw:} runs from the console exactly as written.
 *
 * <p>For a mob: a plain line runs as the mob, at the mob, so @s is the mob. {@code target:} runs as the nearby
 * player involved. {@code player:} runs with that player's permissions. {@code raw:} runs from the console.
 *
 * <p>In every form %player% is the player's name. Extra placeholders such as %mob% (the mob's UUID, usable as a
 * selector) and %target% come from the variables passed in.
 */
public final class ActionRunner {
    /** Sends one command line to the server. Replaceable so tests can record commands. */
    public interface Dispatcher {
        /** Runs the command and returns whether the server accepted it. */
        boolean dispatch(CommandSender sender, String command);
    }

    private static final String PLAYER_PREFIX = "player:";
    private static final String RAW_PREFIX = "raw:";
    private static final String TARGET_PREFIX = "target:";

    private final Logger logger;
    private Dispatcher dispatcher = Bukkit::dispatchCommand;

    /** Creates a runner that logs failures to the given logger. */
    public ActionRunner(Logger logger) {
        this.logger = logger;
    }

    /** Swaps how commands reach the server. */
    public void setDispatcher(Dispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    /** Runs every command line for the given player. */
    public void run(Player player, List<String> commands) {
        run(player, commands, Map.of());
    }

    /** Runs every command line for the given player with extra placeholders. */
    public void run(Player player, List<String> commands, Map<String, String> vars) {
        for (String command : commands) {
            runForPlayer(player, command, vars);
        }
    }

    /** Runs lines as a mob (or other entity). The player may be null when nobody is involved. */
    public void runAsEntity(Entity self, Player player, List<String> commands, Map<String, String> vars) {
        for (String command : commands) {
            runForEntity(self, player, command, vars);
        }
    }

    /** Runs lines from the console at a fixed place. Used when the entity is already gone (on death). */
    public void runAtLocation(Location at, Player player, List<String> commands, Map<String, String> vars) {
        for (String command : commands) {
            String text = command.strip();
            try {
                if (hasPrefix(text, RAW_PREFIX)) {
                    dispatcher.dispatch(Bukkit.getConsoleSender(), fill(text.substring(RAW_PREFIX.length()), player, vars));
                } else if (hasPrefix(text, PLAYER_PREFIX) && player != null) {
                    dispatcher.dispatch(player, fill(text.substring(PLAYER_PREFIX.length()), player, vars));
                } else if (hasPrefix(text, TARGET_PREFIX) && player != null) {
                    String name = player.getName();
                    dispatcher.dispatch(Bukkit.getConsoleSender(),
                            "execute as " + name + " at " + name + " run " + fill(text.substring(TARGET_PREFIX.length()), player, vars));
                } else {
                    dispatcher.dispatch(Bukkit.getConsoleSender(), "execute in " + at.getWorld().getKey().asString()
                            + " positioned " + at.getX() + " " + at.getY() + " " + at.getZ() + " run " + fill(text, player, vars));
                }
            } catch (RuntimeException e) {
                logger.log(Level.WARNING, "Command failed: " + command, e);
            }
        }
    }

    /** Runs lines from the console exactly as written, with placeholders filled in. */
    public void runRaw(List<String> commands, Map<String, String> vars) {
        for (String command : commands) {
            String text = command.strip();
            if (hasPrefix(text, RAW_PREFIX)) {
                text = text.substring(RAW_PREFIX.length());
            }
            try {
                dispatcher.dispatch(Bukkit.getConsoleSender(), fill(text, null, vars));
            } catch (RuntimeException e) {
                logger.log(Level.WARNING, "Command failed: " + command, e);
            }
        }
    }

    private void runForPlayer(Player player, String command, Map<String, String> vars) {
        String text = command.strip();
        try {
            if (hasPrefix(text, PLAYER_PREFIX)) {
                dispatcher.dispatch(player, fill(text.substring(PLAYER_PREFIX.length()), player, vars));
            } else if (hasPrefix(text, RAW_PREFIX)) {
                dispatcher.dispatch(Bukkit.getConsoleSender(), fill(text.substring(RAW_PREFIX.length()), player, vars));
            } else {
                String name = player.getName();
                dispatcher.dispatch(Bukkit.getConsoleSender(),
                        "execute as " + name + " at " + name + " run " + fill(text, player, vars));
            }
        } catch (RuntimeException e) {
            logger.log(Level.WARNING, "Item command failed: " + command, e);
        }
    }

    private void runForEntity(Entity self, Player player, String command, Map<String, String> vars) {
        String text = command.strip();
        try {
            if (hasPrefix(text, RAW_PREFIX)) {
                dispatcher.dispatch(Bukkit.getConsoleSender(), fill(text.substring(RAW_PREFIX.length()), player, vars));
            } else if (hasPrefix(text, PLAYER_PREFIX)) {
                if (player != null) {
                    dispatcher.dispatch(player, fill(text.substring(PLAYER_PREFIX.length()), player, vars));
                }
            } else if (hasPrefix(text, TARGET_PREFIX)) {
                if (player != null) {
                    String name = player.getName();
                    dispatcher.dispatch(Bukkit.getConsoleSender(),
                            "execute as " + name + " at " + name + " run " + fill(text.substring(TARGET_PREFIX.length()), player, vars));
                }
            } else {
                String id = self.getUniqueId().toString();
                dispatcher.dispatch(Bukkit.getConsoleSender(), "execute as " + id + " at " + id + " run " + fill(text, player, vars));
            }
        } catch (RuntimeException e) {
            logger.log(Level.WARNING, "Mob command failed: " + command, e);
        }
    }

    private static boolean hasPrefix(String text, String prefix) {
        return text.regionMatches(true, 0, prefix, 0, prefix.length());
    }

    private static String fill(String command, Player player, Map<String, String> vars) {
        String text = command.strip();
        if (text.startsWith("/")) {
            text = text.substring(1);
        }
        for (Map.Entry<String, String> entry : vars.entrySet()) {
            text = text.replace("%" + entry.getKey() + "%", entry.getValue());
        }
        if (player != null) {
            text = text.replace("%player%", player.getName());
        }
        return text;
    }
}
