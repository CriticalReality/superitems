package dev.superitems.action;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Tracks per player, per item cooldowns. Only used from the server thread. */
public final class CooldownTracker {
    private final Map<String, Long> readyAt = new HashMap<>();

    /** Starts the cooldown and returns 0 when the item is ready, otherwise returns the milliseconds left. */
    public long tryUse(UUID player, String itemId, double seconds) {
        if (seconds <= 0) {
            return 0;
        }
        String key = player + ":" + itemId;
        long now = System.currentTimeMillis();
        Long ready = readyAt.get(key);
        if (ready != null && ready > now) {
            return ready - now;
        }
        readyAt.put(key, now + (long) (seconds * 1000));
        return 0;
    }

    /** Forgets every cooldown of a player. */
    public void clear(UUID player) {
        String prefix = player + ":";
        readyAt.keySet().removeIf(key -> key.startsWith(prefix));
    }
}
