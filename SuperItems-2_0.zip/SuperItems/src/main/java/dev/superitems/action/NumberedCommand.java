package dev.superitems.action;

/** A command line that starts with a number, such as "5 say hi" (every 5 seconds) or "50 say half health" (at 50 percent). */
public record NumberedCommand(double number, String command) {
    /** Parses text shaped like {@code "<number> <command>"}. Returns null when the number or command is missing. */
    public static NumberedCommand parse(String text) {
        if (text == null) {
            return null;
        }
        String value = text.strip();
        int space = value.indexOf(' ');
        if (space < 1) {
            return null;
        }
        try {
            double number = Double.parseDouble(value.substring(0, space));
            String command = value.substring(space + 1).strip();
            if (!Double.isFinite(number) || command.isEmpty()) {
                return null;
            }
            return new NumberedCommand(number, command);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
