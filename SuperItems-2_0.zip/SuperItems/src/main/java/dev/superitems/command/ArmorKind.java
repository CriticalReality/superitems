package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.item.Armor;
import dev.superitems.item.ItemDefinition;
import java.util.Locale;

/** Armor: the same definitions as items, limited to wearable materials and created with --piece and --tier. */
public final class ArmorKind extends ItemKind {
    private static final String CREATE_USAGE = "create <id> --piece helmet|chestplate|leggings|boots --tier leather|chainmail|iron|golden|diamond|netherite "
            + "[--name text] [--description text] [--armor n] [--toughness n] [--health n] [--speed n] [--knockback_resistance n] "
            + "[--attribute \"name amount [add|mult|mult_total] [slot]\"] [--unbreakable] [--color #rrggbb] [--glow] [--model key] "
            + "[--on_hit command] [--on_damaged command] [--on_equip command] [--on_unequip command] "
            + "[--while_worn command] [--interval seconds] [--trigger_cooldown seconds]";

    /** Creates the kind. */
    public ArmorKind(SuperItems plugin) {
        super(plugin);
    }

    @Override
    public String noun() {
        return "armor piece";
    }

    @Override
    public String prefix() {
        return "/superitems armor";
    }

    @Override
    public String createUsage() {
        return CREATE_USAGE;
    }

    @Override
    public String validate(ItemDefinition definition) {
        if (!Armor.isWearable(definition.getMaterial())) {
            return "Armor needs a wearable material. Use --piece helmet|chestplate|leggings|boots with --tier diamond (or --material diamond_helmet).";
        }
        return null;
    }

    @Override
    public boolean listed(ItemDefinition definition) {
        return Armor.isWearable(definition.getMaterial());
    }

    @Override
    public String summary(ItemDefinition d) {
        return "(" + d.getMaterial().name().toLowerCase(Locale.ROOT) + ", attributes: " + d.getAttributes().size() + ")";
    }
}
