package dev.superitems.command;

import dev.superitems.util.Ids;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;

/** Creates a new definition from flags. */
public final class CreateSubcommand<T> implements Subcommand {
    private final Kind<T> kind;

    /** Creates the subcommand for a kind. */
    public CreateSubcommand(Kind<T> kind) {
        this.kind = kind;
    }

    @Override
    public String name() {
        return "create";
    }

    @Override
    public String usage() {
        return kind.createUsage();
    }

    @Override
    public String description() {
        return "Create a new " + kind.noun();
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        FlagParser.Result parsed = FlagParser.parse(args, kind.spec());
        String problem = KindSupport.syntaxProblem(parsed, kind.spec(), usage(), kind.prefix());
        if (problem != null) {
            dev.superitems.util.Text.error(sender, problem);
            return;
        }
        String id = parsed.positional().get(0).toLowerCase(Locale.ROOT);
        if (!Ids.isValid(id)) {
            dev.superitems.util.Text.error(sender, "The id may only use a-z, 0-9, _ and - (up to 32 characters).");
            return;
        }
        if (kind.contains(id)) {
            dev.superitems.util.Text.error(sender, "A " + kind.noun() + " called '" + id + "' already exists. Use " + kind.prefix() + " edit " + id + " to change it.");
            return;
        }
        T definition = kind.blank(id);
        String error = kind.apply(definition, parsed, sender);
        if (error == null) {
            error = kind.validate(definition);
        }
        if (error != null) {
            dev.superitems.util.Text.error(sender, error);
            return;
        }
        kind.put(definition);
        kind.changed();
        kind.save(sender);
        dev.superitems.util.Text.ok(sender, kind.createdMessage(id));
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        return args.length <= 1 ? List.of() : FlagCompleter.complete(args, kind.spec());
    }
}
