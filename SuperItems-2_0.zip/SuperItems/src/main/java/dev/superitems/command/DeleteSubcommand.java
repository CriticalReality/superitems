package dev.superitems.command;

import dev.superitems.util.Text;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;

/** Deletes a definition. Copies already out in the world stop doing anything. */
public final class DeleteSubcommand<T> implements Subcommand {
    private final Kind<T> kind;

    /** Creates the subcommand for a kind. */
    public DeleteSubcommand(Kind<T> kind) {
        this.kind = kind;
    }

    @Override
    public String name() {
        return "delete";
    }

    @Override
    public String usage() {
        return "delete <id>";
    }

    @Override
    public String description() {
        return "Delete a " + kind.noun();
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (args.length != 1) {
            Text.error(sender, "Usage: " + kind.prefix() + " " + usage());
            return;
        }
        String id = args[0].toLowerCase(Locale.ROOT);
        if (!kind.remove(id)) {
            Text.error(sender, "No " + kind.noun() + " called '" + id + "'.");
            return;
        }
        kind.changed();
        kind.save(sender);
        Text.ok(sender, "Deleted " + kind.noun() + " '" + id + "'. Copies already out in the world stop working.");
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        return args.length <= 1 ? Subcommand.match(kind.ids(), args.length == 0 ? "" : args[0]) : List.of();
    }
}
