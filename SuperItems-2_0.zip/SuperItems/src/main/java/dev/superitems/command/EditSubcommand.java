package dev.superitems.command;

import dev.superitems.util.Text;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;

/** Changes some settings of an existing definition. Nothing changes when any flag is wrong. */
public final class EditSubcommand<T> implements Subcommand {
    private final Kind<T> kind;

    /** Creates the subcommand for a kind. */
    public EditSubcommand(Kind<T> kind) {
        this.kind = kind;
    }

    @Override
    public String name() {
        return "edit";
    }

    @Override
    public String usage() {
        return "edit <id> [same flags as create]. Use a value of none to clear a flag";
    }

    @Override
    public String description() {
        return "Change a " + kind.noun();
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        FlagParser.Result parsed = FlagParser.parse(args, kind.spec());
        String problem = KindSupport.syntaxProblem(parsed, kind.spec(), usage(), kind.prefix());
        if (problem != null) {
            Text.error(sender, problem);
            return;
        }
        String id = parsed.positional().get(0).toLowerCase(Locale.ROOT);
        T existing = kind.get(id);
        if (existing == null) {
            Text.error(sender, "No " + kind.noun() + " called '" + id + "'. See " + kind.prefix() + " list");
            return;
        }
        if (parsed.flags().isEmpty()) {
            Text.error(sender, "Nothing to change. Add a flag such as --name.");
            return;
        }
        T draft = kind.copy(existing);
        String error = kind.apply(draft, parsed, sender);
        if (error == null) {
            error = kind.validate(draft);
        }
        if (error != null) {
            Text.error(sender, error);
            return;
        }
        kind.put(draft);
        kind.changed();
        kind.save(sender);
        Text.ok(sender, "Updated " + kind.noun() + " '" + id + "'. Items already given and mobs already spawned keep their old name, "
                + "lore and appearance; behavior (commands, timers, phases, loot) updates right away.");
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        if (args.length <= 1) {
            return Subcommand.match(kind.ids(), args.length == 0 ? "" : args[0]);
        }
        return FlagCompleter.complete(args, kind.spec());
    }
}
