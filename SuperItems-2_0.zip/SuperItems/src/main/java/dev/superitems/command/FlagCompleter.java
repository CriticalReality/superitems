package dev.superitems.command;

import java.util.List;

/** Tab completion for flag based arguments. */
final class FlagCompleter {
    private FlagCompleter() {}

    /** Completes the last word: flag names after two dashes, or values for the flag right before it. */
    static List<String> complete(String[] args, FlagSpec spec) {
        if (args.length == 0) {
            return List.of();
        }
        String typed = args[args.length - 1];
        if (typed.startsWith("--")) {
            List<String> flags = spec.names().stream().map(flag -> "--" + flag).toList();
            return Subcommand.match(flags, typed);
        }
        if (args.length < 2) {
            return List.of();
        }
        String flag = spec.canonical(args[args.length - 2]);
        if (flag == null) {
            return List.of();
        }
        return Subcommand.match(spec.hintsFor(flag), typed);
    }
}
