package dev.superitems.command;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Splits command arguments into plain words and flags. A flag is a word starting with two dashes.
 * Everything after a flag up to the next flag is that flag's value, so values can contain spaces
 * and whole commands. A flag may be repeated.
 */
public final class FlagParser {
    private FlagParser() {}

    /** The parsed arguments. Flag values are trimmed and may be empty. */
    public record Result(List<String> positional, Map<String, List<String>> flags, List<String> unknown) {
        /** Returns true when the flag was given at least once. */
        public boolean has(String flag) {
            return flags.containsKey(flag);
        }

        /** Returns every value given for a flag, in order. */
        public List<String> all(String flag) {
            return flags.getOrDefault(flag, List.of());
        }

        /** Returns the last value given for a flag, or null. */
        public String last(String flag) {
            List<String> values = all(flag);
            return values.isEmpty() ? null : values.get(values.size() - 1);
        }
    }

    /** Returns true when the word looks like a flag such as --name. */
    public static boolean isFlagToken(String word) {
        return word.length() > 2 && word.startsWith("--") && Character.isLetter(word.charAt(2));
    }

    /** Parses the arguments using the flags of an item. */
    public static Result parse(String[] args) {
        return parse(args, Specs.ITEM);
    }

    /** Parses the arguments using the given flags. */
    public static Result parse(String[] args, FlagSpec spec) {
        List<String> positional = new ArrayList<>();
        Map<String, List<String>> flags = new LinkedHashMap<>();
        List<String> unknown = new ArrayList<>();
        List<String> words = new ArrayList<>();
        String current = null;
        for (String arg : args) {
            if (isFlagToken(arg)) {
                finish(flags, current, words);
                current = spec.canonical(arg);
                if (current == null) {
                    unknown.add(arg);
                }
            } else if (current == null) {
                positional.add(arg);
            } else {
                words.add(arg);
            }
        }
        finish(flags, current, words);
        return new Result(positional, flags, unknown);
    }

    private static void finish(Map<String, List<String>> flags, String current, List<String> words) {
        if (current != null) {
            flags.computeIfAbsent(current, key -> new ArrayList<>()).add(String.join(" ", words).trim());
        }
        words.clear();
    }
}
