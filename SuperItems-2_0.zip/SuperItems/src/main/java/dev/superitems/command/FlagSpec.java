package dev.superitems.command;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;

/** The flags one kind of definition understands: names, shortcuts, flags that may be bare, and tab completion hints. */
public final class FlagSpec {
    private final Map<String, String> aliases = new LinkedHashMap<>();
    private final List<String> names = new ArrayList<>();
    private final Set<String> bare = new HashSet<>();
    private final Map<String, Supplier<List<String>>> hints = new HashMap<>();

    /** Adds a flag with optional shortcut names. */
    public FlagSpec flag(String name, String... shortcuts) {
        names.add(name);
        aliases.put(name, name);
        for (String shortcut : shortcuts) {
            aliases.put(shortcut, name);
        }
        return this;
    }

    /** Marks flags that may be written without a value, such as --glow. */
    public FlagSpec bare(String... flags) {
        bare.addAll(List.of(flags));
        return this;
    }

    /** Gives a flag a list of tab completion values. */
    public FlagSpec hint(String flag, Supplier<List<String>> values) {
        hints.put(flag, values);
        return this;
    }

    /** Gives a flag a fixed list of tab completion values. */
    public FlagSpec hint(String flag, String... values) {
        List<String> list = List.of(values);
        hints.put(flag, () -> list);
        return this;
    }

    /** Returns the canonical flag name for a word like --on-right-click, or null when it is not a known flag. */
    public String canonical(String word) {
        if (!FlagParser.isFlagToken(word)) {
            return null;
        }
        return aliases.get(word.substring(2).toLowerCase(Locale.ROOT).replace('-', '_'));
    }

    /** The flag names shown in help and tab completion. */
    public List<String> names() {
        return List.copyOf(names);
    }

    /** True when the flag may be given without a value. */
    public boolean allowsBare(String flag) {
        return bare.contains(flag);
    }

    /** Completion values for a flag, or an empty list. */
    public List<String> hintsFor(String flag) {
        Supplier<List<String>> supplier = hints.get(flag);
        return supplier == null ? List.of() : supplier.get();
    }
}
