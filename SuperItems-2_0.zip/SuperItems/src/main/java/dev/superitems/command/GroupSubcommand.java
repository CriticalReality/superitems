package dev.superitems.command;

import dev.superitems.util.Text;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.CommandSender;

/** A subcommand that has subcommands of its own, such as /superitems mob create. */
public final class GroupSubcommand implements Subcommand {
    private final String name;
    private final String description;
    private final Map<String, Subcommand> children = new LinkedHashMap<>();

    /** Creates a group with the given children. */
    public GroupSubcommand(String name, String description, List<Subcommand> list) {
        this.name = name;
        this.description = description;
        for (Subcommand child : list) {
            children.put(child.name(), child);
        }
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public String usage() {
        return name + " <" + String.join("|", children.keySet()) + ">";
    }

    @Override
    public String description() {
        return description;
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Subcommand child = args.length == 0 ? null : children.get(args[0].toLowerCase(Locale.ROOT));
        if (child == null) {
            Text.info(sender, "/superitems " + name + " commands:");
            for (Subcommand each : children.values()) {
                sender.sendMessage(Component.text("  /superitems " + name + " " + each.usage(), NamedTextColor.YELLOW)
                        .append(Component.text(" - " + each.description(), NamedTextColor.GRAY)));
            }
            return;
        }
        child.execute(sender, Arrays.copyOfRange(args, 1, args.length));
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        if (args.length <= 1) {
            return Subcommand.match(children.keySet(), args.length == 0 ? "" : args[0]);
        }
        Subcommand child = children.get(args[0].toLowerCase(Locale.ROOT));
        return child == null ? List.of() : child.complete(sender, Arrays.copyOfRange(args, 1, args.length));
    }
}
