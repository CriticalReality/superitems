package dev.superitems.command;

import dev.superitems.util.Text;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;

/** Shows every setting of one definition. */
public final class InfoSubcommand<T> implements Subcommand {
    private final Kind<T> kind;

    /** Creates the subcommand for a kind. */
    public InfoSubcommand(Kind<T> kind) {
        this.kind = kind;
    }

    @Override
    public String name() {
        return "info";
    }

    @Override
    public String usage() {
        return "info <id>";
    }

    @Override
    public String description() {
        return "Show a " + kind.noun() + "'s settings";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (args.length != 1) {
            Text.error(sender, "Usage: " + kind.prefix() + " " + usage());
            return;
        }
        String id = args[0].toLowerCase(Locale.ROOT);
        T definition = kind.get(id);
        if (definition == null) {
            Text.error(sender, "No " + kind.noun() + " called '" + id + "'.");
            return;
        }
        Text.ok(sender, kind.noun() + " '" + id + "'");
        for (String line : kind.infoLines(definition)) {
            Text.info(sender, line);
        }
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        return args.length <= 1 ? Subcommand.match(kind.ids(), args.length == 0 ? "" : args[0]) : List.of();
    }
}
