package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.item.Armor;
import dev.superitems.item.AttributeLine;
import dev.superitems.item.ConsumeMode;
import dev.superitems.item.ItemDefinition;
import dev.superitems.item.ItemFactory;
import dev.superitems.util.Parse;
import dev.superitems.util.Range;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.CommandSender;

/** Items. Also the base of armor, which is the same data with armor flags and a wearable material. */
public class ItemKind implements Kind<ItemDefinition> {
    private static final String CREATE_USAGE = "create <id> [--name text] [--description text] [--material item] "
            + "[--on_right_click command] [--on_left_click command] [--consume none|right|left|both] "
            + "[--cooldown seconds] [--glow] [--model key] [--cancel true|false] [--unbreakable] "
            + "[--attribute \"name amount [add|mult|mult_total] [slot]\"] [--damage min-max] [--color #rrggbb] "
            + "[--on_hit command] [--on_damaged command] [--on_equip command] [--on_unequip command] "
            + "[--while_worn command] [--interval seconds] [--trigger_cooldown seconds]";

    /** The plugin whose stores are used. */
    protected final SuperItems plugin;

    /** Creates the kind. */
    public ItemKind(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String noun() {
        return "item";
    }

    @Override
    public String prefix() {
        return "/superitems";
    }

    @Override
    public FlagSpec spec() {
        return Specs.ITEM;
    }

    @Override
    public String createUsage() {
        return CREATE_USAGE;
    }

    @Override
    public ItemDefinition blank(String id) {
        return new ItemDefinition(id, id, plugin.defaultMaterial());
    }

    @Override
    public ItemDefinition copy(ItemDefinition definition) {
        return definition.copy();
    }

    @Override
    public String createdMessage(String id) {
        return "Created '" + id + "'. Get it with " + prefix() + " give " + id;
    }

    @Override
    public String apply(ItemDefinition d, FlagParser.Result p, CommandSender sender) {
        if (p.has("name")) {
            d.setName(p.last("name"));
        }
        if (p.has("description")) {
            d.setDescription(Parse.lines(p.all("description")));
        }
        if (p.has("piece") || p.has("tier")) {
            String piece = p.has("piece") ? p.last("piece").toLowerCase(Locale.ROOT) : Armor.pieceOf(d.getMaterial());
            String tier = p.has("tier") ? p.last("tier").toLowerCase(Locale.ROOT) : Armor.tierOf(d.getMaterial());
            if (piece == null || tier == null) {
                return "Give both --piece (helmet, chestplate, leggings, boots) and --tier (leather, chainmail, iron, golden, diamond, netherite).";
            }
            Material made = Armor.materialFor(tier, piece);
            if (made == null) {
                return "There is no " + tier + " " + piece + ".";
            }
            d.setMaterial(made);
        }
        if (p.has("material")) {
            String text = p.last("material");
            Material material = Material.matchMaterial(text);
            if (material == null || !material.isItem() || material.isAir()) {
                return "'" + text + "' is not an item material (try something like stick or blaze_rod).";
            }
            d.setMaterial(material);
        }
        if (p.has("model")) {
            String text = p.last("model");
            if (Parse.isClear(text)) {
                d.setModel(null);
            } else if (NamespacedKey.fromString(text.toLowerCase(Locale.ROOT)) == null) {
                return "'" + text + "' is not a valid model key (example: minecraft:dead_brain_coral).";
            } else {
                d.setModel(text.toLowerCase(Locale.ROOT));
            }
        }
        if (p.has("glow")) {
            Boolean value = Parse.bool(p.last("glow"));
            if (value == null) {
                return "--glow must be true or false.";
            }
            d.setGlow(value);
        }
        if (p.has("on_right_click")) {
            d.setOnRightClick(Parse.entries(p.all("on_right_click")));
        }
        if (p.has("on_left_click")) {
            d.setOnLeftClick(Parse.entries(p.all("on_left_click")));
        }
        if (p.has("consume")) {
            ConsumeMode mode = ConsumeMode.parse(p.last("consume"));
            if (mode == null) {
                return "--consume must be none, right, left or both.";
            }
            d.setConsume(mode);
        }
        if (p.has("cooldown")) {
            Double seconds = Parse.number(p.last("cooldown"));
            if (seconds == null || seconds < 0) {
                return "--cooldown must be a number of seconds, 0 or more.";
            }
            d.setCooldownSeconds(seconds);
        }
        if (p.has("cancel")) {
            Boolean value = Parse.bool(p.last("cancel"));
            if (value == null) {
                return "--cancel must be true or false.";
            }
            d.setCancel(value);
        }
        if (p.has("unbreakable")) {
            Boolean value = Parse.bool(p.last("unbreakable"));
            if (value == null) {
                return "--unbreakable must be true or false.";
            }
            d.setUnbreakable(value);
        }
        String error = applyAttributes(d, p);
        if (error != null) {
            return error;
        }
        if (p.has("color")) {
            String text = p.last("color");
            if (Parse.isClear(text)) {
                d.setColor(null);
            } else if (ItemFactory.parseColor(text) == null) {
                return "--color must look like #ff8800.";
            } else {
                d.setColor(text.startsWith("#") ? text.toLowerCase(Locale.ROOT) : "#" + text.toLowerCase(Locale.ROOT));
            }
        }
        if (p.has("damage")) {
            String text = p.last("damage");
            if (Parse.isClear(text)) {
                d.setDamage(0, 0);
            } else {
                Range range = Range.parse(text);
                if (range == null || range.min() < 0 || range.max() <= 0) {
                    return "--damage must be a number or a range like 400-600.";
                }
                d.setDamage(range.min(), range.max());
            }
        }
        if (p.has("on_hit")) {
            d.setOnHit(Parse.entries(p.all("on_hit")));
        }
        if (p.has("on_damaged")) {
            d.setOnDamaged(Parse.entries(p.all("on_damaged")));
        }
        if (p.has("on_equip")) {
            d.setOnEquip(Parse.entries(p.all("on_equip")));
        }
        if (p.has("on_unequip")) {
            d.setOnUnequip(Parse.entries(p.all("on_unequip")));
        }
        if (p.has("while_worn")) {
            d.setWhileWorn(Parse.entries(p.all("while_worn")));
        }
        if (p.has("interval")) {
            Double seconds = Parse.number(p.last("interval"));
            if (seconds == null || seconds < 0.5) {
                return "--interval must be at least 0.5 seconds.";
            }
            d.setWhileWornInterval(seconds);
        }
        if (p.has("trigger_cooldown")) {
            Double seconds = Parse.number(p.last("trigger_cooldown"));
            if (seconds == null || seconds < 0) {
                return "--trigger_cooldown must be a number of seconds, 0 or more.";
            }
            d.setTriggerCooldownSeconds(seconds);
        }
        return null;
    }

    private static String applyAttributes(ItemDefinition d, FlagParser.Result p) {
        List<String> lines = new ArrayList<>(d.getAttributes());
        if (p.has("attribute")) {
            for (String value : p.all("attribute")) {
                if (Parse.isClear(value)) {
                    lines.clear();
                    continue;
                }
                try {
                    put(lines, AttributeLine.parse(value));
                } catch (IllegalArgumentException e) {
                    return e.getMessage();
                }
            }
        }
        for (String flag : List.of("armor", "toughness", "health", "speed", "knockback_resistance")) {
            if (!p.has(flag)) {
                continue;
            }
            String name = AttributeLine.normalizeName(flag);
            String text = p.last(flag);
            if (Parse.isClear(text)) {
                lines.removeIf(line -> startsWithName(line, name));
                continue;
            }
            Double number = Parse.number(text);
            if (number == null) {
                return "--" + flag + " must be a number.";
            }
            put(lines, new AttributeLine(name, number, "add", "auto"));
        }
        if (p.has("attribute") || p.has("armor") || p.has("toughness") || p.has("health") || p.has("speed")
                || p.has("knockback_resistance")) {
            d.setAttributes(lines);
        }
        return null;
    }

    private static boolean startsWithName(String line, String name) {
        return line.startsWith(name + " ");
    }

    private static void put(List<String> lines, AttributeLine line) {
        lines.removeIf(existing -> startsWithName(existing, line.name()) && existing.endsWith(" " + line.slot()));
        lines.add(line.toText());
    }

    @Override
    public ItemDefinition get(String id) {
        return plugin.items().get(id);
    }

    @Override
    public boolean contains(String id) {
        return plugin.items().contains(id);
    }

    @Override
    public void put(ItemDefinition definition) {
        plugin.items().put(definition);
    }

    @Override
    public boolean remove(String id) {
        return plugin.items().remove(id);
    }

    @Override
    public List<String> ids() {
        return plugin.items().ids();
    }

    @Override
    public Collection<ItemDefinition> all() {
        return plugin.items().all();
    }

    @Override
    public String idOf(ItemDefinition definition) {
        return definition.getId();
    }

    @Override
    public List<String> infoLines(ItemDefinition d) {
        List<String> lines = new ArrayList<>();
        lines.add("name: " + d.getName());
        lines.add("material: " + d.getMaterial().name().toLowerCase(Locale.ROOT)
                + (d.getModel() == null ? "" : ", model: " + d.getModel())
                + (d.isGlow() ? ", glowing" : "")
                + (d.isUnbreakable() ? ", unbreakable" : "")
                + (d.getColor() == null ? "" : ", color: " + d.getColor()));
        lines.add("description: " + (d.getDescription().isEmpty() ? "(none)" : String.join(" | ", d.getDescription())));
        lines.add("on right click: " + show(d.getOnRightClick()));
        lines.add("on left click: " + show(d.getOnLeftClick()));
        lines.add("consume: " + d.getConsume().name().toLowerCase(Locale.ROOT)
                + ", cooldown: " + d.getCooldownSeconds() + "s, cancel click: " + d.isCancel());
        if (d.hasDamageRange()) {
            lines.add("damage: " + new Range(d.getDamageMin(), d.getDamageMax()).show());
        }
        if (!d.getAttributes().isEmpty()) {
            lines.add("attributes: " + String.join(" ; ", d.getAttributes()));
        }
        lines.add("on hit: " + show(d.getOnHit()) + " | on damaged: " + show(d.getOnDamaged()));
        lines.add("on equip: " + show(d.getOnEquip()) + " | on unequip: " + show(d.getOnUnequip()));
        lines.add("while worn (every " + d.getWhileWornInterval() + "s): " + show(d.getWhileWorn())
                + " | trigger cooldown: " + d.getTriggerCooldownSeconds() + "s");
        List<String> sets = new ArrayList<>();
        plugin.sets().containing(d.getId()).forEach(set -> sets.add(set.getId()));
        if (!sets.isEmpty()) {
            lines.add("in sets: " + String.join(", ", sets));
        }
        return lines;
    }

    private static String show(List<String> commands) {
        return commands.isEmpty() ? "(nothing)" : String.join(" ;; ", commands);
    }

    @Override
    public String summary(ItemDefinition d) {
        return "(" + d.getMaterial().name().toLowerCase(Locale.ROOT) + ", right: " + d.getOnRightClick().size()
                + ", left: " + d.getOnLeftClick().size() + ")";
    }

    @Override
    public boolean save(CommandSender sender) {
        return plugin.saveItems(sender);
    }
}
