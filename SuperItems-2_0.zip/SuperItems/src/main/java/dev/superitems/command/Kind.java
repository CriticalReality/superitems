package dev.superitems.command;

import java.util.Collection;
import java.util.List;
import org.bukkit.command.CommandSender;

/**
 * Describes one kind of definition (item, armor, set, mob, loot table, spawner) so that the
 * create, edit, delete, info and list subcommands can be shared by all of them.
 */
public interface Kind<T> {
    /** Singular word used in messages, such as "mob". */
    String noun();

    /** The command text users type for this kind, such as "/superitems mob". */
    String prefix();

    /** The flags this kind understands. */
    FlagSpec spec();

    /** Usage text for create, without the leading command. */
    String createUsage();

    /** A new definition with default settings. */
    T blank(String id);

    /** An independent copy used to check an edit before it is applied. */
    T copy(T definition);

    /** Applies every flag that was given to the definition. Returns an error message, or null on success. */
    String apply(T definition, FlagParser.Result parsed, CommandSender sender);

    /** Final check after flags were applied, for rules that depend on several flags. Returns an error message, or null. */
    default String validate(T definition) {
        return null;
    }

    /** Returns a definition or null. */
    T get(String id);

    /** True when the id exists. */
    boolean contains(String id);

    /** Adds or replaces a definition. */
    void put(T definition);

    /** Removes a definition and returns whether it existed. */
    boolean remove(String id);

    /** Every id of this kind. */
    List<String> ids();

    /** Every definition of this kind. */
    Collection<T> all();

    /** The id of a definition. */
    String idOf(T definition);

    /** Lines shown by the info subcommand. */
    List<String> infoLines(T definition);

    /** One line shown by the list subcommand. */
    String summary(T definition);

    /** Saves to disk and tells the sender when it fails. */
    boolean save(CommandSender sender);

    /** Called after a definition was created, changed or deleted. */
    default void changed() {}

    /** Message shown after create. */
    default String createdMessage(String id) {
        return "Created " + noun() + " '" + id + "'.";
    }

    /** True when the definition belongs in this kind's list (armor hides non wearable items). */
    default boolean listed(T definition) {
        return true;
    }
}
