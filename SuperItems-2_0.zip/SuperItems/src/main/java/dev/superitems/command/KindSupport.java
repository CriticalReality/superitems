package dev.superitems.command;

import java.util.List;

/** Checks shared by the create and edit subcommands. */
final class KindSupport {
    private KindSupport() {}

    /** Returns an error message when the words or flags are malformed, otherwise null. */
    static String syntaxProblem(FlagParser.Result parsed, FlagSpec spec, String usage, String prefix) {
        if (!parsed.unknown().isEmpty()) {
            return "Unknown flag " + parsed.unknown().get(0) + ". Valid flags: --" + String.join(", --", spec.names());
        }
        if (parsed.positional().size() != 1) {
            return "Expected the id first, then flags like --name. Usage: " + prefix + " " + usage;
        }
        for (String flag : parsed.flags().keySet()) {
            List<String> values = parsed.all(flag);
            if (!spec.allowsBare(flag) && values.stream().anyMatch(String::isEmpty)) {
                return "--" + flag + " needs a value.";
            }
        }
        return null;
    }
}
