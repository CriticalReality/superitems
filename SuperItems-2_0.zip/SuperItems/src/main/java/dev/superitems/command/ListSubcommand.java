package dev.superitems.command;

import dev.superitems.util.Text;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.CommandSender;

/** Lists every definition of a kind. */
public final class ListSubcommand<T> implements Subcommand {
    private final Kind<T> kind;

    /** Creates the subcommand for a kind. */
    public ListSubcommand(Kind<T> kind) {
        this.kind = kind;
    }

    @Override
    public String name() {
        return "list";
    }

    @Override
    public String usage() {
        return "list";
    }

    @Override
    public String description() {
        return "List all " + kind.noun() + "s";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        List<T> shown = new ArrayList<>();
        for (T definition : kind.all()) {
            if (kind.listed(definition)) {
                shown.add(definition);
            }
        }
        if (shown.isEmpty()) {
            Text.info(sender, "No " + kind.noun() + "s yet. Try " + kind.prefix() + " create <id> --name Something");
            return;
        }
        Text.ok(sender, shown.size() + " " + kind.noun() + "(s):");
        for (T definition : shown) {
            Text.info(sender, "- " + kind.idOf(definition) + " " + kind.summary(definition));
        }
    }
}
