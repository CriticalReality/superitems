package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.loot.LootResult;
import dev.superitems.util.Text;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/** Rolls a loot table and drops the result in the world. */
public final class LootDropSubcommand implements Subcommand {
    private final SuperItems plugin;

    /** Creates the subcommand. */
    public LootDropSubcommand(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String name() {
        return "drop";
    }

    @Override
    public String usage() {
        return "drop <table> [world x y z]";
    }

    @Override
    public String description() {
        return "Roll a loot table and drop the items where you stand, or at a place";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (args.length == 0) {
            Text.error(sender, "Usage: /superitems loot " + usage());
            return;
        }
        String id = args[0].toLowerCase(Locale.ROOT);
        if (!plugin.loot().contains(id)) {
            Text.error(sender, "No loot table called '" + id + "'. See /superitems loot list");
            return;
        }
        Targets.Place place = Targets.place(plugin, sender, args, 1);
        if (place.error() != null) {
            Text.error(sender, place.error());
            return;
        }
        LootResult result = plugin.roller().roll(id);
        Player player = sender instanceof Player self ? self : null;
        plugin.roller().dropAt(place.location(), player, result);
        Text.ok(sender, "Dropped " + result.items().size() + " stack(s) and ran " + result.commands().size() + " command(s).");
        for (String problem : result.problems()) {
            Text.error(sender, problem);
        }
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        return args.length <= 1 ? Subcommand.match(plugin.loot().ids(), args.length == 0 ? "" : args[0]) : List.of();
    }
}
