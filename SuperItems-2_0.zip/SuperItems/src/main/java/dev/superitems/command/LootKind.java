package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.loot.LootEntry;
import dev.superitems.loot.LootTable;
import dev.superitems.util.Parse;
import dev.superitems.util.Range;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;

/** Loot tables (loot pools). */
public final class LootKind implements Kind<LootTable> {
    private static final String CREATE_USAGE = "create <id> [--name text] [--rolls 1-3] [--chance percent] [--deliver drop|inventory] "
            + "[--entry \"weight kind:ref [amount] [chance=%]\"] [--always \"weight kind:ref [amount] [chance=%]\"]";

    private final SuperItems plugin;

    /** Creates the kind. */
    public LootKind(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String noun() {
        return "loot table";
    }

    @Override
    public String prefix() {
        return "/superitems loot";
    }

    @Override
    public FlagSpec spec() {
        return Specs.LOOT;
    }

    @Override
    public String createUsage() {
        return CREATE_USAGE;
    }

    @Override
    public LootTable blank(String id) {
        return new LootTable(id);
    }

    @Override
    public LootTable copy(LootTable definition) {
        return definition.copy();
    }

    @Override
    public String apply(LootTable d, FlagParser.Result p, CommandSender sender) {
        if (p.has("name")) {
            d.setName(p.last("name"));
        }
        if (p.has("rolls")) {
            Range rolls = Range.parse(p.last("rolls"));
            if (rolls == null || rolls.min() < 0) {
                return "--rolls must be a number or a range like 1-3.";
            }
            d.setRolls(rolls);
        }
        if (p.has("chance")) {
            Double chance = Parse.number(p.last("chance").replace("%", ""));
            if (chance == null || chance < 0 || chance > 100) {
                return "--chance must be from 0 to 100.";
            }
            d.setChance(chance);
        }
        if (p.has("deliver")) {
            switch (p.last("deliver").toLowerCase(Locale.ROOT)) {
                case "drop" -> d.setDelivery(LootTable.Delivery.DROP);
                case "inventory" -> d.setDelivery(LootTable.Delivery.INVENTORY);
                default -> {
                    return "--deliver must be drop or inventory.";
                }
            }
        }
        if (p.has("entry")) {
            List<String> lines = Parse.entriesOnTop(d.getEntries(), p.all("entry"));
            String error = check(lines, d.getId());
            if (error != null) {
                return error;
            }
            d.setEntries(lines);
        }
        if (p.has("always")) {
            List<String> lines = Parse.entriesOnTop(d.getAlways(), p.all("always"));
            String error = check(lines, d.getId());
            if (error != null) {
                return error;
            }
            d.setAlways(lines);
        }
        return null;
    }

    private String check(List<String> lines, String ownId) {
        for (String line : lines) {
            LootEntry entry;
            try {
                entry = LootEntry.parse(line);
            } catch (IllegalArgumentException e) {
                return "Entry '" + line + "': " + e.getMessage();
            }
            if (entry.kind() == LootEntry.Kind.ITEM && !plugin.items().contains(entry.ref())) {
                return "Entry '" + line + "': no item called '" + entry.ref() + "'. Create it first.";
            }
            if (entry.kind() == LootEntry.Kind.TABLE) {
                if (entry.ref().equals(ownId)) {
                    return "Entry '" + line + "': a table cannot include itself.";
                }
                if (!plugin.loot().contains(entry.ref())) {
                    return "Entry '" + line + "': no loot table called '" + entry.ref() + "'. Create it first.";
                }
            }
        }
        return null;
    }

    @Override
    public LootTable get(String id) {
        return plugin.loot().get(id);
    }

    @Override
    public boolean contains(String id) {
        return plugin.loot().contains(id);
    }

    @Override
    public void put(LootTable definition) {
        plugin.loot().put(definition);
    }

    @Override
    public boolean remove(String id) {
        return plugin.loot().remove(id);
    }

    @Override
    public List<String> ids() {
        return plugin.loot().ids();
    }

    @Override
    public Collection<LootTable> all() {
        return plugin.loot().all();
    }

    @Override
    public String idOf(LootTable definition) {
        return definition.getId();
    }

    @Override
    public List<String> infoLines(LootTable d) {
        List<String> lines = new ArrayList<>();
        lines.add("name: " + d.getName());
        lines.add("rolls: " + d.getRolls().show() + ", chance: " + d.getChance() + "%, deliver: " + d.getDelivery().name().toLowerCase(Locale.ROOT));
        lines.add("entries (" + d.getEntries().size() + "):");
        for (String entry : d.getEntries()) {
            lines.add("  " + entry);
        }
        lines.add("always (" + d.getAlways().size() + "):");
        for (String entry : d.getAlways()) {
            lines.add("  " + entry);
        }
        return lines;
    }

    @Override
    public String summary(LootTable d) {
        return "(rolls " + d.getRolls().show() + ", " + d.getEntries().size() + " entries, " + d.getAlways().size() + " guaranteed)";
    }

    @Override
    public boolean save(CommandSender sender) {
        return plugin.saveLoot(sender);
    }
}
