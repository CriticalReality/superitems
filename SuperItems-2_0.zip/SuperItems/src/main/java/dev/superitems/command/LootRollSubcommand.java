package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.loot.LootResult;
import dev.superitems.util.Parse;
import dev.superitems.util.Text;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/** Rolls a loot table straight into a player's inventory. */
public final class LootRollSubcommand implements Subcommand {
    private final SuperItems plugin;

    /** Creates the subcommand. */
    public LootRollSubcommand(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String name() {
        return "roll";
    }

    @Override
    public String usage() {
        return "roll <table> [player] [times]";
    }

    @Override
    public String description() {
        return "Roll a loot table and give the result to a player";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (args.length == 0) {
            Text.error(sender, "Usage: /superitems loot " + usage());
            return;
        }
        String id = args[0].toLowerCase(Locale.ROOT);
        if (!plugin.loot().contains(id)) {
            Text.error(sender, "No loot table called '" + id + "'. See /superitems loot list");
            return;
        }
        Player target;
        if (args.length >= 2) {
            target = plugin.getServer().getPlayerExact(args[1]);
            if (target == null) {
                Text.error(sender, "Player '" + args[1] + "' is not online.");
                return;
            }
        } else if (sender instanceof Player self) {
            target = self;
        } else {
            Text.error(sender, "The console must name a player: /superitems loot " + usage());
            return;
        }
        int times = 1;
        if (args.length >= 3) {
            Integer parsed = Parse.integer(args[2]);
            if (parsed == null || parsed < 1 || parsed > 100) {
                Text.error(sender, "Times must be a whole number from 1 to 100.");
                return;
            }
            times = parsed;
        }
        LootResult total = new LootResult();
        for (int i = 0; i < times; i++) {
            total.addAll(plugin.roller().roll(id));
        }
        plugin.roller().giveTo(target, total);
        Text.ok(sender, "Gave " + target.getName() + " " + total.items().size() + " stack(s) and ran " + total.commands().size() + " command(s).");
        for (String problem : total.problems()) {
            Text.error(sender, problem);
        }
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        String typed = args.length == 0 ? "" : args[args.length - 1];
        return switch (args.length) {
            case 0, 1 -> Subcommand.match(plugin.loot().ids(), typed);
            case 2 -> Subcommand.match(plugin.getServer().getOnlinePlayers().stream().map(Player::getName).toList(), typed);
            default -> List.of();
        };
    }
}
