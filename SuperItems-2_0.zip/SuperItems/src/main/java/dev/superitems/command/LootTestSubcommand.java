package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.loot.LootResult;
import dev.superitems.util.Parse;
import dev.superitems.util.Text;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;

/** Simulates many rolls of a loot table and shows what came out, without giving anything. */
public final class LootTestSubcommand implements Subcommand {
    private static final int MAX_ROLLS = 100_000;
    private static final int SHOWN = 20;

    private final SuperItems plugin;

    /** Creates the subcommand. */
    public LootTestSubcommand(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String name() {
        return "test";
    }

    @Override
    public String usage() {
        return "test <table> [times]";
    }

    @Override
    public String description() {
        return "Simulate rolls of a table and show the totals (gives nothing)";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (args.length == 0) {
            Text.error(sender, "Usage: /superitems loot " + usage());
            return;
        }
        String id = args[0].toLowerCase(Locale.ROOT);
        if (!plugin.loot().contains(id)) {
            Text.error(sender, "No loot table called '" + id + "'.");
            return;
        }
        int times = 1000;
        if (args.length >= 2) {
            Integer parsed = Parse.integer(args[1]);
            if (parsed == null || parsed < 1 || parsed > MAX_ROLLS) {
                Text.error(sender, "Times must be a whole number from 1 to " + MAX_ROLLS + ".");
                return;
            }
            times = parsed;
        }
        Map<String, Long> totals = new HashMap<>();
        Map<String, Integer> hits = new HashMap<>();
        Set<String> problems = new LinkedHashSet<>();
        for (int i = 0; i < times; i++) {
            LootResult result = plugin.roller().roll(id);
            Set<String> seen = new LinkedHashSet<>();
            for (ItemStack stack : result.items()) {
                String key = label(stack);
                totals.merge(key, (long) stack.getAmount(), Long::sum);
                seen.add(key);
            }
            for (String command : result.commands()) {
                String key = "command: " + command;
                totals.merge(key, 1L, Long::sum);
                seen.add(key);
            }
            for (String key : seen) {
                hits.merge(key, 1, Integer::sum);
            }
            problems.addAll(result.problems());
        }
        List<Map.Entry<String, Long>> sorted = new ArrayList<>(totals.entrySet());
        sorted.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
        Text.ok(sender, "Loot table '" + id + "' over " + times + " roll(s):");
        if (sorted.isEmpty()) {
            Text.info(sender, "  nothing dropped");
        }
        for (int i = 0; i < Math.min(SHOWN, sorted.size()); i++) {
            String key = sorted.get(i).getKey();
            double percent = hits.getOrDefault(key, 0) * 100.0 / times;
            Text.info(sender, String.format(Locale.ROOT, "  %s: %d total, in %.1f%% of rolls", key, sorted.get(i).getValue(), percent));
        }
        for (String problem : problems) {
            Text.error(sender, problem);
        }
    }

    private String label(ItemStack stack) {
        String id = plugin.factory().idOf(stack);
        return id != null ? "item " + id : stack.getType().name().toLowerCase(Locale.ROOT);
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        String typed = args.length == 0 ? "" : args[args.length - 1];
        if (args.length <= 1) {
            return Subcommand.match(plugin.loot().ids(), typed);
        }
        return args.length == 2 ? Subcommand.match(List.of("100", "1000", "10000"), typed) : List.of();
    }
}
