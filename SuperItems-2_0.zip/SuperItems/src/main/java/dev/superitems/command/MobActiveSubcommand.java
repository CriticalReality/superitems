package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.mob.ActiveMob;
import dev.superitems.util.Text;
import java.util.Map;
import java.util.TreeMap;
import org.bukkit.command.CommandSender;

/** Counts live custom mobs in loaded chunks. */
public final class MobActiveSubcommand implements Subcommand {
    private final SuperItems plugin;

    /** Creates the subcommand. */
    public MobActiveSubcommand(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String name() {
        return "active";
    }

    @Override
    public String usage() {
        return "active";
    }

    @Override
    public String description() {
        return "Show how many custom mobs are alive in loaded chunks";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        Map<String, Integer> counts = new TreeMap<>();
        for (ActiveMob mob : plugin.manager().all()) {
            counts.merge(mob.id(), 1, Integer::sum);
        }
        if (counts.isEmpty()) {
            Text.info(sender, "No custom mobs are alive in loaded chunks.");
            return;
        }
        Text.ok(sender, counts.values().stream().mapToInt(Integer::intValue).sum() + " custom mob(s) alive:");
        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            Text.info(sender, "- " + entry.getKey() + ": " + entry.getValue());
        }
    }
}
