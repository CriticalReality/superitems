package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.util.Text;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;

/** Removes live custom mobs without drops. */
public final class MobKillSubcommand implements Subcommand {
    private final SuperItems plugin;

    /** Creates the subcommand. */
    public MobKillSubcommand(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String name() {
        return "kill";
    }

    @Override
    public String usage() {
        return "kill [id]";
    }

    @Override
    public String description() {
        return "Remove all live custom mobs, or only those of one id (no drops)";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        String id = args.length == 0 ? null : args[0].toLowerCase(Locale.ROOT);
        int removed = plugin.manager().killAll(id);
        Text.ok(sender, "Removed " + removed + " mob(s)" + (id == null ? "." : " of '" + id + "'."));
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        return args.length <= 1 ? Subcommand.match(plugin.mobs().ids(), args.length == 0 ? "" : args[0]) : List.of();
    }
}
