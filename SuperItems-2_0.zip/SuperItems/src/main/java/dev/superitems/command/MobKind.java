package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.action.NumberedCommand;
import dev.superitems.item.AttributeLine;
import dev.superitems.mob.MobDefinition;
import dev.superitems.mob.MobManager;
import dev.superitems.mob.MobTier;
import dev.superitems.util.Parse;
import dev.superitems.util.Range;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;

/** Custom enemies, minibosses and bosses. */
public final class MobKind implements Kind<MobDefinition> {
    private static final String CREATE_USAGE = "create <id> [--tier enemy|miniboss|boss] [--type zombie] [--name text] "
            + "[--health n] [--damage n] [--speed n|1.5x] [--armor n] [--toughness n] [--knockback_resistance n] [--follow_range n] [--scale n] "
            + "[--attribute \"name value\"] [--size n] [--baby] [--glow] [--silent] [--invulnerable] [--invisible] [--ai true|false] [--gravity true|false] "
            + "[--persistent true|false] [--name_visible true|false] "
            + "[--mainhand ref] [--offhand ref] [--helmet ref] [--chestplate ref] [--leggings ref] [--boots ref] [--equipment_drop percent] "
            + "[--effect \"name [amp] [seconds|infinite]\"] [--rider mobId] "
            + "[--on_spawn cmd] [--on_hit cmd] [--on_damaged cmd] [--on_death cmd] [--on_kill cmd] "
            + "[--timer \"seconds cmd\"] [--phase \"percent cmd\"] [--trigger_cooldown seconds] [--active_range blocks] "
            + "[--bossbar true|false] [--bar_color c] [--bar_style s] [--bar_range blocks] [--bar_title text] "
            + "[--loot tableId] [--xp min-max] [--vanilla_drops true|false] "
            + "[--spawn_message text] [--death_message text] [--announce world|server|none] "
            + "[--replace entityType percent] [--worlds a,b]";

    private final SuperItems plugin;

    /** Creates the kind. */
    public MobKind(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String noun() {
        return "mob";
    }

    @Override
    public String prefix() {
        return "/superitems mob";
    }

    @Override
    public FlagSpec spec() {
        return Specs.MOB;
    }

    @Override
    public String createUsage() {
        return CREATE_USAGE;
    }

    @Override
    public MobDefinition blank(String id) {
        return new MobDefinition(id);
    }

    @Override
    public MobDefinition copy(MobDefinition definition) {
        return definition.copy();
    }

    @Override
    public String createdMessage(String id) {
        return "Created mob '" + id + "'. Spawn it with /superitems mob spawn " + id;
    }

    @Override
    public String apply(MobDefinition d, FlagParser.Result p, CommandSender sender) {
        String error = basics(d, p);
        if (error == null) {
            error = stats(d, p);
        }
        if (error == null) {
            error = looks(d, p);
        }
        if (error == null) {
            error = equipment(d, p);
        }
        if (error == null) {
            error = abilities(d, p);
        }
        if (error == null) {
            error = bar(d, p);
        }
        if (error == null) {
            error = drops(d, p);
        }
        if (error == null) {
            error = spawning(d, p);
        }
        return error;
    }

    private String basics(MobDefinition d, FlagParser.Result p) {
        if (p.has("name")) {
            d.name = p.last("name");
        }
        if (p.has("tier")) {
            MobTier tier = MobTier.parse(p.last("tier"));
            if (tier == null) {
                return "--tier must be enemy, miniboss or boss.";
            }
            d.tier = tier;
            if (!p.has("persistent")) {
                d.persistent = tier != MobTier.ENEMY;
            }
            if (!p.has("bossbar")) {
                d.bossbar = tier == MobTier.BOSS;
            }
        }
        if (p.has("type")) {
            EntityType type = MobManager.resolveType(p.last("type"));
            if (!MobManager.isSpawnableMob(type)) {
                return "'" + p.last("type") + "' is not a living entity type that can be spawned (try zombie, skeleton, wither_skeleton, iron_golem).";
            }
            d.type = type.getKey().getKey();
        }
        return null;
    }

    private String stats(MobDefinition d, FlagParser.Result p) {
        String[][] shortcuts = {
            {"health", "max_health"}, {"damage", "attack_damage"}, {"speed", "movement_speed"}, {"armor", "armor"},
            {"toughness", "armor_toughness"}, {"knockback_resistance", "knockback_resistance"},
            {"follow_range", "follow_range"}, {"scale", "scale"}
        };
        for (String[] pair : shortcuts) {
            if (p.has(pair[0])) {
                String error = setAttribute(d, pair[1], p.last(pair[0]), "--" + pair[0]);
                if (error != null) {
                    return error;
                }
            }
        }
        if (p.has("attribute")) {
            for (String value : p.all("attribute")) {
                if (Parse.isClear(value)) {
                    d.attributes.clear();
                    continue;
                }
                String[] words = value.trim().split("\\s+");
                if (words.length != 2) {
                    return "--attribute looks like: max_health 300 (a name, then a number or a multiplier like 1.5x).";
                }
                String error = setAttribute(d, AttributeLine.normalizeName(words[0]), words[1], "--attribute " + words[0]);
                if (error != null) {
                    return error;
                }
            }
        }
        return null;
    }

    private static String setAttribute(MobDefinition d, String name, String value, String label) {
        if (AttributeLine.resolve(name) == null) {
            return "'" + name + "' is not an attribute.";
        }
        if (Parse.isClear(value)) {
            d.attributes.remove(name);
            return null;
        }
        String text = value.trim().toLowerCase(Locale.ROOT);
        String number = text.endsWith("x") ? text.substring(0, text.length() - 1) : text;
        Double parsed = Parse.number(number);
        if (parsed == null) {
            return label + " must be a number" + (name.equals("movement_speed") ? " or a multiplier like 1.5x." : ".");
        }
        d.attributes.put(name, text);
        return null;
    }

    private String looks(MobDefinition d, FlagParser.Result p) {
        if (p.has("size")) {
            Integer size = Parse.integer(p.last("size"));
            if (size == null || size < 1 || size > 127) {
                return "--size must be a whole number from 1 to 127.";
            }
            d.size = size;
        }
        String[] names = {"baby", "glow", "silent", "invulnerable", "invisible", "ai", "gravity", "persistent", "name_visible", "bossbar", "vanilla_drops"};
        for (String flag : names) {
            if (!p.has(flag)) {
                continue;
            }
            Boolean value = Parse.bool(p.last(flag));
            if (value == null) {
                return "--" + flag + " must be true or false.";
            }
            switch (flag) {
                case "baby" -> d.baby = value;
                case "glow" -> d.glow = value;
                case "silent" -> d.silent = value;
                case "invulnerable" -> d.invulnerable = value;
                case "invisible" -> d.invisible = value;
                case "ai" -> d.ai = value;
                case "gravity" -> d.gravity = value;
                case "persistent" -> d.persistent = value;
                case "name_visible" -> d.nameVisible = value;
                case "bossbar" -> d.bossbar = value;
                default -> d.vanillaDrops = value;
            }
        }
        return null;
    }

    private String equipment(MobDefinition d, FlagParser.Result p) {
        String[] slots = {"mainhand", "offhand", "helmet", "chestplate", "leggings", "boots"};
        for (String slot : slots) {
            if (!p.has(slot)) {
                continue;
            }
            String ref = p.last(slot).trim();
            String stored;
            if (Parse.isClear(ref)) {
                stored = null;
            } else {
                String lower = ref.toLowerCase(Locale.ROOT);
                Material material = Material.matchMaterial(ref);
                if (plugin.items().contains(lower)) {
                    stored = lower;
                } else if (material != null && material.isItem() && !material.isAir()) {
                    stored = material.name().toLowerCase(Locale.ROOT);
                } else {
                    return "--" + slot + " '" + ref + "' is neither a SuperItems item or armor id nor an item material (like diamond_sword).";
                }
            }
            switch (slot) {
                case "mainhand" -> d.mainhand = stored;
                case "offhand" -> d.offhand = stored;
                case "helmet" -> d.helmet = stored;
                case "chestplate" -> d.chestplate = stored;
                case "leggings" -> d.leggings = stored;
                default -> d.boots = stored;
            }
        }
        if (p.has("equipment_drop")) {
            Double percent = Parse.number(p.last("equipment_drop").replace("%", ""));
            if (percent == null || percent < 0 || percent > 100) {
                return "--equipment_drop must be a percent from 0 to 100.";
            }
            d.equipmentDrop = percent;
        }
        return null;
    }

    private String abilities(MobDefinition d, FlagParser.Result p) {
        if (p.has("effect")) {
            List<String> lines = Parse.entries(p.all("effect"));
            for (String line : lines) {
                String[] words = line.split("\\s+");
                if (!words[0].matches("[a-zA-Z0-9_:]+")) {
                    return "--effect looks like: strength 1 infinite (name, amplifier, seconds). Got '" + line + "'.";
                }
                if (words.length > 1 && (Parse.integer(words[1]) == null || Parse.integer(words[1]) < 0 || Parse.integer(words[1]) > 255)) {
                    return "The effect amplifier must be 0 to 255 in '" + line + "'.";
                }
                if (words.length > 2 && !words[2].equalsIgnoreCase("infinite") && (Parse.integer(words[2]) == null || Parse.integer(words[2]) < 1)) {
                    return "The effect duration must be seconds or infinite in '" + line + "'.";
                }
            }
            MobDefinition.assign(d.effects, lines);
        }
        if (p.has("rider")) {
            String id = p.last("rider").toLowerCase(Locale.ROOT);
            if (Parse.isClear(id)) {
                d.rider = null;
            } else if (id.equals(d.id)) {
                return "A mob cannot ride itself.";
            } else if (!plugin.mobs().contains(id)) {
                return "No mob called '" + id + "' to use as a rider. Create it first.";
            } else {
                d.rider = id;
            }
        }
        setList(p, "on_spawn", d.onSpawn);
        setList(p, "on_hit", d.onHit);
        setList(p, "on_damaged", d.onDamaged);
        setList(p, "on_death", d.onDeath);
        setList(p, "on_kill", d.onKill);
        String error = numbered(p, "timer", d.timers, 0.5, Double.MAX_VALUE, "seconds");
        if (error == null) {
            error = numbered(p, "phase", d.phases, 0, 100, "health percent");
        }
        if (error != null) {
            return error;
        }
        if (p.has("trigger_cooldown")) {
            Double seconds = Parse.number(p.last("trigger_cooldown"));
            if (seconds == null || seconds < 0) {
                return "--trigger_cooldown must be 0 or more seconds.";
            }
            d.triggerCooldown = seconds;
        }
        if (p.has("active_range")) {
            Double range = Parse.number(p.last("active_range"));
            if (range == null || range < 0) {
                return "--active_range must be 0 or more blocks (0 means always).";
            }
            d.activeRange = range;
        }
        return null;
    }

    private static void setList(FlagParser.Result p, String flag, List<String> target) {
        if (p.has(flag)) {
            MobDefinition.assign(target, Parse.entries(p.all(flag)));
        }
    }

    private static String numbered(FlagParser.Result p, String flag, List<String> target, double min, double max, String what) {
        if (!p.has(flag)) {
            return null;
        }
        List<String> lines = Parse.entries(p.all(flag));
        for (String line : lines) {
            NumberedCommand parsed = NumberedCommand.parse(line);
            if (parsed == null || parsed.number() < min || parsed.number() > max) {
                return "--" + flag + " lines look like: <" + what + "> <command>. Got '" + line + "'.";
            }
        }
        MobDefinition.assign(target, lines);
        return null;
    }

    private String bar(MobDefinition d, FlagParser.Result p) {
        if (p.has("bar_color")) {
            if (MobManager.parseColor(p.last("bar_color")) == null) {
                return "--bar_color must be pink, blue, red, green, yellow, purple or white.";
            }
            d.barColor = p.last("bar_color").toLowerCase(Locale.ROOT);
        }
        if (p.has("bar_style")) {
            if (MobManager.parseOverlay(p.last("bar_style")) == null) {
                return "--bar_style must be progress, 6, 10, 12 or 20.";
            }
            d.barStyle = p.last("bar_style").toLowerCase(Locale.ROOT);
        }
        if (p.has("bar_range")) {
            Double range = Parse.number(p.last("bar_range"));
            if (range == null || range < 1) {
                return "--bar_range must be at least 1 block.";
            }
            d.barRange = range;
        }
        if (p.has("bar_title")) {
            d.barTitle = Parse.isClear(p.last("bar_title")) ? null : p.last("bar_title");
        }
        return null;
    }

    private String drops(MobDefinition d, FlagParser.Result p) {
        if (p.has("loot")) {
            List<String> ids = new ArrayList<>();
            for (String value : p.all("loot")) {
                if (Parse.isClear(value)) {
                    ids.clear();
                    continue;
                }
                for (String id : Parse.commaList(value.replace(' ', ','))) {
                    String lower = id.toLowerCase(Locale.ROOT);
                    if (!plugin.loot().contains(lower)) {
                        return "No loot table called '" + lower + "'. Create it first with /superitems loot create.";
                    }
                    ids.add(lower);
                }
            }
            MobDefinition.assign(d.loot, ids);
        }
        if (p.has("xp")) {
            if (Parse.isClear(p.last("xp"))) {
                d.xp = null;
            } else {
                Range range = Range.parse(p.last("xp"));
                if (range == null || range.min() < 0) {
                    return "--xp must be a number or range like 50-100.";
                }
                d.xp = range;
            }
        }
        return null;
    }

    private String spawning(MobDefinition d, FlagParser.Result p) {
        if (p.has("spawn_message")) {
            d.spawnMessage = Parse.isClear(p.last("spawn_message")) ? null : p.last("spawn_message");
        }
        if (p.has("death_message")) {
            d.deathMessage = Parse.isClear(p.last("death_message")) ? null : p.last("death_message");
        }
        if (p.has("announce")) {
            String mode = p.last("announce").toLowerCase(Locale.ROOT);
            if (!List.of("world", "server", "none").contains(mode)) {
                return "--announce must be world, server or none.";
            }
            d.announce = mode;
        }
        if (p.has("replace")) {
            String text = p.last("replace").trim();
            if (Parse.isClear(text)) {
                d.replaceType = null;
                d.replaceChance = 0;
            } else {
                String[] words = text.split("\\s+");
                EntityType type = MobManager.resolveType(words[0]);
                Double chance = words.length > 1 ? Parse.number(words[1].replace("%", "")) : Double.valueOf(100);
                if (!MobManager.isSpawnableMob(type)) {
                    return "--replace '" + words[0] + "' is not a living entity type.";
                }
                if (chance == null || chance <= 0 || chance > 100) {
                    return "--replace looks like: zombie 5 (an entity type, then a percent chance from 0 to 100).";
                }
                d.replaceType = type.getKey().getKey();
                d.replaceChance = chance;
            }
        }
        if (p.has("worlds")) {
            MobDefinition.assign(d.worlds, Parse.commaList(p.last("worlds")));
        }
        return null;
    }

    @Override
    public MobDefinition get(String id) {
        return plugin.mobs().get(id);
    }

    @Override
    public boolean contains(String id) {
        return plugin.mobs().contains(id);
    }

    @Override
    public void put(MobDefinition definition) {
        plugin.mobs().put(definition);
    }

    @Override
    public boolean remove(String id) {
        return plugin.mobs().remove(id);
    }

    @Override
    public List<String> ids() {
        return plugin.mobs().ids();
    }

    @Override
    public Collection<MobDefinition> all() {
        return plugin.mobs().all();
    }

    @Override
    public String idOf(MobDefinition definition) {
        return definition.id;
    }

    @Override
    public List<String> infoLines(MobDefinition d) {
        List<String> lines = new ArrayList<>();
        lines.add("name: " + d.name + " | tier: " + d.tier.text() + " | type: " + d.type);
        lines.add("attributes: " + (d.attributes.isEmpty() ? "(vanilla)" : d.attributes.toString()));
        lines.add("flags: ai=" + d.ai + " gravity=" + d.gravity + " persistent=" + d.persistent + " glow=" + d.glow
                + " silent=" + d.silent + " invulnerable=" + d.invulnerable + " invisible=" + d.invisible + " baby=" + d.baby
                + (d.size > 0 ? " size=" + d.size : ""));
        lines.add("gear: main=" + d.mainhand + " off=" + d.offhand + " head=" + d.helmet + " chest=" + d.chestplate
                + " legs=" + d.leggings + " feet=" + d.boots + " (drop " + d.equipmentDrop + "%)");
        lines.add("effects: " + (d.effects.isEmpty() ? "(none)" : String.join(" ; ", d.effects)) + " | rider: " + d.rider);
        lines.add("on spawn: " + show(d.onSpawn) + " | on hit: " + show(d.onHit) + " | on damaged: " + show(d.onDamaged));
        lines.add("on death: " + show(d.onDeath) + " | on kill: " + show(d.onKill));
        lines.add("timers: " + show(d.timers) + " | phases: " + show(d.phases));
        lines.add("trigger cooldown: " + d.triggerCooldown + "s, active range: " + d.activeRange);
        lines.add("boss bar: " + d.bossbar + (d.bossbar ? " (" + d.barColor + ", " + d.barStyle + ", range " + d.barRange + ")" : ""));
        lines.add("loot: " + (d.loot.isEmpty() ? "(none)" : String.join(", ", d.loot)) + " | xp: " + (d.xp == null ? "vanilla" : d.xp.show())
                + " | vanilla drops: " + d.vanillaDrops);
        lines.add("messages (" + d.announce + "): spawn=" + d.spawnMessage + " death=" + d.deathMessage);
        lines.add("natural replacement: " + (d.replaceType == null ? "(off)" : d.replaceType + " " + d.replaceChance + "% in "
                + (d.worlds.isEmpty() ? "all worlds" : String.join(",", d.worlds))));
        lines.add("alive now: " + plugin.manager().all().stream().filter(mob -> mob.id().equals(d.id)).count());
        return lines;
    }

    private static String show(List<String> values) {
        return values.isEmpty() ? "(none)" : String.join(" ;; ", values);
    }

    @Override
    public String summary(MobDefinition d) {
        return "(" + d.tier.text() + " " + d.type + ", " + d.loot.size() + " loot table(s))";
    }

    @Override
    public boolean save(CommandSender sender) {
        return plugin.saveMobs(sender);
    }

    @Override
    public void changed() {
        plugin.manager().rebind();
    }
}
