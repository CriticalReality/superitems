package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.mob.MobDefinition;
import dev.superitems.mob.MobManager;
import dev.superitems.util.Parse;
import dev.superitems.util.Text;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;

/** Spawns custom mobs. */
public final class MobSpawnSubcommand implements Subcommand {
    private static final int MAX_AMOUNT = 50;

    private final SuperItems plugin;

    /** Creates the subcommand. */
    public MobSpawnSubcommand(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String name() {
        return "spawn";
    }

    @Override
    public String usage() {
        return "spawn <id> [amount] [world x y z]";
    }

    @Override
    public String description() {
        return "Spawn a mob where you stand, or at a place";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (args.length == 0) {
            Text.error(sender, "Usage: /superitems mob " + usage());
            return;
        }
        String id = args[0].toLowerCase(Locale.ROOT);
        MobDefinition definition = plugin.mobs().get(id);
        if (definition == null) {
            Text.error(sender, "No mob called '" + id + "'. See /superitems mob list");
            return;
        }
        int amount = 1;
        int placeStart = 1;
        if (args.length >= 2 && Parse.integer(args[1]) != null) {
            amount = Parse.integer(args[1]);
            placeStart = 2;
        }
        if (amount < 1 || amount > MAX_AMOUNT) {
            Text.error(sender, "Amount must be between 1 and " + MAX_AMOUNT + ".");
            return;
        }
        Targets.Place place = Targets.place(plugin, sender, args, placeStart);
        if (place.error() != null) {
            Text.error(sender, place.error());
            return;
        }
        int spawned = 0;
        for (int i = 0; i < amount; i++) {
            MobManager.SpawnResult result = plugin.manager().spawn(definition, place.location(), null);
            if (!result.ok()) {
                Text.error(sender, result.error());
                break;
            }
            spawned++;
        }
        if (spawned > 0) {
            Text.ok(sender, "Spawned " + spawned + "x '" + id + "'.");
        }
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        String typed = args.length == 0 ? "" : args[args.length - 1];
        if (args.length <= 1) {
            return Subcommand.match(plugin.mobs().ids(), typed);
        }
        if (args.length == 2) {
            return Subcommand.match(List.of("1", "3", "5"), typed);
        }
        return List.of();
    }
}
