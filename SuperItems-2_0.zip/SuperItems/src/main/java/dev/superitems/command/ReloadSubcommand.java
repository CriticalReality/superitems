package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.util.Text;
import org.bukkit.command.CommandSender;

/** Reloads config.yml and every data file from disk. */
public final class ReloadSubcommand implements Subcommand {
    private final SuperItems plugin;

    /** Creates the subcommand. */
    public ReloadSubcommand(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String name() {
        return "reload";
    }

    @Override
    public String usage() {
        return "reload";
    }

    @Override
    public String description() {
        return "Reload config.yml, items.yml, sets.yml, mobs.yml, loot.yml and spawners.yml";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        plugin.reloadAll();
        Text.ok(sender, "Reloaded " + plugin.items().ids().size() + " item(s), " + plugin.sets().ids().size() + " set(s), "
                + plugin.mobs().ids().size() + " mob(s), " + plugin.loot().ids().size() + " loot table(s) and "
                + plugin.spawners().ids().size() + " spawner(s).");
    }
}
