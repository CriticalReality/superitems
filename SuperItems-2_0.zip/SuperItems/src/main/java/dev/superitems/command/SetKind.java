package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.action.NumberedCommand;
import dev.superitems.item.ArmorSet;
import dev.superitems.util.Parse;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;

/** Armor sets: pieces that give bonuses when worn together. */
public final class SetKind implements Kind<ArmorSet> {
    private static final String CREATE_USAGE = "create <id> --pieces item1,item2,item3,item4 [--name text] [--description text] "
            + "[--bonus \"count command\"] [--on_activate \"count command\"] [--on_deactivate \"count command\"] [--interval seconds]";

    private final SuperItems plugin;

    /** Creates the kind. */
    public SetKind(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String noun() {
        return "set";
    }

    @Override
    public String prefix() {
        return "/superitems set";
    }

    @Override
    public FlagSpec spec() {
        return Specs.SET;
    }

    @Override
    public String createUsage() {
        return CREATE_USAGE;
    }

    @Override
    public ArmorSet blank(String id) {
        return new ArmorSet(id, id);
    }

    @Override
    public ArmorSet copy(ArmorSet definition) {
        return definition.copy();
    }

    @Override
    public String apply(ArmorSet d, FlagParser.Result p, CommandSender sender) {
        if (p.has("name")) {
            d.setName(p.last("name"));
        }
        if (p.has("pieces")) {
            List<String> ids = new ArrayList<>();
            for (String value : p.all("pieces")) {
                for (String id : Parse.commaList(value.replace(' ', ','))) {
                    String lower = id.toLowerCase(Locale.ROOT);
                    if (!plugin.items().contains(lower)) {
                        return "No item called '" + lower + "'. Create it first with /superitems create or /superitems armor create.";
                    }
                    if (!ids.contains(lower)) {
                        ids.add(lower);
                    }
                }
            }
            d.setPieces(ids);
        }
        if (p.has("description")) {
            d.setDescription(Parse.lines(p.all("description")));
        }
        String error = numbered(p, "bonus", d::setBonus);
        if (error == null) {
            error = numbered(p, "on_activate", d::setOnActivate);
        }
        if (error == null) {
            error = numbered(p, "on_deactivate", d::setOnDeactivate);
        }
        if (error != null) {
            return error;
        }
        if (p.has("interval")) {
            Double seconds = Parse.number(p.last("interval"));
            if (seconds == null || seconds < 0.5) {
                return "--interval must be at least 0.5 seconds.";
            }
            d.setInterval(seconds);
        }
        return null;
    }

    private static String numbered(FlagParser.Result p, String flag, java.util.function.Consumer<List<String>> setter) {
        if (!p.has(flag)) {
            return null;
        }
        List<String> lines = Parse.entries(p.all(flag));
        for (String line : lines) {
            NumberedCommand parsed = NumberedCommand.parse(line);
            if (parsed == null || parsed.number() < 1 || parsed.number() != Math.rint(parsed.number())) {
                return "--" + flag + " lines look like: 2 effect give @s minecraft:speed 3 0 true (a whole number of pieces, then the command). Got '" + line + "'.";
            }
        }
        setter.accept(lines);
        return null;
    }

    @Override
    public String validate(ArmorSet definition) {
        return definition.getPieces().isEmpty() ? "A set needs --pieces, for example --pieces helm,chest,legs,boots." : null;
    }

    @Override
    public ArmorSet get(String id) {
        return plugin.sets().get(id);
    }

    @Override
    public boolean contains(String id) {
        return plugin.sets().contains(id);
    }

    @Override
    public void put(ArmorSet definition) {
        plugin.sets().put(definition);
    }

    @Override
    public boolean remove(String id) {
        return plugin.sets().remove(id);
    }

    @Override
    public List<String> ids() {
        return plugin.sets().ids();
    }

    @Override
    public Collection<ArmorSet> all() {
        return plugin.sets().all();
    }

    @Override
    public String idOf(ArmorSet definition) {
        return definition.getId();
    }

    @Override
    public List<String> infoLines(ArmorSet d) {
        List<String> lines = new ArrayList<>();
        lines.add("name: " + d.getName());
        lines.add("pieces: " + String.join(", ", d.getPieces()));
        lines.add("description: " + (d.getDescription().isEmpty() ? "(none)" : String.join(" | ", d.getDescription())));
        lines.add("bonus (every " + d.getInterval() + "s): " + (d.getBonus().isEmpty() ? "(nothing)" : String.join(" ;; ", d.getBonus())));
        lines.add("on activate: " + (d.getOnActivate().isEmpty() ? "(nothing)" : String.join(" ;; ", d.getOnActivate())));
        lines.add("on deactivate: " + (d.getOnDeactivate().isEmpty() ? "(nothing)" : String.join(" ;; ", d.getOnDeactivate())));
        return lines;
    }

    @Override
    public String summary(ArmorSet d) {
        return "(" + d.getPieces().size() + " pieces, " + d.getBonus().size() + " bonus line(s))";
    }

    @Override
    public boolean save(CommandSender sender) {
        return plugin.saveSets(sender);
    }

    @Override
    public String createdMessage(String id) {
        return "Created set '" + id + "'. Pieces show the set in their lore the next time they are given.";
    }
}
