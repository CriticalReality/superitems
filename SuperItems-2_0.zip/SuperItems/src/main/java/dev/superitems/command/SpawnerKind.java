package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.spawner.SpawnerDefinition;
import dev.superitems.util.Parse;
import java.util.Collection;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/** Spawner points that keep spawning a custom mob. */
public final class SpawnerKind implements Kind<SpawnerDefinition> {
    private static final String CREATE_USAGE = "create <id> --mob <mobId> (--here | --location x y z [world]) [--interval seconds] "
            + "[--amount n] [--max n] [--radius blocks] [--range blocks] [--enabled true|false]";

    private final SuperItems plugin;

    /** Creates the kind. */
    public SpawnerKind(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String noun() {
        return "spawner";
    }

    @Override
    public String prefix() {
        return "/superitems spawner";
    }

    @Override
    public FlagSpec spec() {
        return Specs.SPAWNER;
    }

    @Override
    public String createUsage() {
        return CREATE_USAGE;
    }

    @Override
    public SpawnerDefinition blank(String id) {
        SpawnerDefinition d = new SpawnerDefinition(id);
        d.world = null;
        return d;
    }

    @Override
    public SpawnerDefinition copy(SpawnerDefinition definition) {
        return definition.copy();
    }

    @Override
    public String apply(SpawnerDefinition d, FlagParser.Result p, CommandSender sender) {
        if (p.has("mob")) {
            String id = p.last("mob").toLowerCase(java.util.Locale.ROOT);
            if (!plugin.mobs().contains(id)) {
                return "No mob called '" + id + "'. Create it first with /superitems mob create.";
            }
            d.mob = id;
        }
        if (p.has("here")) {
            if (!(sender instanceof Player player)) {
                return "--here only works for players. Use --location x y z world.";
            }
            Location at = player.getLocation();
            d.world = at.getWorld().getName();
            d.x = at.getX();
            d.y = at.getY();
            d.z = at.getZ();
        }
        if (p.has("location")) {
            String[] words = p.last("location").trim().split("\\s+");
            if (words.length < 3) {
                return "--location needs x y z and, from the console, a world name.";
            }
            Double x = Parse.number(words[0]);
            Double y = Parse.number(words[1]);
            Double z = Parse.number(words[2]);
            if (x == null || y == null || z == null) {
                return "--location coordinates must be numbers.";
            }
            String worldName = words.length > 3 ? words[3] : (sender instanceof Player player ? player.getWorld().getName() : null);
            if (worldName == null) {
                return "The console must add a world name: --location x y z world.";
            }
            World world = plugin.getServer().getWorld(worldName);
            if (world == null) {
                return "No loaded world called '" + worldName + "'.";
            }
            d.world = world.getName();
            d.x = x;
            d.y = y;
            d.z = z;
        }
        if (p.has("interval")) {
            Double value = Parse.number(p.last("interval"));
            if (value == null || value < 1) {
                return "--interval must be at least 1 second.";
            }
            d.interval = value;
        }
        if (p.has("amount")) {
            Integer value = Parse.integer(p.last("amount"));
            if (value == null || value < 1 || value > 50) {
                return "--amount must be a whole number from 1 to 50.";
            }
            d.amount = value;
        }
        if (p.has("max")) {
            Integer value = Parse.integer(p.last("max"));
            if (value == null || value < 1 || value > 500) {
                return "--max must be a whole number from 1 to 500.";
            }
            d.max = value;
        }
        if (p.has("radius")) {
            Double value = Parse.number(p.last("radius"));
            if (value == null || value < 0) {
                return "--radius must be 0 or more.";
            }
            d.radius = value;
        }
        if (p.has("range")) {
            Double value = Parse.number(p.last("range"));
            if (value == null || value < 0) {
                return "--range must be 0 or more (0 means always active).";
            }
            d.range = value;
        }
        if (p.has("enabled")) {
            Boolean value = Parse.bool(p.last("enabled"));
            if (value == null) {
                return "--enabled must be true or false.";
            }
            d.enabled = value;
        }
        return null;
    }

    @Override
    public String validate(SpawnerDefinition d) {
        if (d.mob == null) {
            return "A spawner needs --mob <mobId>.";
        }
        if (d.world == null) {
            return "A spawner needs a place: --here or --location x y z world.";
        }
        return null;
    }

    @Override
    public SpawnerDefinition get(String id) {
        return plugin.spawners().get(id);
    }

    @Override
    public boolean contains(String id) {
        return plugin.spawners().contains(id);
    }

    @Override
    public void put(SpawnerDefinition definition) {
        plugin.spawners().put(definition);
    }

    @Override
    public boolean remove(String id) {
        return plugin.spawners().remove(id);
    }

    @Override
    public List<String> ids() {
        return plugin.spawners().ids();
    }

    @Override
    public Collection<SpawnerDefinition> all() {
        return plugin.spawners().all();
    }

    @Override
    public String idOf(SpawnerDefinition definition) {
        return definition.id;
    }

    @Override
    public List<String> infoLines(SpawnerDefinition d) {
        return List.of(
                "mob: " + d.mob + ", enabled: " + d.enabled,
                "place: " + d.world + " " + Math.round(d.x * 10) / 10.0 + " " + Math.round(d.y * 10) / 10.0 + " " + Math.round(d.z * 10) / 10.0,
                "every " + d.interval + "s spawn " + d.amount + ", at most " + d.max + " alive, scatter " + d.radius + " blocks",
                "only while a player is within " + d.range + " blocks (0 = always)",
                "alive now: " + plugin.manager().countFromSpawner(d.id));
    }

    @Override
    public String summary(SpawnerDefinition d) {
        return "(" + d.mob + " in " + d.world + ", " + (d.enabled ? "on" : "off") + ")";
    }

    @Override
    public boolean save(CommandSender sender) {
        return plugin.saveSpawners(sender);
    }

    @Override
    public void changed() {
        plugin.spawnerTask().reset();
    }
}
