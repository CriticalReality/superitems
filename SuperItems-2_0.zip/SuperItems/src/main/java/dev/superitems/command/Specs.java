package dev.superitems.command;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import org.bukkit.Material;
import org.bukkit.Registry;
import org.bukkit.entity.EntityType;

/** The flags of every kind of definition. */
public final class Specs {
    private static final String[] BOOL = {"true", "false"};

    /** Flags for items and armor. */
    public static final FlagSpec ITEM = new FlagSpec()
            .flag("name")
            .flag("description", "lore")
            .flag("material")
            .flag("model")
            .flag("glow")
            .flag("on_right_click", "right")
            .flag("on_left_click", "left")
            .flag("consume")
            .flag("cooldown")
            .flag("cancel")
            .flag("unbreakable")
            .flag("attribute", "attr")
            .flag("color")
            .flag("damage")
            .flag("on_hit")
            .flag("on_damaged", "on_hit_taken")
            .flag("on_equip")
            .flag("on_unequip")
            .flag("while_worn")
            .flag("interval")
            .flag("trigger_cooldown")
            .flag("piece")
            .flag("tier")
            .flag("armor")
            .flag("toughness")
            .flag("health")
            .flag("speed")
            .flag("knockback_resistance", "kb_resist")
            .bare("glow", "cancel", "unbreakable")
            .hint("material", Specs::itemNames)
            .hint("consume", "none", "right", "left", "both")
            .hint("glow", BOOL)
            .hint("cancel", BOOL)
            .hint("unbreakable", BOOL)
            .hint("model", "minecraft:", "none")
            .hint("attribute", () -> attributeNames().stream().map(name -> name + " ").toList())
            .hint("piece", "helmet", "chestplate", "leggings", "boots")
            .hint("tier", "leather", "chainmail", "iron", "golden", "diamond", "netherite", "turtle")
            .hint("on_right_click", Specs::commandStarts)
            .hint("on_left_click", Specs::commandStarts)
            .hint("on_hit", Specs::commandStarts)
            .hint("on_damaged", Specs::commandStarts)
            .hint("on_equip", Specs::commandStarts)
            .hint("on_unequip", Specs::commandStarts)
            .hint("while_worn", Specs::commandStarts);

    /** Flags for armor sets. */
    public static final FlagSpec SET = new FlagSpec()
            .flag("name")
            .flag("pieces")
            .flag("description", "lore")
            .flag("bonus")
            .flag("on_activate")
            .flag("on_deactivate")
            .flag("interval");

    /** Flags for loot tables. */
    public static final FlagSpec LOOT = new FlagSpec()
            .flag("name")
            .flag("rolls")
            .flag("chance")
            .flag("entry")
            .flag("always")
            .flag("deliver")
            .hint("deliver", "drop", "inventory")
            .hint("entry", "10 item:", "10 vanilla:", "10 table:", "10 command:", "10 nothing");

    /** Flags for mobs. */
    public static final FlagSpec MOB = new FlagSpec()
            .flag("name")
            .flag("tier")
            .flag("type", "entity")
            .flag("health")
            .flag("damage")
            .flag("speed")
            .flag("armor")
            .flag("toughness")
            .flag("knockback_resistance", "kb_resist")
            .flag("follow_range")
            .flag("scale")
            .flag("attribute", "attr")
            .flag("size")
            .flag("baby")
            .flag("glow")
            .flag("silent")
            .flag("invulnerable")
            .flag("invisible")
            .flag("ai")
            .flag("gravity")
            .flag("persistent")
            .flag("name_visible")
            .flag("mainhand")
            .flag("offhand")
            .flag("helmet")
            .flag("chestplate")
            .flag("leggings")
            .flag("boots")
            .flag("equipment_drop")
            .flag("effect")
            .flag("rider")
            .flag("on_spawn")
            .flag("on_hit")
            .flag("on_damaged")
            .flag("on_death")
            .flag("on_kill")
            .flag("timer")
            .flag("phase")
            .flag("trigger_cooldown")
            .flag("active_range")
            .flag("bossbar")
            .flag("bar_color")
            .flag("bar_style")
            .flag("bar_range")
            .flag("bar_title")
            .flag("loot")
            .flag("xp")
            .flag("vanilla_drops")
            .flag("spawn_message")
            .flag("death_message")
            .flag("announce")
            .flag("replace")
            .flag("worlds")
            .bare("baby", "glow", "silent", "invulnerable", "invisible", "ai", "gravity", "persistent", "name_visible",
                    "bossbar", "vanilla_drops")
            .hint("tier", "enemy", "miniboss", "boss")
            .hint("type", Specs::entityTypes)
            .hint("attribute", () -> attributeNames().stream().map(name -> name + " ").toList())
            .hint("mainhand", Specs::itemNames)
            .hint("offhand", Specs::itemNames)
            .hint("helmet", Specs::itemNames)
            .hint("chestplate", Specs::itemNames)
            .hint("leggings", Specs::itemNames)
            .hint("boots", Specs::itemNames)
            .hint("bar_color", "pink", "blue", "red", "green", "yellow", "purple", "white")
            .hint("bar_style", "progress", "6", "10", "12", "20")
            .hint("announce", "world", "server", "none")
            .hint("baby", BOOL)
            .hint("glow", BOOL)
            .hint("ai", BOOL)
            .hint("bossbar", BOOL)
            .hint("vanilla_drops", BOOL)
            .hint("replace", () -> entityTypes().stream().map(name -> name + " ").toList())
            .hint("on_spawn", Specs::commandStarts)
            .hint("on_hit", Specs::commandStarts)
            .hint("on_damaged", Specs::commandStarts)
            .hint("on_death", Specs::commandStarts)
            .hint("on_kill", Specs::commandStarts);

    /** Flags for spawner points. */
    public static final FlagSpec SPAWNER = new FlagSpec()
            .flag("mob")
            .flag("location", "at")
            .flag("here")
            .flag("interval")
            .flag("amount")
            .flag("max")
            .flag("radius")
            .flag("range")
            .flag("enabled")
            .bare("here", "enabled")
            .hint("enabled", BOOL);

    private Specs() {}

    private static List<String> commandStarts() {
        return List.of("effect", "playsound", "particle", "title", "say", "give", "tp", "summon", "execute", "damage",
                "player:", "raw:", "target:");
    }

    private static List<String> itemNames() {
        return Arrays.stream(Material.values())
                .filter(material -> material.isItem() && !material.isLegacy() && !material.isAir())
                .map(material -> material.name().toLowerCase(Locale.ROOT))
                .toList();
    }

    /** Names of entity types that can be spawned as living mobs. */
    static List<String> entityTypes() {
        return Registry.ENTITY_TYPE.stream()
                .filter(type -> type != EntityType.UNKNOWN && type.isSpawnable() && type.isAlive())
                .map(type -> type.getKey().getKey())
                .toList();
    }

    /** Names of attributes. */
    static List<String> attributeNames() {
        return Registry.ATTRIBUTE.stream().map(attribute -> attribute.getKey().getKey()).toList();
    }
}
