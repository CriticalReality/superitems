package dev.superitems.command;

import java.util.Collection;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;

/** One /superitems subcommand. Each subcommand lives in its own class. */
public interface Subcommand {
    /** The word typed after /superitems. */
    String name();

    /** Usage text without the leading command. */
    String usage();

    /** One line describing what it does. */
    String description();

    /** Runs the subcommand. The arguments do not include the subcommand name. */
    void execute(CommandSender sender, String[] args);

    /** Tab completion for the arguments after the subcommand name. */
    default List<String> complete(CommandSender sender, String[] args) {
        return List.of();
    }

    /** Filters options by what has been typed so far. */
    static List<String> match(Collection<String> options, String typed) {
        String lower = typed.toLowerCase(Locale.ROOT);
        return options.stream()
                .filter(option -> option.toLowerCase(Locale.ROOT).startsWith(lower))
                .sorted()
                .limit(50)
                .toList();
    }
}
