package dev.superitems.command;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;

/** Routes /superitems to the matching subcommand. */
public final class SuperItemsCommand implements TabExecutor {
    private final Map<String, Subcommand> subcommands = new LinkedHashMap<>();

    /** Creates the router for the given subcommands. */
    public SuperItemsCommand(List<Subcommand> list) {
        for (Subcommand subcommand : list) {
            subcommands.put(subcommand.name(), subcommand);
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Subcommand subcommand = args.length == 0 ? null : subcommands.get(args[0].toLowerCase(Locale.ROOT));
        if (subcommand == null) {
            sendHelp(sender, label);
            return true;
        }
        subcommand.execute(sender, Arrays.copyOfRange(args, 1, args.length));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length <= 1) {
            return Subcommand.match(subcommands.keySet(), args.length == 0 ? "" : args[0]);
        }
        Subcommand subcommand = subcommands.get(args[0].toLowerCase(Locale.ROOT));
        if (subcommand == null) {
            return List.of();
        }
        return subcommand.complete(sender, Arrays.copyOfRange(args, 1, args.length));
    }

    private void sendHelp(CommandSender sender, String label) {
        sender.sendMessage(Component.text("SuperItems commands (type a group name alone to see its commands):", NamedTextColor.GOLD));
        for (Subcommand subcommand : subcommands.values()) {
            String usage = subcommand.usage();
            int space = usage.indexOf(' ');
            String shown = subcommand instanceof GroupSubcommand || usage.length() < 60 ? usage : usage.substring(0, space < 0 ? usage.length() : space) + " ...";
            sender.sendMessage(Component.text("/" + label + " " + shown, NamedTextColor.YELLOW)
                    .append(Component.text(" - " + subcommand.description(), NamedTextColor.GRAY)));
        }
    }
}
