package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.util.Parse;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/** Reads a place from command words: nothing (the player's own spot) or world x y z. */
final class Targets {
    private Targets() {}

    /** Result of reading a place: the location, or an error message. */
    record Place(Location location, String error) {}

    /** Reads a place starting at the given word index. */
    static Place place(SuperItems plugin, CommandSender sender, String[] args, int start) {
        if (args.length <= start) {
            if (sender instanceof Player player) {
                return new Place(player.getLocation(), null);
            }
            return new Place(null, "The console must give a place: <world> <x> <y> <z>.");
        }
        if (args.length < start + 4) {
            return new Place(null, "A place looks like: <world> <x> <y> <z>.");
        }
        World world = plugin.getServer().getWorld(args[start]);
        if (world == null) {
            return new Place(null, "No loaded world called '" + args[start] + "'.");
        }
        Double x = Parse.number(args[start + 1]);
        Double y = Parse.number(args[start + 2]);
        Double z = Parse.number(args[start + 3]);
        if (x == null || y == null || z == null) {
            return new Place(null, "The coordinates must be numbers.");
        }
        return new Place(new Location(world, x, y, z), null);
    }
}
