package dev.superitems.item;

import java.util.List;
import java.util.Locale;
import org.bukkit.Material;
import org.bukkit.inventory.EquipmentSlotGroup;

/** Helpers that know which materials are worn and how a tier and piece make a material. */
public final class Armor {
    /** The four armor pieces. */
    public static final List<String> PIECES = List.of("helmet", "chestplate", "leggings", "boots");

    private Armor() {}

    /** Returns the piece name (helmet, chestplate, leggings, boots) a material is worn as, or null. */
    public static String pieceOf(Material material) {
        String name = material.name();
        if (name.endsWith("_HELMET") || name.endsWith("_HEAD") || name.endsWith("_SKULL") || name.equals("CARVED_PUMPKIN")) {
            return "helmet";
        }
        if (name.endsWith("_CHESTPLATE") || name.equals("ELYTRA")) {
            return "chestplate";
        }
        if (name.endsWith("_LEGGINGS")) {
            return "leggings";
        }
        if (name.endsWith("_BOOTS")) {
            return "boots";
        }
        return null;
    }

    /** True when the material can be worn in an armor slot. */
    public static boolean isWearable(Material material) {
        return pieceOf(material) != null;
    }

    /** The equipment slot group an item of this material works in. Worn pieces use their slot, everything else the main hand. */
    public static EquipmentSlotGroup slotGroupOf(Material material) {
        String piece = pieceOf(material);
        if (piece == null) {
            return EquipmentSlotGroup.MAINHAND;
        }
        return switch (piece) {
            case "helmet" -> EquipmentSlotGroup.HEAD;
            case "chestplate" -> EquipmentSlotGroup.CHEST;
            case "leggings" -> EquipmentSlotGroup.LEGS;
            default -> EquipmentSlotGroup.FEET;
        };
    }

    /** Makes a material from a tier word and a piece word, such as diamond + helmet. Returns null when there is no such item. */
    public static Material materialFor(String tier, String piece) {
        String tierName = tier.trim().toLowerCase(Locale.ROOT);
        String pieceName = piece.trim().toLowerCase(Locale.ROOT);
        if (!PIECES.contains(pieceName)) {
            return null;
        }
        if (tierName.equals("gold")) {
            tierName = "golden";
        } else if (tierName.equals("chain")) {
            tierName = "chainmail";
        }
        Material material = Material.matchMaterial(tierName + "_" + pieceName);
        return material != null && isWearable(material) ? material : null;
    }

    /** Returns the tier word of an existing armor material (diamond for DIAMOND_HELMET), or null. */
    public static String tierOf(Material material) {
        String piece = pieceOf(material);
        if (piece == null) {
            return null;
        }
        String name = material.name().toLowerCase(Locale.ROOT);
        String suffix = "_" + piece;
        return name.endsWith(suffix) ? name.substring(0, name.length() - suffix.length()) : null;
    }
}
