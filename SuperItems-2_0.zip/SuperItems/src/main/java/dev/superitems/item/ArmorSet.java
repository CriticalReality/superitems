package dev.superitems.item;

import dev.superitems.action.NumberedCommand;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * A group of items that give bonuses when several are worn together.
 * Bonus lines look like "2 effect give @s speed 3 0 true": the number is how many pieces must be worn.
 */
public final class ArmorSet {
    private final String id;
    private String name;
    private final List<String> pieces = new ArrayList<>();
    private final List<String> description = new ArrayList<>();
    private final List<String> bonus = new ArrayList<>();
    private final List<String> onActivate = new ArrayList<>();
    private final List<String> onDeactivate = new ArrayList<>();
    private double interval = 2;

    /** Creates an empty set. */
    public ArmorSet(String id, String name) {
        this.id = id;
        this.name = name;
    }

    /** Returns an independent copy. */
    public ArmorSet copy() {
        ArmorSet other = new ArmorSet(id, name);
        other.setPieces(pieces);
        other.setDescription(description);
        other.setBonus(bonus);
        other.setOnActivate(onActivate);
        other.setOnDeactivate(onDeactivate);
        other.interval = interval;
        return other;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /** Ids of the items that belong to the set. */
    public List<String> getPieces() {
        return Collections.unmodifiableList(pieces);
    }

    public void setPieces(List<String> ids) {
        List<String> copy = new ArrayList<>(ids);
        pieces.clear();
        pieces.addAll(copy);
    }

    /** Lore lines added to every piece. */
    public List<String> getDescription() {
        return Collections.unmodifiableList(description);
    }

    public void setDescription(List<String> lines) {
        List<String> copy = new ArrayList<>(lines);
        description.clear();
        description.addAll(copy);
    }

    /** Lines "count command" that repeat while that many pieces are worn. */
    public List<String> getBonus() {
        return Collections.unmodifiableList(bonus);
    }

    public void setBonus(List<String> lines) {
        List<String> copy = new ArrayList<>(lines);
        bonus.clear();
        bonus.addAll(copy);
    }

    /** Lines "count command" that run once when the wearer reaches that many pieces. */
    public List<String> getOnActivate() {
        return Collections.unmodifiableList(onActivate);
    }

    public void setOnActivate(List<String> lines) {
        List<String> copy = new ArrayList<>(lines);
        onActivate.clear();
        onActivate.addAll(copy);
    }

    /** Lines "count command" that run once when the wearer drops below that many pieces. */
    public List<String> getOnDeactivate() {
        return Collections.unmodifiableList(onDeactivate);
    }

    public void setOnDeactivate(List<String> lines) {
        List<String> copy = new ArrayList<>(lines);
        onDeactivate.clear();
        onDeactivate.addAll(copy);
    }

    /** Seconds between repeats of the bonus commands. */
    public double getInterval() {
        return interval;
    }

    public void setInterval(double seconds) {
        this.interval = seconds;
    }

    /** Parses every line of a list, skipping lines that are not "count command". */
    public static List<NumberedCommand> parsed(List<String> lines) {
        List<NumberedCommand> out = new ArrayList<>();
        for (String line : lines) {
            NumberedCommand command = NumberedCommand.parse(line);
            if (command != null) {
                out.add(command);
            }
        }
        return out;
    }
}
