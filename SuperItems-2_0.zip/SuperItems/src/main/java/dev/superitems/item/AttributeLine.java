package dev.superitems.item;

import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.inventory.EquipmentSlotGroup;

/** One attribute bonus on an item, written "name amount [add|mult|mult_total] [slot]", for example "armor 5 add chest". */
public record AttributeLine(String name, double amount, String operation, String slot) {
    private static final Map<String, String> ALIASES = Map.ofEntries(
            Map.entry("speed", "movement_speed"),
            Map.entry("health", "max_health"),
            Map.entry("toughness", "armor_toughness"),
            Map.entry("damage", "attack_damage"),
            Map.entry("knockback", "attack_knockback"),
            Map.entry("kb_resist", "knockback_resistance"));
    private static final Set<String> OPERATIONS = Set.of("add", "mult", "mult_total");
    private static final Set<String> SLOTS = Set.of("auto", "any", "mainhand", "offhand", "hand", "head", "chest", "legs",
            "feet", "armor", "body");

    /** Cleans up an attribute name: lowercase, no generic. prefix, shortcuts expanded. */
    public static String normalizeName(String raw) {
        String value = raw.trim().toLowerCase(Locale.ROOT);
        for (String prefix : new String[] {"minecraft:", "generic.", "generic_", "player.", "zombie."}) {
            if (value.startsWith(prefix)) {
                value = value.substring(prefix.length());
            }
        }
        return ALIASES.getOrDefault(value, value);
    }

    /** Finds an attribute by name, or returns null. */
    public static Attribute resolve(String raw) {
        NamespacedKey key = NamespacedKey.fromString("minecraft:" + normalizeName(raw));
        return key == null ? null : Registry.ATTRIBUTE.get(key);
    }

    /** Parses a line. Throws IllegalArgumentException with a readable message when it is wrong. */
    public static AttributeLine parse(String text) {
        String[] words = text.trim().split("\\s+");
        if (words.length < 2) {
            throw new IllegalArgumentException("An attribute needs a name and an amount, for example: armor 5");
        }
        String name = normalizeName(words[0]);
        if (resolve(name) == null) {
            throw new IllegalArgumentException("'" + words[0] + "' is not an attribute (try armor, max_health, movement_speed, attack_damage).");
        }
        Double amount = null;
        try {
            double parsed = Double.parseDouble(words[1]);
            amount = Double.isFinite(parsed) ? parsed : null;
        } catch (NumberFormatException e) {
            amount = null;
        }
        if (amount == null) {
            throw new IllegalArgumentException("'" + words[1] + "' is not a number.");
        }
        String operation = words.length > 2 ? words[2].toLowerCase(Locale.ROOT) : "add";
        if (!OPERATIONS.contains(operation)) {
            throw new IllegalArgumentException("The operation must be add, mult or mult_total.");
        }
        String slot = words.length > 3 ? words[3].toLowerCase(Locale.ROOT) : "auto";
        if (!SLOTS.contains(slot)) {
            throw new IllegalArgumentException("The slot must be one of " + String.join(", ", SLOTS) + ".");
        }
        return new AttributeLine(name, amount, operation, slot);
    }

    /** The text stored in items.yml. */
    public String toText() {
        String number = amount == Math.rint(amount) ? String.valueOf((long) amount) : String.valueOf(amount);
        return name + " " + number + " " + operation + " " + slot;
    }

    /** Builds the Bukkit modifier. The key must be unique per item and line. */
    public AttributeModifier toModifier(NamespacedKey key, Material material) {
        AttributeModifier.Operation op = switch (operation) {
            case "mult" -> AttributeModifier.Operation.ADD_SCALAR;
            case "mult_total" -> AttributeModifier.Operation.MULTIPLY_SCALAR_1;
            default -> AttributeModifier.Operation.ADD_NUMBER;
        };
        return new AttributeModifier(key, amount, op, group(material));
    }

    private EquipmentSlotGroup group(Material material) {
        return switch (slot) {
            case "any" -> EquipmentSlotGroup.ANY;
            case "mainhand" -> EquipmentSlotGroup.MAINHAND;
            case "offhand" -> EquipmentSlotGroup.OFFHAND;
            case "hand" -> EquipmentSlotGroup.HAND;
            case "head" -> EquipmentSlotGroup.HEAD;
            case "chest" -> EquipmentSlotGroup.CHEST;
            case "legs" -> EquipmentSlotGroup.LEGS;
            case "feet" -> EquipmentSlotGroup.FEET;
            case "armor" -> EquipmentSlotGroup.ARMOR;
            case "body" -> EquipmentSlotGroup.BODY;
            default -> Armor.slotGroupOf(material);
        };
    }
}
