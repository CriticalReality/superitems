package dev.superitems.item;

/** Which mouse button triggered an item. */
public enum Click {
    LEFT,
    RIGHT
}
