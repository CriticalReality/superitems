package dev.superitems.item;

import java.util.Locale;

/** Whether using an item removes one from the stack. */
public enum ConsumeMode {
    NONE,
    RIGHT,
    LEFT,
    BOTH;

    /** Returns true when one item should be removed after the given click. */
    public boolean consumesOn(Click click) {
        return this == BOTH
                || (this == RIGHT && click == Click.RIGHT)
                || (this == LEFT && click == Click.LEFT);
    }

    /** Parses user input, returning null when it is not a valid mode. */
    public static ConsumeMode parse(String text) {
        String value = text.trim().toLowerCase(Locale.ROOT);
        return switch (value) {
            case "none", "false", "no", "off" -> NONE;
            case "right", "true", "yes", "on" -> RIGHT;
            case "left" -> LEFT;
            case "both" -> BOTH;
            default -> null;
        };
    }
}
