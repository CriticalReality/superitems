package dev.superitems.item;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.Material;

/** Everything that describes one custom item or armor piece. Items in inventories only carry the id and look this up when used. */
public final class ItemDefinition {
    private final String id;
    private String name;
    private final List<String> description = new ArrayList<>();
    private Material material;
    private String model;
    private boolean glow;
    private final List<String> onRightClick = new ArrayList<>();
    private final List<String> onLeftClick = new ArrayList<>();
    private ConsumeMode consume = ConsumeMode.NONE;
    private double cooldownSeconds;
    private boolean cancel = true;
    private boolean unbreakable;
    private final List<String> attributes = new ArrayList<>();
    private String color;
    private double damageMin;
    private double damageMax;
    private final List<String> onHit = new ArrayList<>();
    private final List<String> onDamaged = new ArrayList<>();
    private final List<String> onEquip = new ArrayList<>();
    private final List<String> onUnequip = new ArrayList<>();
    private final List<String> whileWorn = new ArrayList<>();
    private double whileWornInterval = 2;
    private double triggerCooldownSeconds;

    /** Creates a definition with default behavior. */
    public ItemDefinition(String id, String name, Material material) {
        this.id = id;
        this.name = name;
        this.material = material;
    }

    /** Returns an independent copy, so edits can be checked before they are applied. */
    public ItemDefinition copy() {
        ItemDefinition other = new ItemDefinition(id, name, material);
        other.copyFrom(this);
        return other;
    }

    /** Overwrites every setting except the id with the settings of another definition. */
    public void copyFrom(ItemDefinition other) {
        name = other.name;
        material = other.material;
        model = other.model;
        glow = other.glow;
        consume = other.consume;
        cooldownSeconds = other.cooldownSeconds;
        cancel = other.cancel;
        unbreakable = other.unbreakable;
        color = other.color;
        damageMin = other.damageMin;
        damageMax = other.damageMax;
        whileWornInterval = other.whileWornInterval;
        triggerCooldownSeconds = other.triggerCooldownSeconds;
        replace(description, other.description);
        replace(onRightClick, other.onRightClick);
        replace(onLeftClick, other.onLeftClick);
        replace(attributes, other.attributes);
        replace(onHit, other.onHit);
        replace(onDamaged, other.onDamaged);
        replace(onEquip, other.onEquip);
        replace(onUnequip, other.onUnequip);
        replace(whileWorn, other.whileWorn);
    }

    private static void replace(List<String> target, List<String> source) {
        List<String> copy = new ArrayList<>(source);
        target.clear();
        target.addAll(copy);
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getDescription() {
        return Collections.unmodifiableList(description);
    }

    public void setDescription(List<String> lines) {
        replace(description, lines);
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    /** Namespaced item model key such as minecraft:dead_brain_coral, or null for the default model. */
    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public boolean isGlow() {
        return glow;
    }

    public void setGlow(boolean glow) {
        this.glow = glow;
    }

    public List<String> getOnRightClick() {
        return Collections.unmodifiableList(onRightClick);
    }

    public void setOnRightClick(List<String> commands) {
        replace(onRightClick, commands);
    }

    public List<String> getOnLeftClick() {
        return Collections.unmodifiableList(onLeftClick);
    }

    public void setOnLeftClick(List<String> commands) {
        replace(onLeftClick, commands);
    }

    /** Returns the commands that run for the given click. */
    public List<String> commandsFor(Click click) {
        return click == Click.RIGHT ? getOnRightClick() : getOnLeftClick();
    }

    public ConsumeMode getConsume() {
        return consume;
    }

    public void setConsume(ConsumeMode consume) {
        this.consume = consume;
    }

    public double getCooldownSeconds() {
        return cooldownSeconds;
    }

    public void setCooldownSeconds(double cooldownSeconds) {
        this.cooldownSeconds = cooldownSeconds;
    }

    /** When true, a click that runs commands is cancelled so the item does not also place, break or attack. */
    public boolean isCancel() {
        return cancel;
    }

    public void setCancel(boolean cancel) {
        this.cancel = cancel;
    }

    public boolean isUnbreakable() {
        return unbreakable;
    }

    public void setUnbreakable(boolean unbreakable) {
        this.unbreakable = unbreakable;
    }

    /** Attribute lines such as "armor 5 add auto". When empty the base item keeps its normal attributes. */
    public List<String> getAttributes() {
        return Collections.unmodifiableList(attributes);
    }

    public void setAttributes(List<String> lines) {
        replace(attributes, lines);
    }

    /** Leather dye color as #rrggbb, or null. */
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    /** True when hits with this item deal a random damage amount between the minimum and maximum. */
    public boolean hasDamageRange() {
        return damageMax > 0;
    }

    public double getDamageMin() {
        return damageMin;
    }

    public double getDamageMax() {
        return damageMax;
    }

    /** Sets the damage range. A maximum of 0 switches it off. */
    public void setDamage(double min, double max) {
        this.damageMin = Math.min(min, max);
        this.damageMax = Math.max(min, max);
    }

    /** Commands that run when the holder or wearer hits something. */
    public List<String> getOnHit() {
        return Collections.unmodifiableList(onHit);
    }

    public void setOnHit(List<String> commands) {
        replace(onHit, commands);
    }

    /** Commands that run when the holder or wearer takes damage. */
    public List<String> getOnDamaged() {
        return Collections.unmodifiableList(onDamaged);
    }

    public void setOnDamaged(List<String> commands) {
        replace(onDamaged, commands);
    }

    /** Commands that run when the item becomes worn or held. */
    public List<String> getOnEquip() {
        return Collections.unmodifiableList(onEquip);
    }

    public void setOnEquip(List<String> commands) {
        replace(onEquip, commands);
    }

    /** Commands that run when the item stops being worn or held. */
    public List<String> getOnUnequip() {
        return Collections.unmodifiableList(onUnequip);
    }

    public void setOnUnequip(List<String> commands) {
        replace(onUnequip, commands);
    }

    /** Commands that repeat while the item is worn or held. */
    public List<String> getWhileWorn() {
        return Collections.unmodifiableList(whileWorn);
    }

    public void setWhileWorn(List<String> commands) {
        replace(whileWorn, commands);
    }

    public double getWhileWornInterval() {
        return whileWornInterval;
    }

    public void setWhileWornInterval(double seconds) {
        this.whileWornInterval = seconds;
    }

    /** Cooldown shared by the on_hit and on_damaged commands. */
    public double getTriggerCooldownSeconds() {
        return triggerCooldownSeconds;
    }

    public void setTriggerCooldownSeconds(double seconds) {
        this.triggerCooldownSeconds = seconds;
    }
}
