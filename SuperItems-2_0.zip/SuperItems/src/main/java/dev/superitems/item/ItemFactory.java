package dev.superitems.item;

import dev.superitems.SuperItems;
import dev.superitems.util.Text;
import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.persistence.PersistentDataType;

/** Builds item stacks from definitions and recognizes them again by a tag stored in the item. */
public final class ItemFactory {
    private final SuperItems plugin;
    private final NamespacedKey idKey;

    /** Creates a factory whose tag is namespaced to the given plugin. */
    public ItemFactory(SuperItems plugin) {
        this.plugin = plugin;
        this.idKey = new NamespacedKey(plugin, "item_id");
    }

    /** Builds a stack of the given size for a definition. */
    public ItemStack create(ItemDefinition definition, int amount) {
        ItemStack stack = new ItemStack(definition.getMaterial(), amount);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.parse(definition.getName()));
        List<Component> lore = new ArrayList<>();
        for (String line : definition.getDescription()) {
            lore.add(Text.parse(line));
        }
        addSetLore(definition, lore);
        if (!lore.isEmpty()) {
            meta.lore(lore);
        }
        if (definition.isGlow()) {
            meta.setEnchantmentGlintOverride(true);
        }
        if (definition.isUnbreakable()) {
            meta.setUnbreakable(true);
        }
        if (definition.getModel() != null) {
            NamespacedKey model = NamespacedKey.fromString(definition.getModel());
            if (model != null) {
                meta.setItemModel(model);
            }
        }
        applyAttributes(definition, meta);
        if (meta instanceof LeatherArmorMeta leather && definition.getColor() != null) {
            Integer rgb = parseColor(definition.getColor());
            if (rgb != null) {
                leather.setColor(Color.fromRGB(rgb));
            }
        }
        meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, definition.getId());
        stack.setItemMeta(meta);
        return stack;
    }

    private void applyAttributes(ItemDefinition definition, ItemMeta meta) {
        Material material = definition.getMaterial();
        int index = 0;
        for (String text : definition.getAttributes()) {
            index++;
            try {
                AttributeLine line = AttributeLine.parse(text);
                Attribute attribute = AttributeLine.resolve(line.name());
                if (attribute != null) {
                    NamespacedKey key = new NamespacedKey(plugin, "i_" + definition.getId() + "_" + index);
                    meta.addAttributeModifier(attribute, line.toModifier(key, material));
                }
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Item '" + definition.getId() + "' attribute '" + text + "': " + e.getMessage());
            }
        }
    }

    private void addSetLore(ItemDefinition definition, List<Component> lore) {
        for (ArmorSet set : plugin.sets().containing(definition.getId())) {
            if (!lore.isEmpty()) {
                lore.add(Component.empty());
            }
            lore.add(Text.parse("&7Set: " + set.getName() + " &8(" + set.getPieces().size() + " pieces)"));
            for (String line : set.getDescription()) {
                lore.add(Text.parse(line));
            }
        }
    }

    /** Parses #rrggbb or rrggbb into an RGB number, or returns null. */
    public static Integer parseColor(String text) {
        String hex = text.startsWith("#") ? text.substring(1) : text;
        if (!hex.matches("[0-9a-fA-F]{6}")) {
            return null;
        }
        return Integer.parseInt(hex, 16);
    }

    /** Returns the super item id stored in the stack, or null when it is not a super item. */
    public String idOf(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return null;
        }
        return stack.getItemMeta().getPersistentDataContainer().get(idKey, PersistentDataType.STRING);
    }
}
