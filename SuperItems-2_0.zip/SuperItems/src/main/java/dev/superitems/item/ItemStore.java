package dev.superitems.item;

import dev.superitems.store.YamlStore;
import dev.superitems.util.Ids;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

/** Holds item definitions in memory and persists them to items.yml. */
public final class ItemStore extends YamlStore<ItemDefinition> {
    /** Creates a store backed by the given file. Call load to read it. */
    public ItemStore(File file, Logger logger) {
        super(file, logger, "items");
    }

    /** Returns true when the id only uses lowercase letters, digits, underscores and dashes. */
    public static boolean isValidId(String id) {
        return Ids.isValid(id);
    }

    @Override
    protected ItemDefinition read(String id, ConfigurationSection section) {
        Material material = Material.matchMaterial(section.getString("material", "STICK"));
        if (material == null || !material.isItem() || material.isAir()) {
            logger.warning("Skipping item '" + id + "': unknown material '" + section.getString("material") + "'.");
            return null;
        }
        ItemDefinition definition = new ItemDefinition(id, section.getString("name", id), material);
        definition.setDescription(section.getStringList("description"));
        definition.setModel(section.getString("model"));
        definition.setGlow(section.getBoolean("glow", false));
        definition.setOnRightClick(section.getStringList("on_right_click"));
        definition.setOnLeftClick(section.getStringList("on_left_click"));
        ConsumeMode consume = ConsumeMode.parse(section.getString("consume", "none"));
        definition.setConsume(consume == null ? ConsumeMode.NONE : consume);
        definition.setCooldownSeconds(Math.max(0, section.getDouble("cooldown", 0)));
        definition.setCancel(section.getBoolean("cancel", true));
        definition.setUnbreakable(section.getBoolean("unbreakable", false));
        definition.setAttributes(section.getStringList("attributes"));
        definition.setColor(section.getString("color"));
        definition.setDamage(Math.max(0, section.getDouble("damage_min", 0)), Math.max(0, section.getDouble("damage_max", 0)));
        definition.setOnHit(section.getStringList("on_hit"));
        definition.setOnDamaged(section.getStringList("on_damaged"));
        definition.setOnEquip(section.getStringList("on_equip"));
        definition.setOnUnequip(section.getStringList("on_unequip"));
        definition.setWhileWorn(section.getStringList("while_worn"));
        definition.setWhileWornInterval(Math.max(0.5, section.getDouble("interval", 2)));
        definition.setTriggerCooldownSeconds(Math.max(0, section.getDouble("trigger_cooldown", 0)));
        for (String line : definition.getAttributes()) {
            try {
                AttributeLine.parse(line);
            } catch (IllegalArgumentException e) {
                logger.warning("Item '" + id + "' has a bad attribute line '" + line + "': " + e.getMessage());
            }
        }
        return definition;
    }

    @Override
    protected void write(ItemDefinition definition, ConfigurationSection section) {
        section.set("name", definition.getName());
        section.set("material", definition.getMaterial().name());
        if (definition.getModel() != null) {
            section.set("model", definition.getModel());
        }
        section.set("glow", definition.isGlow());
        section.set("description", new ArrayList<>(definition.getDescription()));
        section.set("on_right_click", new ArrayList<>(definition.getOnRightClick()));
        section.set("on_left_click", new ArrayList<>(definition.getOnLeftClick()));
        section.set("consume", definition.getConsume().name().toLowerCase(Locale.ROOT));
        section.set("cooldown", definition.getCooldownSeconds());
        section.set("cancel", definition.isCancel());
        if (definition.isUnbreakable()) {
            section.set("unbreakable", true);
        }
        setIfAny(section, "attributes", definition.getAttributes());
        if (definition.getColor() != null) {
            section.set("color", definition.getColor());
        }
        if (definition.hasDamageRange()) {
            section.set("damage_min", definition.getDamageMin());
            section.set("damage_max", definition.getDamageMax());
        }
        setIfAny(section, "on_hit", definition.getOnHit());
        setIfAny(section, "on_damaged", definition.getOnDamaged());
        setIfAny(section, "on_equip", definition.getOnEquip());
        setIfAny(section, "on_unequip", definition.getOnUnequip());
        setIfAny(section, "while_worn", definition.getWhileWorn());
        if (!definition.getWhileWorn().isEmpty()) {
            section.set("interval", definition.getWhileWornInterval());
        }
        if (definition.getTriggerCooldownSeconds() > 0) {
            section.set("trigger_cooldown", definition.getTriggerCooldownSeconds());
        }
    }

    private static void setIfAny(ConfigurationSection section, String key, List<String> values) {
        if (!values.isEmpty()) {
            section.set(key, new ArrayList<>(values));
        }
    }

    @Override
    protected String idOf(ItemDefinition definition) {
        return definition.getId();
    }
}
