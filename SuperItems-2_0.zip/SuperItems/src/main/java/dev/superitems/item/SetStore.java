package dev.superitems.item;

import dev.superitems.store.YamlStore;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import org.bukkit.configuration.ConfigurationSection;

/** Holds armor sets and persists them to sets.yml. */
public final class SetStore extends YamlStore<ArmorSet> {
    /** Creates a store backed by the given file. */
    public SetStore(File file, Logger logger) {
        super(file, logger, "sets");
    }

    /** Returns every set that lists the item as a piece. */
    public List<ArmorSet> containing(String itemId) {
        List<ArmorSet> out = new ArrayList<>();
        for (ArmorSet set : all()) {
            if (set.getPieces().contains(itemId)) {
                out.add(set);
            }
        }
        return out;
    }

    @Override
    protected ArmorSet read(String id, ConfigurationSection section) {
        ArmorSet set = new ArmorSet(id, section.getString("name", id));
        set.setPieces(section.getStringList("pieces"));
        set.setDescription(section.getStringList("description"));
        set.setBonus(section.getStringList("bonus"));
        set.setOnActivate(section.getStringList("on_activate"));
        set.setOnDeactivate(section.getStringList("on_deactivate"));
        set.setInterval(Math.max(0.5, section.getDouble("interval", 2)));
        return set;
    }

    @Override
    protected void write(ArmorSet set, ConfigurationSection section) {
        section.set("name", set.getName());
        section.set("pieces", new ArrayList<>(set.getPieces()));
        section.set("description", new ArrayList<>(set.getDescription()));
        section.set("bonus", new ArrayList<>(set.getBonus()));
        section.set("on_activate", new ArrayList<>(set.getOnActivate()));
        section.set("on_deactivate", new ArrayList<>(set.getOnDeactivate()));
        section.set("interval", set.getInterval());
    }

    @Override
    protected String idOf(ArmorSet set) {
        return set.getId();
    }
}
