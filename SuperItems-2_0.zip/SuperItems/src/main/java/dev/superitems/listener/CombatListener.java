package dev.superitems.listener;

import dev.superitems.SuperItems;
import dev.superitems.item.ItemDefinition;
import dev.superitems.mob.ActiveMob;
import dev.superitems.util.Range;
import dev.superitems.util.Text;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Location;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

/** Damage ranges on items, hit and damaged triggers on items, armor and mobs, and floating damage numbers. */
public final class CombatListener implements Listener {
    private final SuperItems plugin;

    /** Creates the listener. */
    public CombatListener(SuperItems plugin) {
        this.plugin = plugin;
    }

    /** Replaces the damage of a melee hit with a random amount when the held item has a damage range. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamageRange(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player) || event.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
            return;
        }
        ItemDefinition definition = definitionOf(player.getInventory().getItemInMainHand());
        if (definition == null || !definition.hasDamageRange()) {
            return;
        }
        double roll = new Range(definition.getDamageMin(), definition.getDamageMax()).roll(ThreadLocalRandom.current());
        double charge = Math.max(0, Math.min(1, player.getAttackCooldown()));
        event.setDamage(roll * (0.2 + charge * charge * 0.8));
    }

    /** Runs item, armor and mob triggers after a hit has been accepted. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent event) {
        Entity damager = shooterOf(event.getDamager());
        Entity victim = event.getEntity();
        long now = System.currentTimeMillis();

        if (damager instanceof Player player) {
            Map<String, String> vars = pair("target", victim);
            for (ItemDefinition definition : equipmentOf(player)) {
                if (!definition.getOnHit().isEmpty() && ready(player, definition, "hit")) {
                    plugin.runner().run(player, definition.getOnHit(), vars);
                }
            }
        }
        if (victim instanceof Player player) {
            Map<String, String> vars = pair("attacker", damager);
            vars.putAll(pair("target", damager));
            for (ItemDefinition definition : equipmentOf(player)) {
                if (!definition.getOnDamaged().isEmpty() && ready(player, definition, "damaged")) {
                    plugin.runner().run(player, definition.getOnDamaged(), vars);
                }
            }
        }

        ActiveMob attacker = damager instanceof LivingEntity ? plugin.manager().track(damager) : null;
        if (attacker != null && !attacker.definition().onHit.isEmpty() && attacker.tryHitTrigger(now)) {
            Player target = victim instanceof Player player ? player : null;
            plugin.runner().runAsEntity(attacker.entity(), target, attacker.definition().onHit,
                    plugin.manager().vars(attacker, attacker.entity().getLocation(), victim));
        }

        ActiveMob hurt = victim instanceof LivingEntity ? plugin.manager().track(victim) : null;
        if (hurt != null && !hurt.definition().onDamaged.isEmpty() && hurt.tryDamagedTrigger(now)) {
            Player source = damager instanceof Player player ? player : null;
            plugin.runner().runAsEntity(hurt.entity(), source, hurt.definition().onDamaged,
                    plugin.manager().vars(hurt, hurt.entity().getLocation(), damager));
        }

        if (damager instanceof Player player && plugin.getConfig().getBoolean("damage-indicators", true)) {
            ItemDefinition held = definitionOf(player.getInventory().getItemInMainHand());
            if (hurt != null || (held != null && held.hasDamageRange())) {
                showDamage(victim, event.getFinalDamage());
            }
        }
    }

    /** Refreshes boss bars and fires health phases right after any damage to a custom mob. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onAnyDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof LivingEntity living)) {
            return;
        }
        ActiveMob mob = plugin.manager().track(living);
        if (mob == null) {
            return;
        }
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (living.isValid() && !living.isDead()) {
                plugin.manager().updateBar(mob);
                plugin.manager().checkPhases(mob);
            }
        });
    }

    private boolean ready(Player player, ItemDefinition definition, String kind) {
        return plugin.cooldowns().tryUse(player.getUniqueId(), definition.getId() + ":" + kind,
                definition.getTriggerCooldownSeconds()) == 0;
    }

    private ItemDefinition definitionOf(ItemStack stack) {
        String id = plugin.factory().idOf(stack);
        return id == null ? null : plugin.items().get(id);
    }

    /** Every custom item a player holds or wears, once each. */
    private List<ItemDefinition> equipmentOf(Player player) {
        List<ItemDefinition> out = new ArrayList<>();
        PlayerInventory inventory = player.getInventory();
        List<ItemStack> stacks = new ArrayList<>(List.of(inventory.getArmorContents()));
        stacks.add(inventory.getItemInMainHand());
        stacks.add(inventory.getItemInOffHand());
        for (ItemStack stack : stacks) {
            ItemDefinition definition = definitionOf(stack);
            if (definition != null && !out.contains(definition)) {
                out.add(definition);
            }
        }
        return out;
    }

    private static Entity shooterOf(Entity damager) {
        if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Entity shooter) {
            return shooter;
        }
        return damager;
    }

    private static Map<String, String> pair(String key, Entity entity) {
        Map<String, String> vars = new HashMap<>();
        vars.put(key, entity.getUniqueId().toString());
        vars.put(key + "name", entity.getName());
        return vars;
    }

    private void showDamage(Entity victim, double damage) {
        if (damage <= 0 || victim.getWorld() == null) {
            return;
        }
        ThreadLocalRandom random = ThreadLocalRandom.current();
        String format = plugin.getConfig().getString("damage-indicator-format", "&c{damage}");
        String number = String.format(Locale.ROOT, "%,.0f", damage);
        Location at = victim.getLocation().add(random.nextDouble(-0.4, 0.4), victim.getHeight() + 0.2, random.nextDouble(-0.4, 0.4));
        TextDisplay display = victim.getWorld().spawn(at, TextDisplay.class, spawned -> {
            spawned.text(Text.parse(format.replace("{damage}", number)));
            spawned.setBillboard(Display.Billboard.CENTER);
            spawned.setShadowed(true);
            spawned.setPersistent(false);
        });
        plugin.getServer().getScheduler().runTaskLater(plugin, display::remove, 20L);
    }
}
