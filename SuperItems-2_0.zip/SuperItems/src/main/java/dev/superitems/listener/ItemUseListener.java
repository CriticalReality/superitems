package dev.superitems.listener;

import dev.superitems.SuperItems;
import dev.superitems.item.Click;
import dev.superitems.item.ItemDefinition;
import dev.superitems.util.Text;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

/** Turns left and right clicks with a super item into its configured commands. */
public final class ItemUseListener implements Listener {
    /** A left click can arrive as both an interact event and a damage event. Ignore a repeat within this many milliseconds. */
    private static final long LEFT_CLICK_DEDUPE_MILLIS = 40;

    private final SuperItems plugin;
    private final Map<UUID, Long> lastLeftClick = new HashMap<>();

    /** Creates the listener for a plugin. */
    public ItemUseListener(SuperItems plugin) {
        this.plugin = plugin;
    }

    /** Clicks in the air or on a block. */
    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        Click click = switch (event.getAction()) {
            case RIGHT_CLICK_AIR, RIGHT_CLICK_BLOCK -> Click.RIGHT;
            case LEFT_CLICK_AIR, LEFT_CLICK_BLOCK -> Click.LEFT;
            default -> null;
        };
        // Do not use ignoreCancelled here: clicks in the air always count as cancelled.
        if (click == null || event.useItemInHand() == Event.Result.DENY) {
            return;
        }
        EquipmentSlot hand = event.getHand() == null ? EquipmentSlot.HAND : event.getHand();
        ItemDefinition definition = trigger(event.getPlayer(), event.getItem(), hand, click);
        if (definition != null && definition.isCancel()) {
            event.setCancelled(true);
        }
    }

    /** Right click on an entity. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        if (event instanceof PlayerInteractAtEntityEvent) {
            return; // the plain entity event fires too, so count each click once
        }
        Player player = event.getPlayer();
        ItemStack held = heldItem(player, event.getHand());
        ItemDefinition definition = trigger(player, held, event.getHand(), Click.RIGHT);
        if (definition != null && definition.isCancel()) {
            event.setCancelled(true);
        }
    }

    /** Left click (a hit) on an entity. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) {
            return;
        }
        ItemDefinition definition = trigger(player, player.getInventory().getItemInMainHand(), EquipmentSlot.HAND, Click.LEFT);
        if (definition != null && definition.isCancel()) {
            event.setCancelled(true);
        }
    }

    /** Drops cooldowns of players who leave. */
    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        plugin.cooldowns().clear(id);
        lastLeftClick.remove(id);
    }

    /** Runs the item's commands if it is a super item with commands for this click. Returns its definition when it matched. */
    private ItemDefinition trigger(Player player, ItemStack stack, EquipmentSlot hand, Click click) {
        String id = plugin.factory().idOf(stack);
        if (id == null) {
            return null;
        }
        ItemDefinition definition = plugin.items().get(id);
        if (definition == null) {
            return null;
        }
        List<String> commands = definition.commandsFor(click);
        if (commands.isEmpty()) {
            return null;
        }
        if (click == Click.LEFT) {
            long now = System.currentTimeMillis();
            Long last = lastLeftClick.put(player.getUniqueId(), now);
            if (last != null && now - last < LEFT_CLICK_DEDUPE_MILLIS) {
                return definition; // the same click was already handled through the other event
            }
        }
        long waitMillis = plugin.cooldowns().tryUse(player.getUniqueId(), id, definition.getCooldownSeconds());
        if (waitMillis > 0) {
            String seconds = String.format(Locale.ROOT, "%.1f", waitMillis / 1000.0);
            String message = plugin.getConfig().getString("cooldown-message", "&cOn cooldown: {seconds}s");
            player.sendActionBar(Text.parse(message.replace("{seconds}", seconds)));
            return definition;
        }
        plugin.runner().run(player, commands);
        if (definition.getConsume().consumesOn(click)) {
            consumeOne(player, hand);
        }
        return definition;
    }

    private static ItemStack heldItem(Player player, EquipmentSlot hand) {
        PlayerInventory inventory = player.getInventory();
        return hand == EquipmentSlot.OFF_HAND ? inventory.getItemInOffHand() : inventory.getItemInMainHand();
    }

    private static void consumeOne(Player player, EquipmentSlot hand) {
        PlayerInventory inventory = player.getInventory();
        ItemStack held = heldItem(player, hand);
        ItemStack remaining = held.getAmount() <= 1 ? new ItemStack(Material.AIR) : held.clone();
        if (held.getAmount() > 1) {
            remaining.setAmount(held.getAmount() - 1);
        }
        if (hand == EquipmentSlot.OFF_HAND) {
            inventory.setItemInOffHand(remaining);
        } else {
            inventory.setItemInMainHand(remaining);
        }
    }
}
