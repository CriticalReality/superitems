package dev.superitems.listener;

import dev.superitems.SuperItems;
import dev.superitems.loot.LootResult;
import dev.superitems.loot.LootTable;
import dev.superitems.mob.ActiveMob;
import dev.superitems.mob.MobDefinition;
import dev.superitems.mob.MobManager;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/** Registers custom mobs when their chunks load, swaps natural spawns for custom mobs, and handles their deaths. */
public final class MobListener implements Listener {
    private static final EquipmentSlot[] SLOTS = {
        EquipmentSlot.HAND, EquipmentSlot.OFF_HAND, EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private final SuperItems plugin;

    /** Creates the listener. */
    public MobListener(SuperItems plugin) {
        this.plugin = plugin;
    }

    /** Picks up custom mobs that were saved in a chunk. */
    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent event) {
        for (Entity entity : event.getEntities()) {
            plugin.manager().track(entity);
        }
    }

    /** Replaces some natural spawns with custom mobs that ask for it. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onNaturalSpawn(CreatureSpawnEvent event) {
        if (event.getSpawnReason() != CreatureSpawnEvent.SpawnReason.NATURAL
                || !plugin.getConfig().getBoolean("natural-replacement", true)) {
            return;
        }
        EntityType type = event.getEntityType();
        Location at = event.getLocation();
        String worldName = at.getWorld() == null ? "" : at.getWorld().getName();
        for (MobDefinition definition : plugin.mobs().all()) {
            if (definition.replaceType == null || definition.replaceChance <= 0) {
                continue;
            }
            if (!type.equals(MobManager.resolveType(definition.replaceType))) {
                continue;
            }
            if (!definition.worlds.isEmpty() && !definition.worlds.contains(worldName)) {
                continue;
            }
            if (ThreadLocalRandom.current().nextDouble() * 100 >= definition.replaceChance) {
                continue;
            }
            event.setCancelled(true);
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                MobManager.SpawnResult result = plugin.manager().spawn(definition, at, null);
                if (!result.ok()) {
                    plugin.getLogger().warning(result.error());
                }
            });
            return;
        }
    }

    /** Handles drops, loot, experience, messages and commands when a custom mob dies, and on_kill when one kills. */
    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        runKillTrigger(entity);

        ActiveMob mob = plugin.manager().track(entity);
        if (mob == null) {
            return;
        }
        MobDefinition definition = mob.definition();
        Player killer = entity.getKiller();
        Location at = entity.getLocation();
        ThreadLocalRandom random = ThreadLocalRandom.current();

        if (!definition.vanillaDrops) {
            event.getDrops().clear();
            keepEquipment(entity, event.getDrops(), definition.equipmentDrop);
        }
        if (definition.xp != null) {
            event.setDroppedExp(definition.xp.rollInt(random));
        }
        for (String tableId : definition.loot) {
            LootTable table = plugin.loot().get(tableId);
            LootResult result = plugin.roller().roll(tableId);
            for (String problem : result.problems()) {
                plugin.getLogger().warning("Mob '" + definition.id + "' loot '" + tableId + "': " + problem);
            }
            if (table != null && table.getDelivery() == LootTable.Delivery.INVENTORY && killer != null) {
                plugin.roller().giveTo(killer, result);
            } else {
                event.getDrops().addAll(result.items());
                plugin.roller().runCommands(killer, result);
            }
        }

        Map<String, String> vars = plugin.manager().vars(mob, at, killer);
        vars.put("killer", killer == null ? "" : killer.getName());
        plugin.runner().runAtLocation(at, killer, definition.onDeath, vars);
        plugin.manager().announce(definition, definition.deathMessage, at, vars);
        plugin.manager().remove(entity.getUniqueId());
    }

    private void runKillTrigger(LivingEntity victim) {
        EntityDamageEvent last = victim.getLastDamageCause();
        if (!(last instanceof EntityDamageByEntityEvent byEntity)) {
            return;
        }
        Entity damager = byEntity.getDamager();
        if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Entity shooter) {
            damager = shooter;
        }
        if (damager.equals(victim) || !(damager instanceof LivingEntity)) {
            return;
        }
        ActiveMob killer = plugin.manager().track(damager);
        if (killer == null || killer.definition().onKill.isEmpty()) {
            return;
        }
        Player target = victim instanceof Player player ? player : null;
        Map<String, String> vars = new HashMap<>(plugin.manager().vars(killer, killer.entity().getLocation(), victim));
        plugin.runner().runAsEntity(killer.entity(), target, killer.definition().onKill, vars);
    }

    private void keepEquipment(LivingEntity entity, List<ItemStack> drops, double percent) {
        if (percent <= 0) {
            return;
        }
        EntityEquipment equipment = entity.getEquipment();
        if (equipment == null) {
            return;
        }
        for (EquipmentSlot slot : SLOTS) {
            ItemStack stack = equipment.getItem(slot);
            if (stack != null && !stack.getType().isAir() && ThreadLocalRandom.current().nextDouble() * 100 < percent) {
                drops.add(stack.clone());
            }
        }
    }

    /** Drops cooldowns and wear state of players who leave. */
    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.wear().forget(event.getPlayer().getUniqueId());
    }
}
