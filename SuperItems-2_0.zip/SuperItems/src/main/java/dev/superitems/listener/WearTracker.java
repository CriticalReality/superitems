package dev.superitems.listener;

import dev.superitems.SuperItems;
import dev.superitems.action.NumberedCommand;
import dev.superitems.item.ArmorSet;
import dev.superitems.item.ItemDefinition;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

/**
 * Watches what every player wears and holds. Runs on_equip, on_unequip and while_worn commands of items,
 * and the activate, deactivate and bonus commands of armor sets. Called every half second.
 */
public final class WearTracker {
    private final SuperItems plugin;
    private final Map<UUID, Set<String>> equipped = new HashMap<>();
    private final Map<UUID, Map<String, Integer>> setCounts = new HashMap<>();
    private final Map<UUID, Map<String, Long>> nextRepeat = new HashMap<>();

    /** Creates the tracker. */
    public WearTracker(SuperItems plugin) {
        this.plugin = plugin;
    }

    /** Scans every online player. */
    public void tick() {
        long now = System.currentTimeMillis();
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            scan(player, now);
        }
    }

    /** Forgets a player who left. */
    public void forget(UUID player) {
        equipped.remove(player);
        setCounts.remove(player);
        nextRepeat.remove(player);
    }

    /** Forgets everyone, for example after a reload. */
    public void reset() {
        equipped.clear();
        setCounts.clear();
        nextRepeat.clear();
    }

    private void scan(Player player, long now) {
        PlayerInventory inventory = player.getInventory();
        Set<String> armorIds = new LinkedHashSet<>();
        for (ItemStack piece : inventory.getArmorContents()) {
            addId(armorIds, piece);
        }
        Set<String> current = new LinkedHashSet<>(armorIds);
        addId(current, inventory.getItemInMainHand());
        addId(current, inventory.getItemInOffHand());

        UUID uuid = player.getUniqueId();
        Set<String> before = equipped.getOrDefault(uuid, Set.of());
        for (String id : current) {
            ItemDefinition definition = plugin.items().get(id);
            if (!before.contains(id) && definition != null && !definition.getOnEquip().isEmpty()) {
                plugin.runner().run(player, definition.getOnEquip());
            }
        }
        for (String id : before) {
            ItemDefinition definition = plugin.items().get(id);
            if (!current.contains(id) && definition != null && !definition.getOnUnequip().isEmpty()) {
                plugin.runner().run(player, definition.getOnUnequip());
            }
        }
        equipped.put(uuid, current);

        Map<String, Long> next = nextRepeat.computeIfAbsent(uuid, key -> new HashMap<>());
        for (String id : current) {
            ItemDefinition definition = plugin.items().get(id);
            if (definition == null || definition.getWhileWorn().isEmpty()) {
                continue;
            }
            String key = "i:" + id;
            if (now >= next.getOrDefault(key, 0L)) {
                next.put(key, now + (long) (definition.getWhileWornInterval() * 1000));
                plugin.runner().run(player, definition.getWhileWorn());
            }
        }

        Map<String, Integer> previous = setCounts.getOrDefault(uuid, Map.of());
        Map<String, Integer> counts = new HashMap<>();
        for (ArmorSet set : plugin.sets().all()) {
            int count = 0;
            for (String piece : set.getPieces()) {
                if (armorIds.contains(piece)) {
                    count++;
                }
            }
            counts.put(set.getId(), count);
            runSet(player, set, previous.getOrDefault(set.getId(), 0), count, next, now);
        }
        setCounts.put(uuid, counts);
    }

    private void runSet(Player player, ArmorSet set, int before, int count, Map<String, Long> next, long now) {
        for (NumberedCommand line : ArmorSet.parsed(set.getOnActivate())) {
            if (before < line.number() && count >= line.number()) {
                plugin.runner().run(player, List.of(line.command()));
            }
        }
        for (NumberedCommand line : ArmorSet.parsed(set.getOnDeactivate())) {
            if (before >= line.number() && count < line.number()) {
                plugin.runner().run(player, List.of(line.command()));
            }
        }
        String key = "s:" + set.getId();
        if (now < next.getOrDefault(key, 0L)) {
            return;
        }
        boolean ran = false;
        for (NumberedCommand line : ArmorSet.parsed(set.getBonus())) {
            if (count >= line.number()) {
                plugin.runner().run(player, List.of(line.command()));
                ran = true;
            }
        }
        if (ran) {
            next.put(key, now + (long) (set.getInterval() * 1000));
        }
    }

    private void addId(Set<String> ids, ItemStack stack) {
        String id = plugin.factory().idOf(stack);
        if (id != null) {
            ids.add(id);
        }
    }
}
