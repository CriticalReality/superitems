package dev.superitems.loot;

import dev.superitems.util.Range;
import java.util.Locale;
import org.bukkit.Material;

/**
 * One line of a loot table. Written as "weight kind:ref [amount] [chance=percent]".
 * Kinds: item:id (a SuperItems item or armor), vanilla:material, table:id (roll another table),
 * command:text (run a command), nothing.
 */
public record LootEntry(String raw, double weight, Kind kind, String ref, Range amount, double chance) {
    /** What an entry gives. */
    public enum Kind {
        ITEM,
        VANILLA,
        TABLE,
        COMMAND,
        NOTHING
    }

    /** Parses a line. Throws IllegalArgumentException with a readable message when it is wrong. */
    public static LootEntry parse(String text) {
        String line = text.strip();
        String[] words = line.split("\\s+");
        int index = 0;
        double weight = 1;
        if (words.length > 0) {
            try {
                weight = Double.parseDouble(words[0]);
                index = 1;
            } catch (NumberFormatException e) {
                index = 0;
            }
        }
        if (weight < 0 || !Double.isFinite(weight)) {
            throw new IllegalArgumentException("The weight must be 0 or more.");
        }
        if (index >= words.length) {
            throw new IllegalArgumentException("Expected something like: 10 item:myitem 1-2");
        }
        String kindWord = words[index];
        String lower = kindWord.toLowerCase(Locale.ROOT);
        if (lower.equals("nothing") || lower.equals("none")) {
            return new LootEntry(line, weight, Kind.NOTHING, "", new Range(1, 1), 100);
        }
        int colon = kindWord.indexOf(':');
        if (colon < 1) {
            throw new IllegalArgumentException("'" + kindWord + "' must look like item:id, vanilla:material, table:id, command:text or nothing.");
        }
        String kindName = lower.substring(0, colon);
        String ref = kindWord.substring(colon + 1);
        if (kindName.equals("command")) {
            StringBuilder command = new StringBuilder(ref);
            for (int i = index + 1; i < words.length; i++) {
                command.append(' ').append(words[i]);
            }
            String result = command.toString().strip();
            if (result.isEmpty()) {
                throw new IllegalArgumentException("command: needs a command after it.");
            }
            return new LootEntry(line, weight, Kind.COMMAND, result, new Range(1, 1), 100);
        }
        Kind kind = switch (kindName) {
            case "item", "armor", "super" -> Kind.ITEM;
            case "vanilla", "material", "minecraft" -> Kind.VANILLA;
            case "table", "pool" -> Kind.TABLE;
            default -> null;
        };
        if (kind == null) {
            throw new IllegalArgumentException("Unknown kind '" + kindName + "'. Use item, vanilla, table, command or nothing.");
        }
        if (ref.isBlank()) {
            throw new IllegalArgumentException("'" + kindWord + "' needs a name after the colon.");
        }
        if (kind == Kind.VANILLA) {
            Material material = Material.matchMaterial(ref);
            if (material == null || !material.isItem() || material.isAir()) {
                throw new IllegalArgumentException("'" + ref + "' is not an item material.");
            }
            ref = material.name().toLowerCase(Locale.ROOT);
        } else {
            ref = ref.toLowerCase(Locale.ROOT);
        }
        Range amount = new Range(1, 1);
        double chance = 100;
        for (int i = index + 1; i < words.length; i++) {
            String word = words[i];
            if (word.toLowerCase(Locale.ROOT).startsWith("chance=")) {
                String number = word.substring(7).replace("%", "");
                try {
                    chance = Double.parseDouble(number);
                } catch (NumberFormatException e) {
                    throw new IllegalArgumentException("'" + word + "' is not a chance (use chance=25 for 25%).");
                }
                if (chance < 0 || chance > 100) {
                    throw new IllegalArgumentException("The chance must be from 0 to 100.");
                }
            } else {
                Range parsed = Range.parse(word);
                if (parsed == null || parsed.min() < 1) {
                    throw new IllegalArgumentException("'" + word + "' is not an amount (use 3 or 1-4, at least 1).");
                }
                amount = parsed;
            }
        }
        return new LootEntry(line, weight, kind, ref, amount, chance);
    }
}
