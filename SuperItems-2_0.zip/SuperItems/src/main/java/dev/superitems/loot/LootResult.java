package dev.superitems.loot;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.inventory.ItemStack;

/** What one roll of a loot table produced: item stacks and commands to run. */
public final class LootResult {
    private final List<ItemStack> items = new ArrayList<>();
    private final List<String> commands = new ArrayList<>();
    private final List<String> problems = new ArrayList<>();

    /** The item stacks, already split to legal stack sizes. */
    public List<ItemStack> items() {
        return items;
    }

    /** Commands from command: entries. */
    public List<String> commands() {
        return commands;
    }

    /** Warnings such as an entry naming an item that does not exist. */
    public List<String> problems() {
        return problems;
    }

    /** Adds everything from another result. */
    public void addAll(LootResult other) {
        items.addAll(other.items);
        commands.addAll(other.commands);
        problems.addAll(other.problems);
    }

    /** True when nothing was produced. */
    public boolean isEmpty() {
        return items.isEmpty() && commands.isEmpty();
    }
}
