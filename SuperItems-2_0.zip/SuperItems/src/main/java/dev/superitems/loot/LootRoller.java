package dev.superitems.loot;

import dev.superitems.SuperItems;
import dev.superitems.item.ItemDefinition;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Material;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/** Rolls loot tables and hands the result to players or the world. */
public final class LootRoller {
    private static final int MAX_DEPTH = 5;

    private final SuperItems plugin;

    /** Creates a roller. */
    public LootRoller(SuperItems plugin) {
        this.plugin = plugin;
    }

    /** Rolls a table once. Unknown tables give an empty result with a problem noted. */
    public LootResult roll(String tableId) {
        return roll(tableId, ThreadLocalRandom.current(), 0);
    }

    /** Rolls a table once with the given random source. */
    public LootResult roll(String tableId, Random random) {
        return roll(tableId, random, 0);
    }

    private LootResult roll(String tableId, Random random, int depth) {
        LootResult result = new LootResult();
        LootTable table = plugin.loot().get(tableId);
        if (table == null) {
            result.problems().add("Unknown loot table '" + tableId + "'.");
            return result;
        }
        if (depth >= MAX_DEPTH) {
            result.problems().add("Loot table '" + tableId + "' is nested too deeply (a table may include itself).");
            return result;
        }
        if (random.nextDouble() * 100 >= table.getChance()) {
            return result;
        }
        List<LootEntry> weighted = parseAll(table.getEntries(), result);
        double total = 0;
        for (LootEntry entry : weighted) {
            total += entry.weight();
        }
        int rolls = table.getRolls().rollInt(random);
        for (int i = 0; i < rolls && total > 0; i++) {
            double pick = random.nextDouble() * total;
            for (LootEntry entry : weighted) {
                pick -= entry.weight();
                if (pick < 0) {
                    give(entry, random, depth, result);
                    break;
                }
            }
        }
        for (LootEntry entry : parseAll(table.getAlways(), result)) {
            give(entry, random, depth, result);
        }
        return result;
    }

    private static List<LootEntry> parseAll(List<String> lines, LootResult result) {
        List<LootEntry> out = new ArrayList<>();
        for (String line : lines) {
            try {
                out.add(LootEntry.parse(line));
            } catch (IllegalArgumentException e) {
                result.problems().add("Bad entry '" + line + "': " + e.getMessage());
            }
        }
        return out;
    }

    private void give(LootEntry entry, Random random, int depth, LootResult result) {
        if (entry.kind() == LootEntry.Kind.NOTHING) {
            return;
        }
        if (random.nextDouble() * 100 >= entry.chance()) {
            return;
        }
        int amount = entry.amount().rollInt(random);
        switch (entry.kind()) {
            case ITEM -> {
                ItemDefinition definition = plugin.items().get(entry.ref());
                if (definition == null) {
                    result.problems().add("No item called '" + entry.ref() + "'.");
                    return;
                }
                addStacks(result, definition, null, amount);
            }
            case VANILLA -> {
                Material material = Material.matchMaterial(entry.ref());
                if (material == null) {
                    result.problems().add("No material called '" + entry.ref() + "'.");
                    return;
                }
                addStacks(result, null, material, amount);
            }
            case TABLE -> {
                for (int i = 0; i < amount; i++) {
                    result.addAll(roll(entry.ref(), random, depth + 1));
                }
            }
            case COMMAND -> result.commands().add(entry.ref().replace("%amount%", String.valueOf(amount)));
            default -> { }
        }
    }

    private void addStacks(LootResult result, ItemDefinition definition, Material material, int amount) {
        int remaining = amount;
        while (remaining > 0) {
            ItemStack stack = definition != null ? plugin.factory().create(definition, 1) : new ItemStack(material, 1);
            int size = Math.min(remaining, stack.getMaxStackSize());
            stack.setAmount(size);
            remaining -= size;
            result.items().add(stack);
        }
    }

    /** Gives items to a player's inventory (dropping what does not fit) and runs the commands as them. */
    public void giveTo(Player player, LootResult result) {
        for (ItemStack stack : result.items()) {
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(stack);
            for (ItemStack extra : leftover.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), extra);
            }
        }
        plugin.runner().run(player, result.commands());
    }

    /** Drops the items at a place. Commands run for the player when there is one, otherwise from the console. */
    public void dropAt(Location at, Player player, LootResult result) {
        for (ItemStack stack : result.items()) {
            at.getWorld().dropItemNaturally(at, stack);
        }
        runCommands(player, result);
    }

    /** Runs only the commands of a result. */
    public void runCommands(Player player, LootResult result) {
        if (result.commands().isEmpty()) {
            return;
        }
        if (player != null) {
            plugin.runner().run(player, result.commands());
        } else {
            plugin.runner().runRaw(result.commands(), Map.of());
        }
    }
}
