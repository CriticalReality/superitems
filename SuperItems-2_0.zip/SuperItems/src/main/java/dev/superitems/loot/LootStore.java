package dev.superitems.loot;

import dev.superitems.store.YamlStore;
import dev.superitems.util.Range;
import java.io.File;
import java.util.ArrayList;
import java.util.Locale;
import java.util.logging.Logger;
import org.bukkit.configuration.ConfigurationSection;

/** Holds loot tables and persists them to loot.yml. */
public final class LootStore extends YamlStore<LootTable> {
    /** Creates a store backed by the given file. */
    public LootStore(File file, Logger logger) {
        super(file, logger, "loot");
    }

    @Override
    protected LootTable read(String id, ConfigurationSection section) {
        LootTable table = new LootTable(id);
        table.setName(section.getString("name", id));
        Range rolls = Range.parse(section.getString("rolls", "1"));
        table.setRolls(rolls == null || rolls.min() < 0 ? new Range(1, 1) : rolls);
        table.setChance(Math.max(0, Math.min(100, section.getDouble("chance", 100))));
        try {
            table.setDelivery(LootTable.Delivery.valueOf(section.getString("deliver", "drop").toUpperCase(Locale.ROOT)));
        } catch (IllegalArgumentException e) {
            table.setDelivery(LootTable.Delivery.DROP);
        }
        table.setEntries(section.getStringList("entries"));
        table.setAlways(section.getStringList("always"));
        for (String line : table.getEntries()) {
            check(id, line);
        }
        for (String line : table.getAlways()) {
            check(id, line);
        }
        return table;
    }

    private void check(String id, String line) {
        try {
            LootEntry.parse(line);
        } catch (IllegalArgumentException e) {
            logger.warning("Loot table '" + id + "' has a bad entry '" + line + "': " + e.getMessage());
        }
    }

    @Override
    protected void write(LootTable table, ConfigurationSection section) {
        section.set("name", table.getName());
        section.set("rolls", table.getRolls().show());
        section.set("chance", table.getChance());
        section.set("deliver", table.getDelivery().name().toLowerCase(Locale.ROOT));
        section.set("entries", new ArrayList<>(table.getEntries()));
        section.set("always", new ArrayList<>(table.getAlways()));
    }

    @Override
    protected String idOf(LootTable table) {
        return table.getId();
    }
}
