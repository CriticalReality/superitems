package dev.superitems.loot;

import dev.superitems.util.Range;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** A loot pool: how many times to pick from weighted entries, plus entries that always drop. */
public final class LootTable {
    /** Where the loot of a mob goes. */
    public enum Delivery {
        DROP,
        INVENTORY
    }

    private final String id;
    private String name;
    private Range rolls = new Range(1, 1);
    private double chance = 100;
    private Delivery delivery = Delivery.DROP;
    private final List<String> entries = new ArrayList<>();
    private final List<String> always = new ArrayList<>();

    /** Creates an empty table. */
    public LootTable(String id) {
        this.id = id;
        this.name = id;
    }

    /** Returns an independent copy. */
    public LootTable copy() {
        LootTable other = new LootTable(id);
        other.name = name;
        other.rolls = rolls;
        other.chance = chance;
        other.delivery = delivery;
        other.entries.addAll(entries);
        other.always.addAll(always);
        return other;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /** How many times the weighted entries are picked. */
    public Range getRolls() {
        return rolls;
    }

    public void setRolls(Range rolls) {
        this.rolls = rolls;
    }

    /** Percent chance (0 to 100) that the table gives anything at all. */
    public double getChance() {
        return chance;
    }

    public void setChance(double chance) {
        this.chance = chance;
    }

    public Delivery getDelivery() {
        return delivery;
    }

    public void setDelivery(Delivery delivery) {
        this.delivery = delivery;
    }

    /** The weighted entries, as written. */
    public List<String> getEntries() {
        return Collections.unmodifiableList(entries);
    }

    public void setEntries(List<String> lines) {
        List<String> copy = new ArrayList<>(lines);
        entries.clear();
        entries.addAll(copy);
    }

    /** Entries that are rolled once each every time, using only their own chance. */
    public List<String> getAlways() {
        return Collections.unmodifiableList(always);
    }

    public void setAlways(List<String> lines) {
        List<String> copy = new ArrayList<>(lines);
        always.clear();
        always.addAll(copy);
    }
}
