package dev.superitems.mob;

import dev.superitems.action.NumberedCommand;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.kyori.adventure.bossbar.BossBar;
import org.bukkit.entity.LivingEntity;

/** A custom mob that is alive in a loaded chunk, with its running timers, fired phases and boss bar. */
public final class ActiveMob {
    private final LivingEntity entity;
    private final String id;
    private final String spawnerId;
    private MobDefinition definition;
    private List<NumberedCommand> timers = new ArrayList<>();
    private List<NumberedCommand> phases = new ArrayList<>();
    private long[] nextTimer = new long[0];
    private final Set<Integer> firedPhases = new HashSet<>();
    private BossBar bar;
    private Set<UUID> viewers = new HashSet<>();
    private long lastHitTrigger;
    private long lastDamagedTrigger;

    /** Creates the record for a living entity. */
    ActiveMob(LivingEntity entity, MobDefinition definition, String spawnerId) {
        this.entity = entity;
        this.id = definition.id;
        this.spawnerId = spawnerId;
        this.definition = definition;
    }

    public LivingEntity entity() {
        return entity;
    }

    /** The id of the definition this mob was spawned from. */
    public String id() {
        return id;
    }

    /** The spawner point that made this mob, or null. */
    public String spawnerId() {
        return spawnerId;
    }

    public MobDefinition definition() {
        return definition;
    }

    /** Points the mob at a (re)loaded definition and rebuilds its timers. */
    void setDefinition(MobDefinition definition, long now) {
        this.definition = definition;
        this.timers = parse(definition.timers);
        this.phases = parse(definition.phases);
        this.nextTimer = new long[timers.size()];
        for (int i = 0; i < nextTimer.length; i++) {
            nextTimer[i] = now + (long) (timers.get(i).number() * 1000);
        }
    }

    private static List<NumberedCommand> parse(List<String> lines) {
        List<NumberedCommand> out = new ArrayList<>();
        for (String line : lines) {
            NumberedCommand command = NumberedCommand.parse(line);
            if (command != null) {
                out.add(command);
            }
        }
        return out;
    }

    List<NumberedCommand> timers() {
        return timers;
    }

    List<NumberedCommand> phases() {
        return phases;
    }

    long[] nextTimer() {
        return nextTimer;
    }

    Set<Integer> firedPhases() {
        return firedPhases;
    }

    BossBar bar() {
        return bar;
    }

    void setBar(BossBar bar) {
        this.bar = bar;
    }

    Set<UUID> viewers() {
        return viewers;
    }

    void setViewers(Set<UUID> viewers) {
        this.viewers = viewers;
    }

    /** Returns true (and starts the cooldown) when an on_hit trigger may run now. */
    public boolean tryHitTrigger(long now) {
        if (now - lastHitTrigger < definition.triggerCooldown * 1000) {
            return false;
        }
        lastHitTrigger = now;
        return true;
    }

    /** Returns true (and starts the cooldown) when an on_damaged trigger may run now. */
    public boolean tryDamagedTrigger(long now) {
        if (now - lastDamagedTrigger < definition.triggerCooldown * 1000) {
            return false;
        }
        lastDamagedTrigger = now;
        return true;
    }
}
