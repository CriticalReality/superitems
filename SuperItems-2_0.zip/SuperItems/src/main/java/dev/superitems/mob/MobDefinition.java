package dev.superitems.mob;

import dev.superitems.util.Range;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Everything that describes one custom enemy, miniboss or boss. Plain data: the fields are the settings. */
public final class MobDefinition {
    /** The id used in commands and files. */
    public final String id;
    /** Display name, with color codes or MiniMessage tags. */
    public String name;
    /** Enemy, miniboss or boss. */
    public MobTier tier = MobTier.ENEMY;
    /** The vanilla entity type key such as zombie or minecraft:wither_skeleton. */
    public String type = "zombie";
    /** Attribute base values by attribute name. A value ending in x multiplies the normal base value. */
    public final Map<String, String> attributes = new LinkedHashMap<>();
    /** Slime and magma cube size, 0 keeps the default. */
    public int size;
    public boolean baby;
    public boolean glow;
    public boolean silent;
    public boolean invulnerable;
    public boolean invisible;
    public boolean ai = true;
    public boolean gravity = true;
    public boolean persistent;
    public boolean nameVisible = true;
    /** Equipment: a SuperItems item or armor id, or a vanilla material name. Null means empty. */
    public String mainhand;
    public String offhand;
    public String helmet;
    public String chestplate;
    public String leggings;
    public String boots;
    /** Percent chance (0 to 100) that worn equipment drops. */
    public double equipmentDrop;
    /** Effect lines "name [amplifier] [seconds|infinite]" applied on spawn. */
    public final List<String> effects = new ArrayList<>();
    /** Another mob id that rides this one. */
    public String rider;
    public final List<String> onSpawn = new ArrayList<>();
    public final List<String> onHit = new ArrayList<>();
    public final List<String> onDamaged = new ArrayList<>();
    public final List<String> onDeath = new ArrayList<>();
    public final List<String> onKill = new ArrayList<>();
    /** Lines "seconds command" that repeat while a player is near. */
    public final List<String> timers = new ArrayList<>();
    /** Lines "percent command" that run once when health falls to that percent. */
    public final List<String> phases = new ArrayList<>();
    /** Seconds between on_hit/on_damaged runs. */
    public double triggerCooldown;
    /** Timers only run while a player is within this many blocks. 0 means always. */
    public double activeRange = 64;
    public boolean bossbar;
    public String barColor = "red";
    public String barStyle = "progress";
    public double barRange = 64;
    /** Boss bar title, or null to use the name. */
    public String barTitle;
    /** Loot table ids rolled when the mob dies. */
    public final List<String> loot = new ArrayList<>();
    /** Experience dropped, or null to keep the vanilla amount. */
    public Range xp;
    public boolean vanillaDrops = true;
    public String spawnMessage;
    public String deathMessage;
    /** Who sees the messages: world, server or none. */
    public String announce = "world";
    /** Vanilla entity type this mob replaces when it would spawn naturally, or null. */
    public String replaceType;
    /** Percent chance of the replacement. */
    public double replaceChance;
    /** Worlds the natural replacement works in. Empty means every world. */
    public final List<String> worlds = new ArrayList<>();

    /** Creates a mob with default settings. */
    public MobDefinition(String id) {
        this.id = id;
        this.name = id;
    }

    /** Returns an independent copy, so edits can be checked before they are applied. */
    public MobDefinition copy() {
        MobDefinition other = new MobDefinition(id);
        other.copyFrom(this);
        return other;
    }

    /** Overwrites every setting except the id. */
    public void copyFrom(MobDefinition o) {
        name = o.name;
        tier = o.tier;
        type = o.type;
        attributes.clear();
        attributes.putAll(o.attributes);
        size = o.size;
        baby = o.baby;
        glow = o.glow;
        silent = o.silent;
        invulnerable = o.invulnerable;
        invisible = o.invisible;
        ai = o.ai;
        gravity = o.gravity;
        persistent = o.persistent;
        nameVisible = o.nameVisible;
        mainhand = o.mainhand;
        offhand = o.offhand;
        helmet = o.helmet;
        chestplate = o.chestplate;
        leggings = o.leggings;
        boots = o.boots;
        equipmentDrop = o.equipmentDrop;
        rider = o.rider;
        triggerCooldown = o.triggerCooldown;
        activeRange = o.activeRange;
        bossbar = o.bossbar;
        barColor = o.barColor;
        barStyle = o.barStyle;
        barRange = o.barRange;
        barTitle = o.barTitle;
        xp = o.xp;
        vanillaDrops = o.vanillaDrops;
        spawnMessage = o.spawnMessage;
        deathMessage = o.deathMessage;
        announce = o.announce;
        replaceType = o.replaceType;
        replaceChance = o.replaceChance;
        assign(effects, o.effects);
        assign(onSpawn, o.onSpawn);
        assign(onHit, o.onHit);
        assign(onDamaged, o.onDamaged);
        assign(onDeath, o.onDeath);
        assign(onKill, o.onKill);
        assign(timers, o.timers);
        assign(phases, o.phases);
        assign(loot, o.loot);
        assign(worlds, o.worlds);
    }

    /** Replaces the contents of a list with the contents of another. */
    public static void assign(List<String> target, List<String> source) {
        List<String> copy = new ArrayList<>(source);
        target.clear();
        target.addAll(copy);
    }
}
