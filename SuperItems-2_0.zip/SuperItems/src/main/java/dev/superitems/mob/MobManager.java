package dev.superitems.mob;

import dev.superitems.SuperItems;
import dev.superitems.action.NumberedCommand;
import dev.superitems.item.ItemDefinition;
import dev.superitems.util.Text;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Slime;
import org.bukkit.entity.Zombie;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

/** Spawns custom mobs, remembers the ones that are alive, and runs their timers, phases and boss bars. */
public final class MobManager {
    /** The outcome of a spawn: the mob, or a message explaining why not. */
    public record SpawnResult(LivingEntity entity, String error) {
        /** True when a mob was spawned. */
        public boolean ok() {
            return entity != null;
        }
    }

    private static final int MAX_RIDER_DEPTH = 3;

    private final SuperItems plugin;
    private final NamespacedKey idKey;
    private final NamespacedKey spawnerKey;
    private final Map<UUID, ActiveMob> active = new HashMap<>();

    /** Creates the manager. */
    public MobManager(SuperItems plugin) {
        this.plugin = plugin;
        this.idKey = new NamespacedKey(plugin, "mob_id");
        this.spawnerKey = new NamespacedKey(plugin, "spawner_id");
    }

    /** Finds a vanilla entity type from text such as zombie or minecraft:zombie, or returns null. */
    public static EntityType resolveType(String text) {
        if (text == null || text.isBlank()) {
            return null;
        }
        String value = text.trim().toLowerCase(Locale.ROOT);
        NamespacedKey key = NamespacedKey.fromString(value.contains(":") ? value : "minecraft:" + value);
        return key == null ? null : Registry.ENTITY_TYPE.get(key);
    }

    /** True when the entity type can be spawned as a living mob. */
    public static boolean isSpawnableMob(EntityType type) {
        return type != null && type != EntityType.UNKNOWN && type.isSpawnable() && type.isAlive();
    }

    /** Parses a boss bar color word, or returns null. */
    public static BossBar.Color parseColor(String text) {
        try {
            return BossBar.Color.valueOf(text.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    /** Parses a boss bar style word (progress, 6, 10, 12, 20), or returns null. */
    public static BossBar.Overlay parseOverlay(String text) {
        String value = text.trim().toLowerCase(Locale.ROOT).replace("notched_", "");
        return switch (value) {
            case "progress", "solid" -> BossBar.Overlay.PROGRESS;
            case "6" -> BossBar.Overlay.NOTCHED_6;
            case "10" -> BossBar.Overlay.NOTCHED_10;
            case "12" -> BossBar.Overlay.NOTCHED_12;
            case "20" -> BossBar.Overlay.NOTCHED_20;
            default -> null;
        };
    }

    /** The mob definition id stored in an entity, or null when it is not a custom mob. */
    public String idOf(Entity entity) {
        return entity.getPersistentDataContainer().get(idKey, PersistentDataType.STRING);
    }

    /** Every custom mob currently alive in a loaded chunk. */
    public Collection<ActiveMob> all() {
        return new ArrayList<>(active.values());
    }

    /** How many live mobs came from the given spawner point. */
    public int countFromSpawner(String spawnerId) {
        int count = 0;
        for (ActiveMob mob : active.values()) {
            if (spawnerId.equals(mob.spawnerId()) && mob.entity().isValid()) {
                count++;
            }
        }
        return count;
    }

    /** Returns the tracked record for a custom mob, registering it first when it was loaded from disk. Null for anything else. */
    public ActiveMob track(Entity entity) {
        ActiveMob existing = active.get(entity.getUniqueId());
        if (existing != null) {
            return existing;
        }
        if (!(entity instanceof LivingEntity living)) {
            return null;
        }
        PersistentDataContainer data = entity.getPersistentDataContainer();
        String id = data.get(idKey, PersistentDataType.STRING);
        if (id == null) {
            return null;
        }
        MobDefinition definition = plugin.mobs().get(id);
        if (definition == null) {
            return null;
        }
        return register(living, definition, data.get(spawnerKey, PersistentDataType.STRING), false);
    }

    /** Registers every custom mob in loaded chunks. Called on startup and reload. */
    public void scanLoaded() {
        for (World world : plugin.getServer().getWorlds()) {
            for (LivingEntity entity : world.getLivingEntities()) {
                track(entity);
            }
        }
    }

    private ActiveMob register(LivingEntity entity, MobDefinition definition, String spawnerId, boolean fresh) {
        ActiveMob mob = new ActiveMob(entity, definition, spawnerId);
        mob.setDefinition(definition, System.currentTimeMillis());
        if (!fresh) {
            double percent = healthPercent(entity);
            List<NumberedCommand> phases = mob.phases();
            for (int i = 0; i < phases.size(); i++) {
                if (phases.get(i).number() >= percent) {
                    mob.firedPhases().add(i);
                }
            }
        }
        buildBar(mob);
        active.put(entity.getUniqueId(), mob);
        return mob;
    }

    /** Forgets a mob and hides its boss bar. The entity itself is left alone. */
    public void remove(UUID id) {
        ActiveMob mob = active.remove(id);
        if (mob != null) {
            hideBar(mob);
        }
    }

    /** Removes every live mob of a definition (or all of them when the id is null) without drops. Returns how many. */
    public int killAll(String id) {
        int count = 0;
        for (ActiveMob mob : all()) {
            if (id == null || id.equals(mob.id())) {
                remove(mob.entity().getUniqueId());
                mob.entity().remove();
                count++;
            }
        }
        return count;
    }

    /** Hides every boss bar. Called when the plugin stops. */
    public void shutdown() {
        for (ActiveMob mob : all()) {
            hideBar(mob);
        }
        active.clear();
    }

    /** Points live mobs at freshly loaded definitions after a reload or edit. Mobs whose definition was deleted stop being tracked. */
    public void rebind() {
        long now = System.currentTimeMillis();
        for (ActiveMob mob : all()) {
            MobDefinition definition = plugin.mobs().get(mob.id());
            if (definition == null) {
                remove(mob.entity().getUniqueId());
                continue;
            }
            mob.setDefinition(definition, now);
            hideBar(mob);
            buildBar(mob);
        }
    }

    /** Spawns a mob at a place. */
    public SpawnResult spawn(MobDefinition definition, Location at, String spawnerId) {
        return spawn(definition, at, spawnerId, 0);
    }

    private SpawnResult spawn(MobDefinition d, Location at, String spawnerId, int depth) {
        EntityType type = resolveType(d.type);
        if (!isSpawnableMob(type)) {
            return new SpawnResult(null, "Mob '" + d.id + "' has entity type '" + d.type + "' which cannot be spawned. Fix it with /superitems mob edit " + d.id + " --type zombie");
        }
        World world = at.getWorld();
        if (world == null) {
            return new SpawnResult(null, "That location has no world.");
        }
        Entity entity;
        try {
            entity = world.spawnEntity(at, type);
        } catch (RuntimeException e) {
            return new SpawnResult(null, "The server could not spawn a " + d.type + ": " + e.getMessage());
        }
        if (!(entity instanceof LivingEntity living)) {
            entity.remove();
            return new SpawnResult(null, "'" + d.type + "' is not a living entity.");
        }
        PersistentDataContainer data = living.getPersistentDataContainer();
        data.set(idKey, PersistentDataType.STRING, d.id);
        if (spawnerId != null) {
            data.set(spawnerKey, PersistentDataType.STRING, spawnerId);
        }
        apply(living, d);
        ActiveMob mob = register(living, d, spawnerId, true);

        List<String> startup = new ArrayList<>(effectCommands(d));
        startup.addAll(d.onSpawn);
        Player near = nearestPlayer(living, 64);
        plugin.runner().runAsEntity(living, near, startup, vars(mob, living.getLocation(), near));
        announce(d, d.spawnMessage, living.getLocation(), vars(mob, living.getLocation(), null));

        if (d.rider != null && depth < MAX_RIDER_DEPTH) {
            MobDefinition riderDefinition = plugin.mobs().get(d.rider);
            if (riderDefinition != null) {
                SpawnResult rider = spawn(riderDefinition, at, spawnerId, depth + 1);
                if (rider.ok()) {
                    living.addPassenger(rider.entity());
                }
            }
        }
        return new SpawnResult(living, null);
    }

    private void apply(LivingEntity e, MobDefinition d) {
        if (e instanceof Slime slime && d.size > 0) {
            slime.setSize(d.size);
        }
        e.customName(Text.parse(d.name));
        e.setCustomNameVisible(d.nameVisible);
        applyAttributes(e, d);
        AttributeInstance maxHealth = e.getAttribute(Attribute.MAX_HEALTH);
        if (maxHealth != null) {
            e.setHealth(maxHealth.getValue());
        }
        if (d.baby) {
            if (e instanceof Zombie zombie) {
                zombie.setBaby(true);
            } else if (e instanceof Ageable ageable) {
                ageable.setBaby();
            }
        }
        e.setGlowing(d.glow);
        e.setSilent(d.silent);
        e.setInvulnerable(d.invulnerable);
        e.setInvisible(d.invisible);
        e.setAI(d.ai);
        e.setGravity(d.gravity);
        e.setRemoveWhenFarAway(!d.persistent);
        e.setCanPickupItems(false);
        EntityEquipment equipment = e.getEquipment();
        if (equipment != null) {
            setSlot(equipment, EquipmentSlot.HAND, d.mainhand, d.equipmentDrop);
            setSlot(equipment, EquipmentSlot.OFF_HAND, d.offhand, d.equipmentDrop);
            setSlot(equipment, EquipmentSlot.HEAD, d.helmet, d.equipmentDrop);
            setSlot(equipment, EquipmentSlot.CHEST, d.chestplate, d.equipmentDrop);
            setSlot(equipment, EquipmentSlot.LEGS, d.leggings, d.equipmentDrop);
            setSlot(equipment, EquipmentSlot.FEET, d.boots, d.equipmentDrop);
        }
    }

    private void applyAttributes(LivingEntity e, MobDefinition d) {
        for (Map.Entry<String, String> entry : d.attributes.entrySet()) {
            Attribute attribute = dev.superitems.item.AttributeLine.resolve(entry.getKey());
            AttributeInstance instance = attribute == null ? null : e.getAttribute(attribute);
            if (instance == null) {
                plugin.getLogger().warning("Mob '" + d.id + "': a " + d.type + " has no attribute '" + entry.getKey() + "'.");
                continue;
            }
            String text = entry.getValue().trim().toLowerCase(Locale.ROOT);
            try {
                if (text.endsWith("x")) {
                    instance.setBaseValue(instance.getBaseValue() * Double.parseDouble(text.substring(0, text.length() - 1)));
                } else {
                    instance.setBaseValue(Double.parseDouble(text));
                }
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Mob '" + d.id + "': bad value '" + text + "' for attribute '" + entry.getKey() + "'.");
            }
        }
    }

    private void setSlot(EntityEquipment equipment, EquipmentSlot slot, String ref, double dropPercent) {
        if (ref == null || ref.isBlank()) {
            return;
        }
        ItemStack stack = stackFor(ref);
        if (stack == null) {
            plugin.getLogger().warning("Mob equipment '" + ref + "' is neither a SuperItems item nor a material.");
            return;
        }
        equipment.setItem(slot, stack);
        equipment.setDropChance(slot, (float) (dropPercent / 100.0));
    }

    /** Builds a stack for an equipment reference: a SuperItems item or armor id first, then a vanilla material. Null when neither exists. */
    public ItemStack stackFor(String ref) {
        ItemDefinition definition = plugin.items().get(ref.toLowerCase(Locale.ROOT));
        if (definition != null) {
            return plugin.factory().create(definition, 1);
        }
        Material material = Material.matchMaterial(ref);
        if (material != null && material.isItem() && !material.isAir()) {
            return new ItemStack(material);
        }
        return null;
    }

    private static List<String> effectCommands(MobDefinition d) {
        List<String> commands = new ArrayList<>();
        for (String line : d.effects) {
            String[] words = line.trim().split("\\s+");
            if (words.length == 0 || words[0].isEmpty()) {
                continue;
            }
            String name = words[0].toLowerCase(Locale.ROOT);
            if (!name.contains(":")) {
                name = "minecraft:" + name;
            }
            String amplifier = words.length > 1 ? words[1] : "0";
            String duration = words.length > 2 ? words[2] : "infinite";
            commands.add("effect give %mob% " + name + " " + duration + " " + amplifier + " true");
        }
        return commands;
    }

    /** Placeholders for mob commands: %mob% (UUID), %mobid%, %x% %y% %z%, %world%, and %target% / %targetname% for the other party. */
    public Map<String, String> vars(ActiveMob mob, Location at, Entity other) {
        Map<String, String> vars = new HashMap<>();
        vars.put("mob", mob.entity().getUniqueId().toString());
        vars.put("mobid", mob.id());
        vars.put("x", String.valueOf(at.getBlockX()));
        vars.put("y", String.valueOf(at.getBlockY()));
        vars.put("z", String.valueOf(at.getBlockZ()));
        vars.put("world", at.getWorld() == null ? "" : at.getWorld().getName());
        if (other != null) {
            vars.put("target", other.getUniqueId().toString());
            vars.put("targetname", other.getName());
        }
        return vars;
    }

    /** Sends a spawn or death message to the audience the mob is set to announce to. */
    public void announce(MobDefinition d, String message, Location at, Map<String, String> vars) {
        if (message == null || message.isBlank() || "none".equalsIgnoreCase(d.announce)) {
            return;
        }
        String text = message;
        for (Map.Entry<String, String> entry : vars.entrySet()) {
            text = text.replace("%" + entry.getKey() + "%", entry.getValue());
        }
        text = text.replace("%name%", d.name);
        Component component = Text.parse(text);
        if ("server".equalsIgnoreCase(d.announce)) {
            plugin.getServer().broadcast(component);
        } else if (at.getWorld() != null) {
            for (Player player : at.getWorld().getPlayers()) {
                player.sendMessage(component);
            }
        }
    }

    /** The closest player in the same world within range blocks (any distance when range is 0 or less), or null. */
    public Player nearestPlayer(Entity from, double range) {
        Player best = null;
        double bestDistance = range > 0 ? range * range : Double.MAX_VALUE;
        for (Player player : from.getWorld().getPlayers()) {
            if (player.getGameMode() == GameMode.SPECTATOR) {
                continue;
            }
            double distance = player.getLocation().distanceSquared(from.getLocation());
            if (distance <= bestDistance) {
                bestDistance = distance;
                best = player;
            }
        }
        return best;
    }

    /** Health as a percent of the maximum (0 to 100). */
    public static double healthPercent(LivingEntity entity) {
        double max = maxHealth(entity);
        return max <= 0 ? 0 : Math.max(0, Math.min(100, entity.getHealth() / max * 100));
    }

    /** Maximum health of an entity. */
    public static double maxHealth(LivingEntity entity) {
        AttributeInstance instance = entity.getAttribute(Attribute.MAX_HEALTH);
        return instance == null ? entity.getHealth() : instance.getValue();
    }

    /** Runs once a half second: drops dead mobs, refreshes boss bars, fires phases and timers. */
    public void tick() {
        long now = System.currentTimeMillis();
        Iterator<ActiveMob> iterator = active.values().iterator();
        while (iterator.hasNext()) {
            ActiveMob mob = iterator.next();
            LivingEntity entity = mob.entity();
            if (!entity.isValid() || entity.isDead()) {
                hideBar(mob);
                iterator.remove();
                continue;
            }
            updateBar(mob);
            checkPhases(mob);
            runTimers(mob, now);
        }
    }

    /** Fires any health phase the mob has now fallen to. */
    public void checkPhases(ActiveMob mob) {
        List<NumberedCommand> phases = mob.phases();
        if (phases.isEmpty()) {
            return;
        }
        double percent = healthPercent(mob.entity());
        for (int i = 0; i < phases.size(); i++) {
            NumberedCommand phase = phases.get(i);
            if (percent <= phase.number() && mob.firedPhases().add(i)) {
                Player near = nearestPlayer(mob.entity(), 64);
                plugin.runner().runAsEntity(mob.entity(), near, List.of(phase.command()),
                        vars(mob, mob.entity().getLocation(), near));
            }
        }
    }

    private void runTimers(ActiveMob mob, long now) {
        List<NumberedCommand> timers = mob.timers();
        long[] next = mob.nextTimer();
        for (int i = 0; i < timers.size() && i < next.length; i++) {
            if (now < next[i]) {
                continue;
            }
            next[i] = now + Math.max(500L, (long) (timers.get(i).number() * 1000));
            double range = mob.definition().activeRange;
            Player near = nearestPlayer(mob.entity(), range);
            if (range > 0 && near == null) {
                continue;
            }
            plugin.runner().runAsEntity(mob.entity(), near, List.of(timers.get(i).command()),
                    vars(mob, mob.entity().getLocation(), near));
        }
    }

    private void buildBar(ActiveMob mob) {
        MobDefinition d = mob.definition();
        if (!d.bossbar) {
            mob.setBar(null);
            return;
        }
        BossBar.Color color = parseColor(d.barColor);
        BossBar.Overlay overlay = parseOverlay(d.barStyle);
        String title = d.barTitle != null ? d.barTitle : d.name;
        mob.setBar(BossBar.bossBar(Text.parse(title), 1.0f,
                color == null ? BossBar.Color.RED : color,
                overlay == null ? BossBar.Overlay.PROGRESS : overlay));
    }

    /** Updates the boss bar progress and who can see it. */
    public void updateBar(ActiveMob mob) {
        BossBar bar = mob.bar();
        if (bar == null) {
            return;
        }
        LivingEntity entity = mob.entity();
        bar.progress((float) (healthPercent(entity) / 100.0));
        double range = mob.definition().barRange;
        double limit = range * range;
        Set<UUID> now = new HashSet<>();
        for (Player player : entity.getWorld().getPlayers()) {
            if (player.getLocation().distanceSquared(entity.getLocation()) <= limit) {
                now.add(player.getUniqueId());
                if (!mob.viewers().contains(player.getUniqueId())) {
                    player.showBossBar(bar);
                }
            }
        }
        for (UUID old : mob.viewers()) {
            if (!now.contains(old)) {
                Player player = plugin.getServer().getPlayer(old);
                if (player != null) {
                    player.hideBossBar(bar);
                }
            }
        }
        mob.setViewers(now);
    }

    private void hideBar(ActiveMob mob) {
        BossBar bar = mob.bar();
        if (bar != null) {
            for (UUID id : mob.viewers()) {
                Player player = plugin.getServer().getPlayer(id);
                if (player != null) {
                    player.hideBossBar(bar);
                }
            }
        }
        mob.setViewers(new HashSet<>());
    }
}
