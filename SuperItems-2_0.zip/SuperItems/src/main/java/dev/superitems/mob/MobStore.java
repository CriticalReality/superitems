package dev.superitems.mob;

import dev.superitems.store.YamlStore;
import dev.superitems.util.Range;
import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Logger;
import org.bukkit.configuration.ConfigurationSection;

/** Holds mob definitions and persists them to mobs.yml. */
public final class MobStore extends YamlStore<MobDefinition> {
    /** Creates a store backed by the given file. */
    public MobStore(File file, Logger logger) {
        super(file, logger, "mobs");
    }

    @Override
    protected MobDefinition read(String id, ConfigurationSection s) {
        MobDefinition d = new MobDefinition(id);
        d.name = s.getString("name", id);
        MobTier tier = MobTier.parse(s.getString("tier", "enemy"));
        d.tier = tier == null ? MobTier.ENEMY : tier;
        d.type = s.getString("type", "zombie");
        ConfigurationSection attributes = s.getConfigurationSection("attributes");
        if (attributes != null) {
            for (String key : attributes.getKeys(false)) {
                d.attributes.put(key, String.valueOf(attributes.get(key)));
            }
        }
        d.size = s.getInt("size", 0);
        d.baby = s.getBoolean("baby", false);
        d.glow = s.getBoolean("glow", false);
        d.silent = s.getBoolean("silent", false);
        d.invulnerable = s.getBoolean("invulnerable", false);
        d.invisible = s.getBoolean("invisible", false);
        d.ai = s.getBoolean("ai", true);
        d.gravity = s.getBoolean("gravity", true);
        d.persistent = s.getBoolean("persistent", d.tier != MobTier.ENEMY);
        d.nameVisible = s.getBoolean("name_visible", true);
        d.mainhand = s.getString("mainhand");
        d.offhand = s.getString("offhand");
        d.helmet = s.getString("helmet");
        d.chestplate = s.getString("chestplate");
        d.leggings = s.getString("leggings");
        d.boots = s.getString("boots");
        d.equipmentDrop = s.getDouble("equipment_drop", 0);
        d.rider = s.getString("rider");
        d.triggerCooldown = Math.max(0, s.getDouble("trigger_cooldown", 0));
        d.activeRange = Math.max(0, s.getDouble("active_range", 64));
        d.bossbar = s.getBoolean("bossbar", d.tier == MobTier.BOSS);
        d.barColor = s.getString("bar_color", "red");
        d.barStyle = s.getString("bar_style", "progress");
        d.barRange = Math.max(1, s.getDouble("bar_range", 64));
        d.barTitle = s.getString("bar_title");
        d.xp = s.contains("xp") ? Range.parse(s.getString("xp")) : null;
        d.vanillaDrops = s.getBoolean("vanilla_drops", true);
        d.spawnMessage = s.getString("spawn_message");
        d.deathMessage = s.getString("death_message");
        d.announce = s.getString("announce", "world");
        d.replaceType = s.getString("replace_type");
        d.replaceChance = Math.max(0, Math.min(100, s.getDouble("replace_chance", 0)));
        MobDefinition.assign(d.effects, s.getStringList("effects"));
        MobDefinition.assign(d.onSpawn, s.getStringList("on_spawn"));
        MobDefinition.assign(d.onHit, s.getStringList("on_hit"));
        MobDefinition.assign(d.onDamaged, s.getStringList("on_damaged"));
        MobDefinition.assign(d.onDeath, s.getStringList("on_death"));
        MobDefinition.assign(d.onKill, s.getStringList("on_kill"));
        MobDefinition.assign(d.timers, s.getStringList("timers"));
        MobDefinition.assign(d.phases, s.getStringList("phases"));
        MobDefinition.assign(d.loot, s.getStringList("loot"));
        MobDefinition.assign(d.worlds, s.getStringList("worlds"));
        if (MobManager.resolveType(d.type) == null) {
            logger.warning("Mob '" + id + "' uses unknown entity type '" + d.type + "' and cannot spawn until it is fixed.");
        }
        return d;
    }

    @Override
    protected void write(MobDefinition d, ConfigurationSection s) {
        s.set("name", d.name);
        s.set("tier", d.tier.text());
        s.set("type", d.type);
        Map<String, String> attributes = new LinkedHashMap<>(d.attributes);
        for (Map.Entry<String, String> entry : attributes.entrySet()) {
            s.set("attributes." + entry.getKey(), entry.getValue());
        }
        if (d.size > 0) {
            s.set("size", d.size);
        }
        s.set("baby", d.baby);
        s.set("glow", d.glow);
        s.set("silent", d.silent);
        s.set("invulnerable", d.invulnerable);
        s.set("invisible", d.invisible);
        s.set("ai", d.ai);
        s.set("gravity", d.gravity);
        s.set("persistent", d.persistent);
        s.set("name_visible", d.nameVisible);
        setIfSet(s, "mainhand", d.mainhand);
        setIfSet(s, "offhand", d.offhand);
        setIfSet(s, "helmet", d.helmet);
        setIfSet(s, "chestplate", d.chestplate);
        setIfSet(s, "leggings", d.leggings);
        setIfSet(s, "boots", d.boots);
        s.set("equipment_drop", d.equipmentDrop);
        setIfSet(s, "rider", d.rider);
        s.set("effects", new ArrayList<>(d.effects));
        s.set("on_spawn", new ArrayList<>(d.onSpawn));
        s.set("on_hit", new ArrayList<>(d.onHit));
        s.set("on_damaged", new ArrayList<>(d.onDamaged));
        s.set("on_death", new ArrayList<>(d.onDeath));
        s.set("on_kill", new ArrayList<>(d.onKill));
        s.set("timers", new ArrayList<>(d.timers));
        s.set("phases", new ArrayList<>(d.phases));
        s.set("trigger_cooldown", d.triggerCooldown);
        s.set("active_range", d.activeRange);
        s.set("bossbar", d.bossbar);
        s.set("bar_color", d.barColor);
        s.set("bar_style", d.barStyle);
        s.set("bar_range", d.barRange);
        setIfSet(s, "bar_title", d.barTitle);
        s.set("loot", new ArrayList<>(d.loot));
        if (d.xp != null) {
            s.set("xp", d.xp.show());
        }
        s.set("vanilla_drops", d.vanillaDrops);
        setIfSet(s, "spawn_message", d.spawnMessage);
        setIfSet(s, "death_message", d.deathMessage);
        s.set("announce", d.announce);
        if (d.replaceType != null) {
            s.set("replace_type", d.replaceType);
            s.set("replace_chance", d.replaceChance);
        }
        s.set("worlds", new ArrayList<>(d.worlds));
    }

    private static void setIfSet(ConfigurationSection s, String key, String value) {
        if (value != null) {
            s.set(key, value);
        }
    }

    @Override
    protected String idOf(MobDefinition definition) {
        return definition.id;
    }
}
