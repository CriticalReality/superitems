package dev.superitems.mob;

import java.util.Locale;

/** How important a mob is. The tier sets sensible defaults for boss bars and despawning. */
public enum MobTier {
    ENEMY,
    MINIBOSS,
    BOSS;

    /** Parses a tier word, or returns null. */
    public static MobTier parse(String text) {
        if (text == null) {
            return null;
        }
        return switch (text.trim().toLowerCase(Locale.ROOT)) {
            case "enemy", "mob", "normal" -> ENEMY;
            case "miniboss", "mini_boss", "mini-boss", "mini" -> MINIBOSS;
            case "boss" -> BOSS;
            default -> null;
        };
    }

    /** Lowercase name used in files and messages. */
    public String text() {
        return name().toLowerCase(Locale.ROOT);
    }
}
