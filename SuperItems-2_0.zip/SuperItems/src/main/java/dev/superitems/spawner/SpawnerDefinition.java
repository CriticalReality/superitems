package dev.superitems.spawner;

/** A fixed point that keeps spawning one custom mob while players are near. Plain data. */
public final class SpawnerDefinition {
    /** The id used in commands and files. */
    public final String id;
    /** Id of the mob to spawn. */
    public String mob;
    /** World name. */
    public String world = "world";
    public double x;
    public double y;
    public double z;
    /** Seconds between spawn waves. */
    public double interval = 30;
    /** Mobs per wave. */
    public int amount = 1;
    /** Most live mobs from this spawner at once. */
    public int max = 3;
    /** Mobs appear up to this many blocks away from the point. */
    public double radius = 3;
    /** The spawner only works while a player is within this many blocks. 0 means always. */
    public double range = 32;
    public boolean enabled = true;

    /** Creates a spawner with default settings. */
    public SpawnerDefinition(String id) {
        this.id = id;
    }

    /** Returns an independent copy. */
    public SpawnerDefinition copy() {
        SpawnerDefinition other = new SpawnerDefinition(id);
        other.mob = mob;
        other.world = world;
        other.x = x;
        other.y = y;
        other.z = z;
        other.interval = interval;
        other.amount = amount;
        other.max = max;
        other.radius = radius;
        other.range = range;
        other.enabled = enabled;
        return other;
    }
}
