package dev.superitems.spawner;

import dev.superitems.store.YamlStore;
import java.io.File;
import java.util.logging.Logger;
import org.bukkit.configuration.ConfigurationSection;

/** Holds spawner points and persists them to spawners.yml. */
public final class SpawnerStore extends YamlStore<SpawnerDefinition> {
    /** Creates a store backed by the given file. */
    public SpawnerStore(File file, Logger logger) {
        super(file, logger, "spawners");
    }

    @Override
    protected SpawnerDefinition read(String id, ConfigurationSection s) {
        String mob = s.getString("mob");
        if (mob == null || mob.isBlank()) {
            logger.warning("Skipping spawner '" + id + "': it has no mob.");
            return null;
        }
        SpawnerDefinition d = new SpawnerDefinition(id);
        d.mob = mob;
        d.world = s.getString("world", "world");
        d.x = s.getDouble("x");
        d.y = s.getDouble("y");
        d.z = s.getDouble("z");
        d.interval = Math.max(1, s.getDouble("interval", 30));
        d.amount = Math.max(1, s.getInt("amount", 1));
        d.max = Math.max(1, s.getInt("max", 3));
        d.radius = Math.max(0, s.getDouble("radius", 3));
        d.range = Math.max(0, s.getDouble("range", 32));
        d.enabled = s.getBoolean("enabled", true);
        return d;
    }

    @Override
    protected void write(SpawnerDefinition d, ConfigurationSection s) {
        s.set("mob", d.mob);
        s.set("world", d.world);
        s.set("x", d.x);
        s.set("y", d.y);
        s.set("z", d.z);
        s.set("interval", d.interval);
        s.set("amount", d.amount);
        s.set("max", d.max);
        s.set("radius", d.radius);
        s.set("range", d.range);
        s.set("enabled", d.enabled);
    }

    @Override
    protected String idOf(SpawnerDefinition definition) {
        return definition.id;
    }
}
