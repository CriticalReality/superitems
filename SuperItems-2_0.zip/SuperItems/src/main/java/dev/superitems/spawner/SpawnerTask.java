package dev.superitems.spawner;

import dev.superitems.SuperItems;
import dev.superitems.mob.MobDefinition;
import dev.superitems.mob.MobManager;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

/** Spawns mobs at spawner points. Called a few times a second on the server thread. */
public final class SpawnerTask {
    private final SuperItems plugin;
    private final Map<String, Long> nextWave = new HashMap<>();

    /** Creates the task. */
    public SpawnerTask(SuperItems plugin) {
        this.plugin = plugin;
    }

    /** Checks every spawner and starts a wave when one is due. */
    public void tick() {
        long now = System.currentTimeMillis();
        for (SpawnerDefinition spawner : plugin.spawners().all()) {
            if (!spawner.enabled) {
                continue;
            }
            Long due = nextWave.get(spawner.id);
            if (due != null && now < due) {
                continue;
            }
            World world = plugin.getServer().getWorld(spawner.world);
            if (world == null || !world.isChunkLoaded((int) Math.floor(spawner.x) >> 4, (int) Math.floor(spawner.z) >> 4)) {
                continue;
            }
            Location center = new Location(world, spawner.x, spawner.y, spawner.z);
            if (spawner.range > 0 && !playerNear(world, center, spawner.range)) {
                continue;
            }
            nextWave.put(spawner.id, now + (long) (spawner.interval * 1000));
            MobDefinition mob = plugin.mobs().get(spawner.mob);
            if (mob == null) {
                plugin.getLogger().warning("Spawner '" + spawner.id + "' uses unknown mob '" + spawner.mob + "'.");
                continue;
            }
            int room = spawner.max - plugin.manager().countFromSpawner(spawner.id);
            int count = Math.min(spawner.amount, room);
            for (int i = 0; i < count; i++) {
                MobManager.SpawnResult result = plugin.manager().spawn(mob, scatter(center, spawner.radius), spawner.id);
                if (!result.ok()) {
                    plugin.getLogger().warning("Spawner '" + spawner.id + "': " + result.error());
                    break;
                }
            }
        }
    }

    /** Forgets wave timers, for example after a reload. */
    public void reset() {
        nextWave.clear();
    }

    private static Location scatter(Location center, double radius) {
        if (radius <= 0) {
            return center.clone();
        }
        ThreadLocalRandom random = ThreadLocalRandom.current();
        double angle = random.nextDouble() * Math.PI * 2;
        double distance = random.nextDouble() * radius;
        return center.clone().add(Math.cos(angle) * distance, 0, Math.sin(angle) * distance);
    }

    private static boolean playerNear(World world, Location center, double range) {
        double limit = range * range;
        for (Player player : world.getPlayers()) {
            if (player.getLocation().distanceSquared(center) <= limit) {
                return true;
            }
        }
        return false;
    }
}
