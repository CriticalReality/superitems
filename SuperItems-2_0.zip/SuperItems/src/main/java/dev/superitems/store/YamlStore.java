package dev.superitems.store;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

/** Holds definitions in memory and persists them under one root key of a yaml file. */
public abstract class YamlStore<T> {
    private final File file;
    private final String root;
    /** Logger for warnings about broken entries. */
    protected final Logger logger;
    private Map<String, T> entries = new LinkedHashMap<>();

    /** Creates a store backed by the given file. Call load to read it. */
    protected YamlStore(File file, Logger logger, String root) {
        this.file = file;
        this.logger = logger;
        this.root = root;
    }

    /** Builds one definition from its yaml section, or returns null (after warning) when it is broken. */
    protected abstract T read(String id, ConfigurationSection section);

    /** Writes one definition into an empty yaml section. */
    protected abstract void write(T definition, ConfigurationSection section);

    /** Returns the id of a definition. */
    protected abstract String idOf(T definition);

    /** Reads the file and replaces the entries in memory. Broken entries are skipped with a warning. */
    public void load() {
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        Map<String, T> loaded = new LinkedHashMap<>();
        ConfigurationSection section = yaml.getConfigurationSection(root);
        if (section != null) {
            for (String id : section.getKeys(false)) {
                ConfigurationSection child = section.getConfigurationSection(id);
                T definition = child == null ? null : read(id, child);
                if (definition != null) {
                    loaded.put(id, definition);
                }
            }
        }
        entries = loaded;
    }

    /** Writes every definition to the file. */
    public void save() throws IOException {
        YamlConfiguration yaml = new YamlConfiguration();
        for (T definition : entries.values()) {
            ConfigurationSection section = yaml.createSection(root + "." + idOf(definition));
            write(definition, section);
        }
        yaml.save(file);
    }

    /** Returns a definition or null. */
    public T get(String id) {
        return entries.get(id);
    }

    /** True when the id exists. */
    public boolean contains(String id) {
        return entries.containsKey(id);
    }

    /** Adds or replaces a definition. */
    public void put(T definition) {
        entries.put(idOf(definition), definition);
    }

    /** Removes a definition and returns whether it existed. */
    public boolean remove(String id) {
        return entries.remove(id) != null;
    }

    /** Every id, in file order. */
    public List<String> ids() {
        return new ArrayList<>(entries.keySet());
    }

    /** A snapshot of every definition. */
    public Collection<T> all() {
        return List.copyOf(entries.values());
    }
}
