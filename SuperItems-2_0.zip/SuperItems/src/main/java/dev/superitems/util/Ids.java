package dev.superitems.util;

/** Rules for the ids used by items, sets, mobs, loot tables and spawners. */
public final class Ids {
    private Ids() {}

    /** Returns true when the id only uses lowercase letters, digits, underscores and dashes (1 to 32 characters). */
    public static boolean isValid(String id) {
        return id != null && id.matches("[a-z0-9_-]{1,32}");
    }
}
