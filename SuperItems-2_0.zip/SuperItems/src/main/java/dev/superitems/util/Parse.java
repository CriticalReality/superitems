package dev.superitems.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Small parsing helpers shared by every flag editor. */
public final class Parse {
    private static final Set<String> CLEAR_WORDS = Set.of("none", "clear", "off", "-");

    private Parse() {}

    /** Returns true when the value means "remove everything" (none, clear, off or a dash). */
    public static boolean isClear(String text) {
        return text != null && CLEAR_WORDS.contains(text.trim().toLowerCase(Locale.ROOT));
    }

    /** Parses true/false style words. An empty value counts as true so a bare flag switches something on. Returns null when invalid. */
    public static Boolean bool(String text) {
        String value = text == null ? "" : text.trim().toLowerCase(Locale.ROOT);
        return switch (value) {
            case "", "true", "yes", "on" -> Boolean.TRUE;
            case "false", "no", "off" -> Boolean.FALSE;
            default -> null;
        };
    }

    /** Parses a finite number, or returns null. */
    public static Double number(String text) {
        if (text == null) {
            return null;
        }
        try {
            double value = Double.parseDouble(text.trim());
            return Double.isFinite(value) ? value : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** Parses a whole number, or returns null. */
    public static Integer integer(String text) {
        if (text == null) {
            return null;
        }
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** Several flags add lines; a value of none clears everything before it. A bar splits one value into lines. */
    public static List<String> lines(List<String> values) {
        List<String> out = new ArrayList<>();
        for (String value : values) {
            if (isClear(value)) {
                out.clear();
                continue;
            }
            for (String line : value.split("\\|")) {
                if (!line.isBlank()) {
                    out.add(line.strip());
                }
            }
        }
        return out;
    }

    /** Several flags add entries; a value of none clears everything before it. Each value is kept whole. */
    public static List<String> entries(List<String> values) {
        List<String> out = new ArrayList<>();
        for (String value : values) {
            if (isClear(value)) {
                out.clear();
            } else if (!value.isBlank()) {
                out.add(value.strip());
            }
        }
        return out;
    }

    /** Like entries, but starts from existing values so flags add to them. A value of none clears first. */
    public static List<String> entriesOnTop(List<String> existing, List<String> values) {
        List<String> out = new ArrayList<>(existing);
        for (String value : values) {
            if (isClear(value)) {
                out.clear();
            } else if (!value.isBlank()) {
                out.add(value.strip());
            }
        }
        return out;
    }

    /** Splits a comma separated list, dropping blanks. A clear word gives an empty list. */
    public static List<String> commaList(String text) {
        List<String> out = new ArrayList<>();
        if (text == null || isClear(text)) {
            return out;
        }
        for (String part : text.split(",")) {
            if (!part.isBlank()) {
                out.add(part.strip());
            }
        }
        return out;
    }
}
