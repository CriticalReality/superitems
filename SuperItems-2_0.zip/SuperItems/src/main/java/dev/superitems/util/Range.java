package dev.superitems.util;

import java.util.Locale;
import java.util.Random;

/** A number or a span of numbers such as 3 or 1-5 (also written 1..5). */
public record Range(double min, double max) {
    /** Creates a range, swapping the ends when they are the wrong way round. */
    public Range {
        if (min > max) {
            double swap = min;
            min = max;
            max = swap;
        }
    }

    /** Parses 5, 1-3, 1..3 or 0.5-2.5. Returns null when the text is not a range. */
    public static Range parse(String text) {
        if (text == null || text.isBlank()) {
            return null;
        }
        String value = text.trim().toLowerCase(Locale.ROOT).replace("..", "~");
        int split = value.indexOf('~');
        if (split < 0) {
            split = value.indexOf('-', 1);
        }
        try {
            if (split < 0) {
                double single = Double.parseDouble(value);
                return Double.isFinite(single) ? new Range(single, single) : null;
            }
            double low = Double.parseDouble(value.substring(0, split));
            double high = Double.parseDouble(value.substring(split + 1));
            return Double.isFinite(low) && Double.isFinite(high) ? new Range(low, high) : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** Picks a random value from min to max. */
    public double roll(Random random) {
        return min == max ? min : min + random.nextDouble() * (max - min);
    }

    /** Picks a random whole number from min to max, both included. */
    public int rollInt(Random random) {
        int low = (int) Math.ceil(min);
        int high = (int) Math.floor(max);
        if (high < low) {
            return low;
        }
        return low == high ? low : low + random.nextInt(high - low + 1);
    }

    /** True when the range is a single value. */
    public boolean isSingle() {
        return min == max;
    }

    /** Short text such as 3 or 1-5. */
    public String show() {
        return min == max ? trim(min) : trim(min) + "-" + trim(max);
    }

    private static String trim(double value) {
        return value == Math.rint(value) ? String.valueOf((long) value) : String.valueOf(value);
    }
}
