package dev.superitems;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import dev.superitems.item.ItemDefinition;
import dev.superitems.loot.LootResult;
import dev.superitems.mob.MobDefinition;
import dev.superitems.mob.MobTier;
import org.bukkit.Material;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockbukkit.mockbukkit.MockBukkit;
import org.mockbukkit.mockbukkit.ServerMock;

class NewFeaturesTest {
    private ServerMock server;
    private SuperItems plugin;

    @BeforeEach
    void startPlugin() {
        server = MockBukkit.mock();
        server.addSimpleWorld("world");
        plugin = MockBukkit.load(SuperItems.class);
    }

    @AfterEach
    void stopPlugin() {
        MockBukkit.unmock();
    }

    private void run(String command) {
        server.dispatchCommand(server.getConsoleSender(), command);
    }

    @Test
    void armorCreateMakesAWearablePieceWithStats() {
        run("superitems armor create helm --piece helmet --tier diamond --armor 5 --health 4 --unbreakable");

        ItemDefinition item = plugin.items().get("helm");
        assertNotNull(item);
        assertEquals(Material.DIAMOND_HELMET, item.getMaterial());
        assertTrue(item.isUnbreakable());
        assertTrue(item.getAttributes().contains("armor 5 add auto"));
        assertTrue(item.getAttributes().contains("max_health 4 add auto"));
    }

    @Test
    void armorRejectsMaterialsThatCannotBeWorn() {
        run("superitems armor create bad --material stick");
        assertNull(plugin.items().get("bad"));
    }

    @Test
    void itemsGainDamageRangeAndTriggers() {
        run("superitems create blade --material iron_sword --damage 400-600 --on_hit say hit %target%");

        ItemDefinition item = plugin.items().get("blade");
        assertTrue(item.hasDamageRange());
        assertEquals(400, item.getDamageMin());
        assertEquals(600, item.getDamageMax());
        assertEquals(1, item.getOnHit().size());
    }

    @Test
    void setNeedsExistingPieces() {
        run("superitems set create ghost --pieces nothing_here");
        assertNull(plugin.sets().get("ghost"));

        run("superitems armor create a --piece helmet --tier iron");
        run("superitems armor create b --piece boots --tier iron");
        run("superitems set create duo --pieces a,b --bonus 2 effect give @s minecraft:speed 3 0 true");

        assertEquals(2, plugin.sets().get("duo").getPieces().size());
        assertEquals(1, plugin.sets().get("duo").getBonus().size());
    }

    @Test
    void mobCreateStoresStatsTiersAndAbilities() {
        run("superitems mob create king --tier boss --type wither_skeleton --name Skeleton King --health 600 --damage 12 --speed 1.3x"
                + " --timer 10 say roar --phase 50 say enraged --effect strength 1 infinite --replace skeleton 5");

        MobDefinition mob = plugin.mobs().get("king");
        assertNotNull(mob);
        assertEquals(MobTier.BOSS, mob.tier);
        assertEquals("wither_skeleton", mob.type);
        assertTrue(mob.bossbar);
        assertTrue(mob.persistent);
        assertEquals("600", mob.attributes.get("max_health"));
        assertEquals("1.3x", mob.attributes.get("movement_speed"));
        assertEquals(1, mob.timers.size());
        assertEquals(1, mob.phases.size());
        assertEquals("skeleton", mob.replaceType);
        assertEquals(5, mob.replaceChance);
    }

    @Test
    void mobRejectsBadInputAndCreatesNothing() {
        run("superitems mob create a --type not_a_mob");
        run("superitems mob create b --tier legend");
        run("superitems mob create c --phase 500 say x");
        run("superitems mob create d --loot missing_table");
        assertTrue(plugin.mobs().ids().isEmpty());
    }

    @Test
    void mobsSurviveReloadFromDisk() {
        run("superitems mob create grunt --type zombie --health 40 --on_death say bye");
        plugin.mobs().load();
        MobDefinition mob = plugin.mobs().get("grunt");
        assertNotNull(mob);
        assertEquals("40", mob.attributes.get("max_health"));
        assertEquals(1, mob.onDeath.size());
    }

    @Test
    void lootTablesValidateEntriesAndRoll() {
        run("superitems loot create bad --entry 10 item:nope");
        assertNull(plugin.loot().get("bad"));

        run("superitems loot create gems --rolls 1 --always 1 vanilla:diamond 2 --entry 5 nothing");
        assertNotNull(plugin.loot().get("gems"));

        LootResult result = plugin.roller().roll("gems");
        assertEquals(1, result.items().size());
        assertEquals(Material.DIAMOND, result.items().get(0).getType());
        assertEquals(2, result.items().get(0).getAmount());
    }

    @Test
    void lootEditAddsEntriesAndNoneClears() {
        run("superitems loot create pool --entry 5 vanilla:apple");
        run("superitems loot edit pool --entry 5 vanilla:bread");
        assertEquals(2, plugin.loot().get("pool").getEntries().size());

        run("superitems loot edit pool --entry none --entry 1 vanilla:gold_ingot");
        assertEquals(1, plugin.loot().get("pool").getEntries().size());
    }

    @Test
    void nestedLootTablesRollTheTableTheyName() {
        run("superitems loot create rare --always 1 vanilla:nether_star");
        run("superitems loot create common --always 1 table:rare");

        LootResult result = plugin.roller().roll("common");
        assertEquals(1, result.items().size());
        assertEquals(Material.NETHER_STAR, result.items().get(0).getType());
        assertFalse(result.problems().iterator().hasNext());
    }

    @Test
    void spawnerNeedsAMobAndAPlace() {
        run("superitems spawner create s1 --mob nothing");
        assertNull(plugin.spawners().get("s1"));

        run("superitems mob create grunt --type zombie");
        run("superitems spawner create s2 --mob grunt");
        assertNull(plugin.spawners().get("s2"));

        run("superitems spawner create s3 --mob grunt --location 1 64 1 world --interval 20 --max 4");
        assertNotNull(plugin.spawners().get("s3"));
        assertEquals(4, plugin.spawners().get("s3").max);
    }
}
