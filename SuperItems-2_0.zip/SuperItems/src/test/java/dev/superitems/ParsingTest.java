package dev.superitems;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import dev.superitems.action.NumberedCommand;
import dev.superitems.command.FlagParser;
import dev.superitems.command.Specs;
import dev.superitems.loot.LootEntry;
import dev.superitems.util.Range;
import java.util.List;
import org.junit.jupiter.api.Test;

class ParsingTest {
    @Test
    void rangesAcceptSingleValuesAndSpans() {
        assertEquals(new Range(1, 3), Range.parse("1-3"));
        assertEquals(new Range(5, 5), Range.parse("5"));
        assertEquals(new Range(0.5, 2), Range.parse("0.5..2"));
        assertNull(Range.parse("abc"));
    }

    @Test
    void numberedCommandsNeedANumberAndACommand() {
        assertEquals(new NumberedCommand(50, "say half"), NumberedCommand.parse("50 say half"));
        assertNull(NumberedCommand.parse("say half"));
        assertNull(NumberedCommand.parse("50"));
    }

    @Test
    void lootEntriesParseKindsAmountsAndChances() {
        LootEntry entry = LootEntry.parse("10 item:Blade 1-2 chance=25");
        assertEquals(LootEntry.Kind.ITEM, entry.kind());
        assertEquals("blade", entry.ref());
        assertEquals(new Range(1, 2), entry.amount());
        assertEquals(25, entry.chance());
        assertEquals(LootEntry.Kind.COMMAND, LootEntry.parse("3 command:give %player% apple 2").kind());
        assertEquals(LootEntry.Kind.NOTHING, LootEntry.parse("40 nothing").kind());
        assertThrows(IllegalArgumentException.class, () -> LootEntry.parse("10 bogus:x"));
        assertThrows(IllegalArgumentException.class, () -> LootEntry.parse("10 item:x chance=500"));
    }

    @Test
    void mobFlagsRepeatAndKeepWholeCommands() {
        FlagParser.Result parsed = FlagParser.parse("m --timer 5 say a --timer 10 say b --phase 50 say half".split(" "), Specs.MOB);
        assertEquals(List.of("5 say a", "10 say b"), parsed.all("timer"));
        assertEquals(List.of("50 say half"), parsed.all("phase"));
        assertEquals(List.of("m"), parsed.positional());
    }
}
