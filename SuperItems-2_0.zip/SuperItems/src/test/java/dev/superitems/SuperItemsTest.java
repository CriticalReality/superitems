package dev.superitems;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import dev.superitems.item.ConsumeMode;
import dev.superitems.item.ItemDefinition;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import org.bukkit.Material;
import org.bukkit.block.BlockFace;
import org.bukkit.event.Event;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockbukkit.mockbukkit.MockBukkit;
import org.mockbukkit.mockbukkit.ServerMock;
import org.mockbukkit.mockbukkit.entity.PlayerMock;

class SuperItemsTest {

    private static final String FROG_STICK = "superitems create fs --name frog stick --description big hopppps"
            + " --on_right_click effect give @p minecraft:jump_boost 3 3 true"
            + " --on_left_click playsound minecraft:entity.frog.ambient master @a ~ ~ ~";

    private ServerMock server;
    private SuperItems plugin;
    private final List<String> dispatched = new ArrayList<>();

    @BeforeEach
    void startPlugin() {
        server = MockBukkit.mock();
        plugin = MockBukkit.load(SuperItems.class);
        plugin.runner().setDispatcher((sender, command) -> dispatched.add(command));
    }

    @AfterEach
    void stopPlugin() {
        MockBukkit.unmock();
    }

    @Test
    void createReadsEveryFlagIncludingWholeCommands() {
        server.dispatchCommand(server.getConsoleSender(), FROG_STICK);

        ItemDefinition item = plugin.items().get("fs");
        assertNotNull(item);
        assertEquals("frog stick", item.getName());
        assertEquals(Material.STICK, item.getMaterial());
        assertEquals(List.of("big hopppps"), item.getDescription());
        assertEquals(List.of("effect give @p minecraft:jump_boost 3 3 true"), item.getOnRightClick());
        assertEquals(List.of("playsound minecraft:entity.frog.ambient master @a ~ ~ ~"), item.getOnLeftClick());
    }

    @Test
    void itemsSurviveReloadFromDisk() {
        server.dispatchCommand(server.getConsoleSender(), FROG_STICK + " --consume right --cooldown 2.5");

        plugin.items().load();

        ItemDefinition item = plugin.items().get("fs");
        assertNotNull(item);
        assertEquals("frog stick", item.getName());
        assertEquals(ConsumeMode.RIGHT, item.getConsume());
        assertEquals(2.5, item.getCooldownSeconds());
    }

    @Test
    void invalidInputCreatesNothing() {
        server.dispatchCommand(server.getConsoleSender(), "superitems create bad --material not_a_real_item");
        server.dispatchCommand(server.getConsoleSender(), "superitems create bad2 --bogus 1");
        server.dispatchCommand(server.getConsoleSender(), "superitems create Bad Id --name x");

        assertTrue(plugin.items().ids().isEmpty());
    }

    @Test
    void editChangesOnlyTheGivenFlagsAndNoneClears() {
        server.dispatchCommand(server.getConsoleSender(), FROG_STICK);

        server.dispatchCommand(server.getConsoleSender(), "superitems edit fs --name Frog Stick --on_left_click none");

        ItemDefinition item = plugin.items().get("fs");
        assertEquals("Frog Stick", item.getName());
        assertTrue(item.getOnLeftClick().isEmpty());
        assertEquals(1, item.getOnRightClick().size());
    }

    @Test
    void deleteRemovesTheItem() {
        server.dispatchCommand(server.getConsoleSender(), FROG_STICK);
        server.dispatchCommand(server.getConsoleSender(), "superitems delete fs");
        assertNull(plugin.items().get("fs"));
    }

    @Test
    void giveCreatesTaggedItems() {
        server.dispatchCommand(server.getConsoleSender(), FROG_STICK);
        PlayerMock player = server.addPlayer();

        server.dispatchCommand(server.getConsoleSender(), "superitems give fs " + player.getName() + " 3");

        ItemStack given = Arrays.stream(player.getInventory().getContents())
                .filter(Objects::nonNull)
                .filter(stack -> "fs".equals(plugin.factory().idOf(stack)))
                .findFirst()
                .orElseThrow();
        assertEquals(3, given.getAmount());
        assertEquals(Material.STICK, given.getType());
    }

    @Test
    void rightClickRunsCommandAsThePlayerAndCancelsTheClick() {
        server.dispatchCommand(server.getConsoleSender(), FROG_STICK);
        PlayerMock player = server.addPlayer();
        ItemStack stick = plugin.factory().create(plugin.items().get("fs"), 1);
        player.getInventory().setItemInMainHand(stick);

        PlayerInteractEvent event = click(player, Action.RIGHT_CLICK_AIR, stick);

        String name = player.getName();
        assertEquals(List.of("execute as " + name + " at " + name + " run effect give @p minecraft:jump_boost 3 3 true"), dispatched);
        assertEquals(Event.Result.DENY, event.useItemInHand());
    }

    @Test
    void leftClickRunsTheLeftCommand() {
        server.dispatchCommand(server.getConsoleSender(), FROG_STICK);
        PlayerMock player = server.addPlayer();
        ItemStack stick = plugin.factory().create(plugin.items().get("fs"), 1);
        player.getInventory().setItemInMainHand(stick);

        click(player, Action.LEFT_CLICK_AIR, stick);

        assertEquals(1, dispatched.size());
        assertTrue(dispatched.get(0).endsWith("run playsound minecraft:entity.frog.ambient master @a ~ ~ ~"));
    }

    @Test
    void prefixesChooseWhoRunsTheCommand() {
        server.dispatchCommand(server.getConsoleSender(),
                "superitems create pf --on_right_click raw:say hi %player% --on_right_click player:/spawn");
        PlayerMock player = server.addPlayer();
        ItemStack item = plugin.factory().create(plugin.items().get("pf"), 1);
        player.getInventory().setItemInMainHand(item);

        click(player, Action.RIGHT_CLICK_AIR, item);

        assertEquals(List.of("say hi " + player.getName(), "spawn"), dispatched);
    }

    @Test
    void consumeRemovesOneItemPerUse() {
        server.dispatchCommand(server.getConsoleSender(), FROG_STICK + " --consume right");
        PlayerMock player = server.addPlayer();
        ItemStack stack = plugin.factory().create(plugin.items().get("fs"), 2);
        player.getInventory().setItemInMainHand(stack);

        click(player, Action.RIGHT_CLICK_AIR, stack);

        assertEquals(1, player.getInventory().getItemInMainHand().getAmount());
    }

    @Test
    void cooldownBlocksRepeatedUse() {
        server.dispatchCommand(server.getConsoleSender(), FROG_STICK + " --cooldown 60");
        PlayerMock player = server.addPlayer();
        ItemStack stick = plugin.factory().create(plugin.items().get("fs"), 1);
        player.getInventory().setItemInMainHand(stick);

        click(player, Action.RIGHT_CLICK_AIR, stick);
        click(player, Action.RIGHT_CLICK_AIR, stick);

        assertEquals(1, dispatched.size());
    }

    @Test
    void ordinaryItemsAndDeletedItemsDoNothing() {
        server.dispatchCommand(server.getConsoleSender(), FROG_STICK);
        PlayerMock player = server.addPlayer();
        ItemStack plain = new ItemStack(Material.STICK);
        ItemStack tagged = plugin.factory().create(plugin.items().get("fs"), 1);
        server.dispatchCommand(server.getConsoleSender(), "superitems delete fs");

        click(player, Action.RIGHT_CLICK_AIR, plain);
        click(player, Action.RIGHT_CLICK_AIR, tagged);

        assertTrue(dispatched.isEmpty());
    }

    private PlayerInteractEvent click(PlayerMock player, Action action, ItemStack item) {
        PlayerInteractEvent event = new PlayerInteractEvent(player, action, item, null, BlockFace.SELF, EquipmentSlot.HAND);
        server.getPluginManager().callEvent(event);
        return event;
    }
}
