# SuperItems

Create custom items in game. Each item has a name, description, and commands that run on left click and right click.

Permission: `superitems.admin` (operators by default). Command aliases: `/sitems`, `/si`.

## Commands

| Command | What it does |
| --- | --- |
| `/superitems create <id> [flags]` | Make a new item |
| `/superitems edit <id> [flags]` | Change flags on an existing item |
| `/superitems give <id> [player] [amount]` | Give copies (the console must name a player) |
| `/superitems info <id>` | Show every setting |
| `/superitems list` | List all items |
| `/superitems delete <id>` | Delete an item (copies already given stop working) |
| `/superitems reload` | Reload `config.yml` and `items.yml` |

## Flags

Everything after a flag, up to the next flag, is its value, so values can contain spaces and full commands.

| Flag | Meaning |
| --- | --- |
| `--name <text>` | Display name |
| `--description <text>` | Lore. Repeat the flag or split with `\|` for several lines |
| `--material <item>` | Base item, default `stick` (set in `config.yml`) |
| `--on_right_click <command>` | Command to run on right click. Repeat the flag for several commands |
| `--on_left_click <command>` | Command to run on left click (air, block, or hitting an entity) |
| `--consume none\|right\|left\|both` | Remove one item after that click |
| `--cooldown <seconds>` | Per player cooldown |
| `--glow [true\|false]` | Enchantment glint |
| `--model <key>` | Item model, e.g. `minecraft:dead_brain_coral`, so a non-placeable base item looks like a block |
| `--cancel <true\|false>` | Cancel the click so the base item does not also place, break or attack. Default true |

Shortcuts: `--lore`, `--right`, `--left`. Dashes work too: `--on-right-click`.
Use `none` as a value on `edit` to clear a flag (`--on_left_click none`).
Text supports `&` color codes or MiniMessage tags like `<green>`.

## How commands run

- A normal line runs from the console **as the player, at the player's position**, so `@p`, `@s` and `~ ~ ~` work:
  `effect give @p minecraft:jump_boost 3 3 true`
- `player:<command>` runs as the player, with their own permissions.
- `raw:<command>` runs from the console exactly as written.
- `%player%` becomes the player's name in every form.

## Example

```
/superitems create fs --name frog stick --description big hopppps --on_right_click effect give @p minecraft:jump_boost 3 3 true --on_left_click playsound minecraft:entity.frog.ambient master @a ~ ~ ~
/superitems give fs
```

A dead brain coral that runs a command and is used up:

```
/superitems create coral --name Mystic Coral --material paper --model minecraft:dead_brain_coral --consume right --on_right_click say %player% used the coral
```

## Files

- `plugins/SuperItems/items.yml` – saved items (edit by hand, then `/superitems reload`)
- `plugins/SuperItems/config.yml` – default material and cooldown message

## Code layout

Each subcommand is its own class in `dev.superitems.command`. To add one, implement `Subcommand` and add it to the list in `SuperItems.onEnable`.
`FlagParser` splits arguments, `DefinitionEditor` applies flags, `ActionRunner` runs click commands, `ItemUseListener` handles clicks.
