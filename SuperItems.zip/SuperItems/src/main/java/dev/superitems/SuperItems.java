package dev.superitems;

import dev.superitems.action.ActionRunner;
import dev.superitems.action.CooldownTracker;
import dev.superitems.command.CreateSubcommand;
import dev.superitems.command.DeleteSubcommand;
import dev.superitems.command.EditSubcommand;
import dev.superitems.command.GiveSubcommand;
import dev.superitems.command.InfoSubcommand;
import dev.superitems.command.ListSubcommand;
import dev.superitems.command.ReloadSubcommand;
import dev.superitems.command.SuperItemsCommand;
import dev.superitems.item.ItemFactory;
import dev.superitems.item.ItemStore;
import dev.superitems.listener.ItemUseListener;
import dev.superitems.util.Text;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.logging.Level;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

/** Create custom items in game that run commands when left or right clicked. */
public class SuperItems extends JavaPlugin {
    private ItemStore items;
    private ItemFactory factory;
    private ActionRunner runner;
    private CooldownTracker cooldowns;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        items = new ItemStore(new File(getDataFolder(), "items.yml"), getLogger());
        items.load();
        factory = new ItemFactory(this);
        runner = new ActionRunner(getLogger());
        cooldowns = new CooldownTracker();

        getServer().getPluginManager().registerEvents(new ItemUseListener(this), this);

        SuperItemsCommand command = new SuperItemsCommand(List.of(
                new CreateSubcommand(this),
                new EditSubcommand(this),
                new DeleteSubcommand(this),
                new GiveSubcommand(this),
                new ListSubcommand(this),
                new InfoSubcommand(this),
                new ReloadSubcommand(this)));
        PluginCommand pluginCommand = Objects.requireNonNull(getCommand("superitems"));
        pluginCommand.setExecutor(command);
        pluginCommand.setTabCompleter(command);
        getLogger().info("Loaded " + items.ids().size() + " super item(s).");
    }

    /** The item definitions. */
    public ItemStore items() {
        return items;
    }

    /** Builds and recognizes item stacks. */
    public ItemFactory factory() {
        return factory;
    }

    /** Runs click commands. */
    public ActionRunner runner() {
        return runner;
    }

    /** Per player item cooldowns. */
    public CooldownTracker cooldowns() {
        return cooldowns;
    }

    /** Reloads config.yml and items.yml from disk. */
    public void reloadAll() {
        reloadConfig();
        items.load();
    }

    /** Material used by create when no material flag is given. */
    public Material defaultMaterial() {
        Material material = Material.matchMaterial(getConfig().getString("default-material", "STICK"));
        return material != null && material.isItem() && !material.isAir() ? material : Material.STICK;
    }

    /** Saves items.yml and tells the sender when it fails. */
    public boolean saveItems(CommandSender sender) {
        try {
            items.save();
            return true;
        } catch (IOException e) {
            getLogger().log(Level.SEVERE, "Could not save items.yml", e);
            Text.error(sender, "Could not save items.yml (see console). The change works until the next restart.");
            return false;
        }
    }
}
