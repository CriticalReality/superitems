package dev.superitems.action;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Runs the command lines attached to an item click.
 *
 * A plain line runs from the console as the clicking player, standing where they stand,
 * so selectors like @p, @s and relative coordinates work. A line starting with player: runs
 * as the player with their own permissions. A line starting with raw: runs from the console
 * exactly as written. In every form the text %player% is replaced with the player's name.
 */
public final class ActionRunner {
    /** Sends one command line to the server. Replaceable so tests can record commands. */
    public interface Dispatcher {
        /** Runs the command and returns whether the server accepted it. */
        boolean dispatch(CommandSender sender, String command);
    }

    private static final String PLAYER_PREFIX = "player:";
    private static final String RAW_PREFIX = "raw:";

    private final Logger logger;
    private Dispatcher dispatcher = Bukkit::dispatchCommand;

    /** Creates a runner that logs failures to the given logger. */
    public ActionRunner(Logger logger) {
        this.logger = logger;
    }

    /** Swaps how commands reach the server. */
    public void setDispatcher(Dispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    /** Runs every command line for the given player. */
    public void run(Player player, List<String> commands) {
        for (String command : commands) {
            runOne(player, command);
        }
    }

    private void runOne(Player player, String command) {
        String text = command.strip();
        try {
            if (hasPrefix(text, PLAYER_PREFIX)) {
                dispatcher.dispatch(player, fill(text.substring(PLAYER_PREFIX.length()), player));
            } else if (hasPrefix(text, RAW_PREFIX)) {
                dispatcher.dispatch(Bukkit.getConsoleSender(), fill(text.substring(RAW_PREFIX.length()), player));
            } else {
                String name = player.getName();
                dispatcher.dispatch(Bukkit.getConsoleSender(),
                        "execute as " + name + " at " + name + " run " + fill(text, player));
            }
        } catch (RuntimeException e) {
            logger.log(Level.WARNING, "Item command failed: " + command, e);
        }
    }

    private static boolean hasPrefix(String text, String prefix) {
        return text.regionMatches(true, 0, prefix, 0, prefix.length());
    }

    private static String fill(String command, Player player) {
        String text = command.strip();
        if (text.startsWith("/")) {
            text = text.substring(1);
        }
        return text.replace("%player%", player.getName());
    }
}
