package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.item.ItemDefinition;
import dev.superitems.item.ItemStore;
import dev.superitems.util.Text;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;

/** Creates a new item from flags. */
public final class CreateSubcommand implements Subcommand {
    private static final String USAGE = "create <id> [--name text] [--description text] [--material item] "
            + "[--on_right_click command] [--on_left_click command] [--consume none|right|left|both] "
            + "[--cooldown seconds] [--glow] [--model key] [--cancel true|false]";

    private final SuperItems plugin;

    /** Creates the subcommand. */
    public CreateSubcommand(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String name() {
        return "create";
    }

    @Override
    public String usage() {
        return USAGE;
    }

    @Override
    public String description() {
        return "Create a new item";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        FlagParser.Result parsed = FlagParser.parse(args);
        String problem = DefinitionEditor.syntaxProblem(parsed, USAGE);
        if (problem != null) {
            Text.error(sender, problem);
            return;
        }
        String id = parsed.positional().get(0).toLowerCase(Locale.ROOT);
        if (!ItemStore.isValidId(id)) {
            Text.error(sender, "The id may only use a-z, 0-9, _ and - (up to 32 characters).");
            return;
        }
        if (plugin.items().contains(id)) {
            Text.error(sender, "An item called '" + id + "' already exists. Use /superitems edit " + id + " to change it.");
            return;
        }
        ItemDefinition definition = new ItemDefinition(id, id, plugin.defaultMaterial());
        String error = DefinitionEditor.apply(definition, parsed);
        if (error != null) {
            Text.error(sender, error);
            return;
        }
        plugin.items().put(definition);
        plugin.saveItems(sender);
        Text.ok(sender, "Created '" + id + "'. Get it with /superitems give " + id);
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        return args.length <= 1 ? List.of() : FlagCompleter.complete(args);
    }
}
