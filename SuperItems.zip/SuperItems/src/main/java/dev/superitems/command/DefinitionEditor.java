package dev.superitems.command;

import dev.superitems.item.ConsumeMode;
import dev.superitems.item.ItemDefinition;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;

/** Applies parsed flags to an item definition. Shared by the create and edit subcommands. */
public final class DefinitionEditor {
    private static final Set<String> CLEAR_WORDS = Set.of("none", "clear", "off", "-");
    private static final Set<String> FLAGS_WITHOUT_VALUE = Set.of("glow", "cancel");

    private DefinitionEditor() {}

    /** Returns an error message when the words or flags are malformed, otherwise null. */
    public static String syntaxProblem(FlagParser.Result parsed, String usage) {
        if (!parsed.unknown().isEmpty()) {
            return "Unknown flag " + parsed.unknown().get(0) + ". Valid flags: --" + String.join(", --", FlagParser.FLAGS);
        }
        if (parsed.positional().size() != 1) {
            return "Expected the item id first, then flags like --name. Usage: /superitems " + usage;
        }
        return null;
    }

    /** Applies every flag that was given. Returns an error message, or null on success. Nothing is partly applied on error. */
    public static String apply(ItemDefinition definition, FlagParser.Result parsed) {
        for (String flag : parsed.flags().keySet()) {
            if (!FLAGS_WITHOUT_VALUE.contains(flag) && parsed.all(flag).stream().anyMatch(String::isEmpty)) {
                return "--" + flag + " needs a value.";
            }
        }

        // Work on a copy so an error halfway through leaves the real definition untouched.
        ItemDefinition draft = new ItemDefinition(definition.getId(), definition.getName(), definition.getMaterial());
        draft.setDescription(definition.getDescription());
        draft.setModel(definition.getModel());
        draft.setGlow(definition.isGlow());
        draft.setOnRightClick(definition.getOnRightClick());
        draft.setOnLeftClick(definition.getOnLeftClick());
        draft.setConsume(definition.getConsume());
        draft.setCooldownSeconds(definition.getCooldownSeconds());
        draft.setCancel(definition.isCancel());

        String problem = applyTo(draft, parsed);
        if (problem != null) {
            return problem;
        }

        definition.setName(draft.getName());
        definition.setDescription(draft.getDescription());
        definition.setMaterial(draft.getMaterial());
        definition.setModel(draft.getModel());
        definition.setGlow(draft.isGlow());
        definition.setOnRightClick(draft.getOnRightClick());
        definition.setOnLeftClick(draft.getOnLeftClick());
        definition.setConsume(draft.getConsume());
        definition.setCooldownSeconds(draft.getCooldownSeconds());
        definition.setCancel(draft.isCancel());
        return null;
    }

    private static String applyTo(ItemDefinition draft, FlagParser.Result parsed) {
        if (parsed.has("name")) {
            draft.setName(parsed.last("name"));
        }
        if (parsed.has("description")) {
            draft.setDescription(lines(parsed.all("description")));
        }
        if (parsed.has("material")) {
            String text = parsed.last("material");
            Material material = Material.matchMaterial(text);
            if (material == null || !material.isItem() || material.isAir()) {
                return "'" + text + "' is not an item material (try something like stick or blaze_rod).";
            }
            draft.setMaterial(material);
        }
        if (parsed.has("model")) {
            String text = parsed.last("model");
            if (isClear(text)) {
                draft.setModel(null);
            } else if (NamespacedKey.fromString(text.toLowerCase(Locale.ROOT)) == null) {
                return "'" + text + "' is not a valid model key (example: minecraft:dead_brain_coral).";
            } else {
                draft.setModel(text.toLowerCase(Locale.ROOT));
            }
        }
        if (parsed.has("glow")) {
            Boolean value = bool(parsed.last("glow"));
            if (value == null) {
                return "--glow must be true or false.";
            }
            draft.setGlow(value);
        }
        if (parsed.has("on_right_click")) {
            draft.setOnRightClick(commands(parsed.all("on_right_click")));
        }
        if (parsed.has("on_left_click")) {
            draft.setOnLeftClick(commands(parsed.all("on_left_click")));
        }
        if (parsed.has("consume")) {
            ConsumeMode mode = ConsumeMode.parse(parsed.last("consume"));
            if (mode == null) {
                return "--consume must be none, right, left or both.";
            }
            draft.setConsume(mode);
        }
        if (parsed.has("cooldown")) {
            try {
                double seconds = Double.parseDouble(parsed.last("cooldown"));
                if (!Double.isFinite(seconds) || seconds < 0) {
                    return "--cooldown must be a number of seconds, 0 or more.";
                }
                draft.setCooldownSeconds(seconds);
            } catch (NumberFormatException e) {
                return "--cooldown must be a number of seconds, 0 or more.";
            }
        }
        if (parsed.has("cancel")) {
            Boolean value = bool(parsed.last("cancel"));
            if (value == null) {
                return "--cancel must be true or false.";
            }
            draft.setCancel(value);
        }
        return null;
    }

    private static boolean isClear(String text) {
        return CLEAR_WORDS.contains(text.toLowerCase(Locale.ROOT));
    }

    /** Several flags add lines; a value of none clears everything before it. A bar splits one value into lines. */
    private static List<String> lines(List<String> values) {
        List<String> out = new ArrayList<>();
        for (String value : values) {
            if (isClear(value)) {
                out.clear();
                continue;
            }
            for (String line : value.split("\\|")) {
                if (!line.isBlank()) {
                    out.add(line.strip());
                }
            }
        }
        return out;
    }

    /** Several flags add commands; a value of none clears everything before it. */
    private static List<String> commands(List<String> values) {
        List<String> out = new ArrayList<>();
        for (String value : values) {
            if (isClear(value)) {
                out.clear();
            } else {
                out.add(value);
            }
        }
        return out;
    }

    private static Boolean bool(String text) {
        String value = text == null ? "" : text.trim().toLowerCase(Locale.ROOT);
        return switch (value) {
            case "", "true", "yes", "on" -> Boolean.TRUE;
            case "false", "no", "off" -> Boolean.FALSE;
            default -> null;
        };
    }
}
