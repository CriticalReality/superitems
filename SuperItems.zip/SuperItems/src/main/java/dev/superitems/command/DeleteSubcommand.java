package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.util.Text;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;

/** Deletes an item definition. Copies already given stop doing anything. */
public final class DeleteSubcommand implements Subcommand {
    private final SuperItems plugin;

    /** Creates the subcommand. */
    public DeleteSubcommand(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String name() {
        return "delete";
    }

    @Override
    public String usage() {
        return "delete <id>";
    }

    @Override
    public String description() {
        return "Delete an item (copies already given stop working)";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (args.length != 1) {
            Text.error(sender, "Usage: /superitems " + usage());
            return;
        }
        String id = args[0].toLowerCase(Locale.ROOT);
        if (!plugin.items().remove(id)) {
            Text.error(sender, "No item called '" + id + "'.");
            return;
        }
        plugin.saveItems(sender);
        Text.ok(sender, "Deleted '" + id + "'. Copies players still hold no longer run commands.");
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        return args.length <= 1 ? Subcommand.match(plugin.items().ids(), args.length == 0 ? "" : args[0]) : List.of();
    }
}
