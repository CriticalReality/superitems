package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.item.ItemDefinition;
import dev.superitems.util.Text;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;

/** Changes some settings of an existing item. */
public final class EditSubcommand implements Subcommand {
    private static final String USAGE = "edit <id> [same flags as create]. Use a value of none to clear a flag";

    private final SuperItems plugin;

    /** Creates the subcommand. */
    public EditSubcommand(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String name() {
        return "edit";
    }

    @Override
    public String usage() {
        return USAGE;
    }

    @Override
    public String description() {
        return "Change an item";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        FlagParser.Result parsed = FlagParser.parse(args);
        String problem = DefinitionEditor.syntaxProblem(parsed, USAGE);
        if (problem != null) {
            Text.error(sender, problem);
            return;
        }
        String id = parsed.positional().get(0).toLowerCase(Locale.ROOT);
        ItemDefinition definition = plugin.items().get(id);
        if (definition == null) {
            Text.error(sender, "No item called '" + id + "'. See /superitems list");
            return;
        }
        if (parsed.flags().isEmpty()) {
            Text.error(sender, "Nothing to change. Add a flag such as --name or --on_right_click.");
            return;
        }
        String error = DefinitionEditor.apply(definition, parsed);
        if (error != null) {
            Text.error(sender, error);
            return;
        }
        plugin.saveItems(sender);
        Text.ok(sender, "Updated '" + id + "'. Click commands apply to existing copies right away; "
                + "name, description, material and model only change on newly given items.");
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        if (args.length <= 1) {
            return Subcommand.match(plugin.items().ids(), args.length == 0 ? "" : args[0]);
        }
        return FlagCompleter.complete(args);
    }
}
