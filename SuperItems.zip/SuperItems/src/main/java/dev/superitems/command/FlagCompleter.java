package dev.superitems.command;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import org.bukkit.Material;

/** Tab completion for flag based arguments. */
final class FlagCompleter {
    private static final List<String> COMMAND_STARTS = List.of(
            "effect", "playsound", "particle", "title", "say", "give", "tp", "summon", "execute", "player:", "raw:");

    private FlagCompleter() {}

    /** Completes the last word: flag names after two dashes, or values for the flag right before it. */
    static List<String> complete(String[] args) {
        if (args.length == 0) {
            return List.of();
        }
        String typed = args[args.length - 1];
        if (typed.startsWith("--")) {
            List<String> flags = FlagParser.FLAGS.stream().map(flag -> "--" + flag).toList();
            return Subcommand.match(flags, typed);
        }
        if (args.length < 2) {
            return List.of();
        }
        String flag = FlagParser.canonical(args[args.length - 2]);
        if (flag == null) {
            return List.of();
        }
        return switch (flag) {
            case "material" -> Subcommand.match(itemNames(typed), typed);
            case "consume" -> Subcommand.match(List.of("none", "right", "left", "both"), typed);
            case "glow", "cancel" -> Subcommand.match(List.of("true", "false"), typed);
            case "on_right_click", "on_left_click" -> Subcommand.match(COMMAND_STARTS, typed);
            case "model" -> Subcommand.match(List.of("minecraft:", "none"), typed);
            default -> List.of();
        };
    }

    private static List<String> itemNames(String typed) {
        String lower = typed.toLowerCase(Locale.ROOT);
        return Arrays.stream(Material.values())
                .filter(material -> material.isItem() && !material.isLegacy() && !material.isAir())
                .map(material -> material.name().toLowerCase(Locale.ROOT))
                .filter(name -> name.startsWith(lower))
                .toList();
    }
}
