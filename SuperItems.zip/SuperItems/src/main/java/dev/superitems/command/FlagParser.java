package dev.superitems.command;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Splits command arguments into plain words and flags. A flag is a word starting with two dashes.
 * Everything after a flag up to the next flag is that flag's value, so values can contain spaces
 * and whole commands. A flag may be repeated.
 */
public final class FlagParser {
    private static final Map<String, String> CANONICAL = Map.ofEntries(
            Map.entry("name", "name"),
            Map.entry("description", "description"),
            Map.entry("lore", "description"),
            Map.entry("material", "material"),
            Map.entry("model", "model"),
            Map.entry("glow", "glow"),
            Map.entry("on_right_click", "on_right_click"),
            Map.entry("right", "on_right_click"),
            Map.entry("on_left_click", "on_left_click"),
            Map.entry("left", "on_left_click"),
            Map.entry("consume", "consume"),
            Map.entry("cooldown", "cooldown"),
            Map.entry("cancel", "cancel"));

    /** The flag names shown in help and tab completion. */
    public static final List<String> FLAGS = List.of(
            "name", "description", "material", "model", "glow",
            "on_right_click", "on_left_click", "consume", "cooldown", "cancel");

    private FlagParser() {}

    /** The parsed arguments. Flag values are trimmed and may be empty. */
    public record Result(List<String> positional, Map<String, List<String>> flags, List<String> unknown) {
        /** Returns true when the flag was given at least once. */
        public boolean has(String flag) {
            return flags.containsKey(flag);
        }

        /** Returns every value given for a flag, in order. */
        public List<String> all(String flag) {
            return flags.getOrDefault(flag, List.of());
        }

        /** Returns the last value given for a flag, or null. */
        public String last(String flag) {
            List<String> values = all(flag);
            return values.isEmpty() ? null : values.get(values.size() - 1);
        }
    }

    /** Returns true when the word looks like a flag such as --name. */
    public static boolean isFlagToken(String word) {
        return word.length() > 2 && word.startsWith("--") && Character.isLetter(word.charAt(2));
    }

    /** Returns the canonical flag name for a word like --on-right-click, or null when it is not a known flag. */
    public static String canonical(String word) {
        if (!isFlagToken(word)) {
            return null;
        }
        return CANONICAL.get(word.substring(2).toLowerCase(Locale.ROOT).replace('-', '_'));
    }

    /** Parses the arguments. */
    public static Result parse(String[] args) {
        List<String> positional = new ArrayList<>();
        Map<String, List<String>> flags = new LinkedHashMap<>();
        List<String> unknown = new ArrayList<>();
        List<String> words = new ArrayList<>();
        String current = null;
        for (String arg : args) {
            if (isFlagToken(arg)) {
                finish(flags, current, words);
                current = canonical(arg);
                if (current == null) {
                    unknown.add(arg);
                }
            } else if (current == null) {
                positional.add(arg);
            } else {
                words.add(arg);
            }
        }
        finish(flags, current, words);
        return new Result(positional, flags, unknown);
    }

    private static void finish(Map<String, List<String>> flags, String current, List<String> words) {
        if (current != null) {
            flags.computeIfAbsent(current, key -> new ArrayList<>()).add(String.join(" ", words).trim());
        }
        words.clear();
    }
}
