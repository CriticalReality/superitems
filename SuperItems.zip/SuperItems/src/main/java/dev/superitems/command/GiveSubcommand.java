package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.item.ItemDefinition;
import dev.superitems.util.Text;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;

/** Gives copies of an item to a player. */
public final class GiveSubcommand implements Subcommand {
    private static final int MAX_AMOUNT = 2304;

    private final SuperItems plugin;

    /** Creates the subcommand. */
    public GiveSubcommand(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String name() {
        return "give";
    }

    @Override
    public String usage() {
        return "give <id> [player] [amount]";
    }

    @Override
    public String description() {
        return "Give an item to yourself or another player";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (args.length == 0) {
            Text.error(sender, "Usage: /superitems " + usage());
            return;
        }
        String id = args[0].toLowerCase(Locale.ROOT);
        ItemDefinition definition = plugin.items().get(id);
        if (definition == null) {
            Text.error(sender, "No item called '" + id + "'. See /superitems list");
            return;
        }
        Player target;
        if (args.length >= 2) {
            target = plugin.getServer().getPlayerExact(args[1]);
            if (target == null) {
                Text.error(sender, "Player '" + args[1] + "' is not online.");
                return;
            }
        } else if (sender instanceof Player self) {
            target = self;
        } else {
            Text.error(sender, "The console must name a player: /superitems " + usage());
            return;
        }
        int amount = 1;
        if (args.length >= 3) {
            try {
                amount = Integer.parseInt(args[2]);
            } catch (NumberFormatException e) {
                Text.error(sender, "'" + args[2] + "' is not a whole number.");
                return;
            }
        }
        if (amount < 1 || amount > MAX_AMOUNT) {
            Text.error(sender, "Amount must be between 1 and " + MAX_AMOUNT + ".");
            return;
        }

        int remaining = amount;
        boolean dropped = false;
        while (remaining > 0) {
            ItemStack stack = plugin.factory().create(definition, 1);
            int size = Math.min(remaining, stack.getMaxStackSize());
            stack.setAmount(size);
            remaining -= size;
            Map<Integer, ItemStack> leftover = target.getInventory().addItem(stack);
            for (ItemStack extra : leftover.values()) {
                target.getWorld().dropItemNaturally(target.getLocation(), extra);
                dropped = true;
            }
        }
        Text.ok(sender, "Gave " + amount + "x '" + id + "' to " + target.getName()
                + (dropped ? " (inventory full, the rest was dropped)." : "."));
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        String typed = args.length == 0 ? "" : args[args.length - 1];
        return switch (args.length) {
            case 0, 1 -> Subcommand.match(plugin.items().ids(), typed);
            case 2 -> Subcommand.match(plugin.getServer().getOnlinePlayers().stream().map(Player::getName).toList(), typed);
            case 3 -> Subcommand.match(List.of("1", "16", "64"), typed);
            default -> List.of();
        };
    }
}
