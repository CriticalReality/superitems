package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.item.ItemDefinition;
import dev.superitems.util.Text;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;

/** Shows every setting of one item. */
public final class InfoSubcommand implements Subcommand {
    private final SuperItems plugin;

    /** Creates the subcommand. */
    public InfoSubcommand(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String name() {
        return "info";
    }

    @Override
    public String usage() {
        return "info <id>";
    }

    @Override
    public String description() {
        return "Show an item's settings";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (args.length != 1) {
            Text.error(sender, "Usage: /superitems " + usage());
            return;
        }
        String id = args[0].toLowerCase(Locale.ROOT);
        ItemDefinition definition = plugin.items().get(id);
        if (definition == null) {
            Text.error(sender, "No item called '" + id + "'.");
            return;
        }
        Text.ok(sender, "Item '" + id + "'");
        Text.info(sender, "name: " + definition.getName());
        Text.info(sender, "material: " + definition.getMaterial().name().toLowerCase(Locale.ROOT)
                + (definition.getModel() == null ? "" : ", model: " + definition.getModel())
                + (definition.isGlow() ? ", glowing" : ""));
        Text.info(sender, "description: " + (definition.getDescription().isEmpty() ? "(none)" : String.join(" | ", definition.getDescription())));
        Text.info(sender, "on right click: " + show(definition.getOnRightClick()));
        Text.info(sender, "on left click: " + show(definition.getOnLeftClick()));
        Text.info(sender, "consume: " + definition.getConsume().name().toLowerCase(Locale.ROOT)
                + ", cooldown: " + definition.getCooldownSeconds() + "s"
                + ", cancel click: " + definition.isCancel());
    }

    private static String show(List<String> commands) {
        return commands.isEmpty() ? "(nothing)" : String.join(" ;; ", commands);
    }

    @Override
    public List<String> complete(CommandSender sender, String[] args) {
        return args.length <= 1 ? Subcommand.match(plugin.items().ids(), args.length == 0 ? "" : args[0]) : List.of();
    }
}
