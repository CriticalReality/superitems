package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.item.ItemDefinition;
import dev.superitems.util.Text;
import org.bukkit.command.CommandSender;

/** Lists every item. */
public final class ListSubcommand implements Subcommand {
    private final SuperItems plugin;

    /** Creates the subcommand. */
    public ListSubcommand(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String name() {
        return "list";
    }

    @Override
    public String usage() {
        return "list";
    }

    @Override
    public String description() {
        return "List all items";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (plugin.items().all().isEmpty()) {
            Text.info(sender, "No items yet. Try /superitems create <id> --name Something --on_right_click say hi");
            return;
        }
        Text.ok(sender, plugin.items().all().size() + " item(s):");
        for (ItemDefinition definition : plugin.items().all()) {
            Text.info(sender, "- " + definition.getId() + " (" + definition.getMaterial().name().toLowerCase(java.util.Locale.ROOT)
                    + ", right: " + definition.getOnRightClick().size() + ", left: " + definition.getOnLeftClick().size() + ")");
        }
    }
}
