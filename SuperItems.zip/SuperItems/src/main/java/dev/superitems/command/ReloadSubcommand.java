package dev.superitems.command;

import dev.superitems.SuperItems;
import dev.superitems.util.Text;
import org.bukkit.command.CommandSender;

/** Reloads config.yml and items.yml from disk. */
public final class ReloadSubcommand implements Subcommand {
    private final SuperItems plugin;

    /** Creates the subcommand. */
    public ReloadSubcommand(SuperItems plugin) {
        this.plugin = plugin;
    }

    @Override
    public String name() {
        return "reload";
    }

    @Override
    public String usage() {
        return "reload";
    }

    @Override
    public String description() {
        return "Reload config.yml and items.yml";
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        plugin.reloadAll();
        Text.ok(sender, "Reloaded " + plugin.items().ids().size() + " item(s).");
    }
}
