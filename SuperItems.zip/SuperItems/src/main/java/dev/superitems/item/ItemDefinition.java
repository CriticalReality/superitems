package dev.superitems.item;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.Material;

/** Everything that describes one custom item. Items in inventories only carry the id and look this up when clicked. */
public final class ItemDefinition {
    private final String id;
    private String name;
    private final List<String> description = new ArrayList<>();
    private Material material;
    private String model;
    private boolean glow;
    private final List<String> onRightClick = new ArrayList<>();
    private final List<String> onLeftClick = new ArrayList<>();
    private ConsumeMode consume = ConsumeMode.NONE;
    private double cooldownSeconds;
    private boolean cancel = true;

    /** Creates a definition with default behavior. */
    public ItemDefinition(String id, String name, Material material) {
        this.id = id;
        this.name = name;
        this.material = material;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getDescription() {
        return Collections.unmodifiableList(description);
    }

    public void setDescription(List<String> lines) {
        List<String> copy = new ArrayList<>(lines);
        description.clear();
        description.addAll(copy);
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    /** Namespaced item model key such as minecraft:dead_brain_coral, or null for the default model. */
    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public boolean isGlow() {
        return glow;
    }

    public void setGlow(boolean glow) {
        this.glow = glow;
    }

    public List<String> getOnRightClick() {
        return Collections.unmodifiableList(onRightClick);
    }

    public void setOnRightClick(List<String> commands) {
        List<String> copy = new ArrayList<>(commands);
        onRightClick.clear();
        onRightClick.addAll(copy);
    }

    public List<String> getOnLeftClick() {
        return Collections.unmodifiableList(onLeftClick);
    }

    public void setOnLeftClick(List<String> commands) {
        List<String> copy = new ArrayList<>(commands);
        onLeftClick.clear();
        onLeftClick.addAll(copy);
    }

    /** Returns the commands that run for the given click. */
    public List<String> commandsFor(Click click) {
        return click == Click.RIGHT ? getOnRightClick() : getOnLeftClick();
    }

    public ConsumeMode getConsume() {
        return consume;
    }

    public void setConsume(ConsumeMode consume) {
        this.consume = consume;
    }

    public double getCooldownSeconds() {
        return cooldownSeconds;
    }

    public void setCooldownSeconds(double cooldownSeconds) {
        this.cooldownSeconds = cooldownSeconds;
    }

    /** When true, a click that runs commands is cancelled so the item does not also place, break or attack. */
    public boolean isCancel() {
        return cancel;
    }

    public void setCancel(boolean cancel) {
        this.cancel = cancel;
    }
}
