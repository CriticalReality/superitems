package dev.superitems.item;

import dev.superitems.util.Text;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

/** Builds item stacks from definitions and recognizes them again by a tag stored in the item. */
public final class ItemFactory {
    private final NamespacedKey idKey;

    /** Creates a factory whose tag is namespaced to the given plugin. */
    public ItemFactory(Plugin plugin) {
        this.idKey = new NamespacedKey(plugin, "item_id");
    }

    /** Builds a stack of the given size for a definition. */
    public ItemStack create(ItemDefinition definition, int amount) {
        ItemStack stack = new ItemStack(definition.getMaterial(), amount);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Text.parse(definition.getName()));
        if (!definition.getDescription().isEmpty()) {
            meta.lore(definition.getDescription().stream().map(Text::parse).toList());
        }
        if (definition.isGlow()) {
            meta.setEnchantmentGlintOverride(true);
        }
        if (definition.getModel() != null) {
            NamespacedKey model = NamespacedKey.fromString(definition.getModel());
            if (model != null) {
                meta.setItemModel(model);
            }
        }
        meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, definition.getId());
        stack.setItemMeta(meta);
        return stack;
    }

    /** Returns the super item id stored in the stack, or null when it is not a super item. */
    public String idOf(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return null;
        }
        return stack.getItemMeta().getPersistentDataContainer().get(idKey, PersistentDataType.STRING);
    }
}
