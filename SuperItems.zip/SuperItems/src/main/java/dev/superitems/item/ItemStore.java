package dev.superitems.item;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

/** Holds item definitions in memory and persists them to items.yml. */
public final class ItemStore {
    private final File file;
    private final Logger logger;
    private Map<String, ItemDefinition> items = new LinkedHashMap<>();

    /** Creates a store backed by the given file. Call load to read it. */
    public ItemStore(File file, Logger logger) {
        this.file = file;
        this.logger = logger;
    }

    /** Returns true when the id only uses lowercase letters, digits, underscores and dashes. */
    public static boolean isValidId(String id) {
        return id.matches("[a-z0-9_-]{1,32}");
    }

    /** Reads the file and replaces the items in memory. Broken entries are skipped with a warning. */
    public void load() {
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        Map<String, ItemDefinition> loaded = new LinkedHashMap<>();
        ConfigurationSection root = yaml.getConfigurationSection("items");
        if (root != null) {
            for (String id : root.getKeys(false)) {
                ConfigurationSection section = root.getConfigurationSection(id);
                ItemDefinition definition = section == null ? null : read(id, section);
                if (definition != null) {
                    loaded.put(id, definition);
                }
            }
        }
        items = loaded;
    }

    private ItemDefinition read(String id, ConfigurationSection section) {
        Material material = Material.matchMaterial(section.getString("material", "STICK"));
        if (material == null || !material.isItem() || material.isAir()) {
            logger.warning("Skipping item '" + id + "': unknown material '" + section.getString("material") + "'.");
            return null;
        }
        ItemDefinition definition = new ItemDefinition(id, section.getString("name", id), material);
        definition.setDescription(section.getStringList("description"));
        definition.setModel(section.getString("model"));
        definition.setGlow(section.getBoolean("glow", false));
        definition.setOnRightClick(section.getStringList("on_right_click"));
        definition.setOnLeftClick(section.getStringList("on_left_click"));
        ConsumeMode consume = ConsumeMode.parse(section.getString("consume", "none"));
        definition.setConsume(consume == null ? ConsumeMode.NONE : consume);
        definition.setCooldownSeconds(Math.max(0, section.getDouble("cooldown", 0)));
        definition.setCancel(section.getBoolean("cancel", true));
        return definition;
    }

    /** Writes every definition to the file. */
    public void save() throws IOException {
        YamlConfiguration yaml = new YamlConfiguration();
        for (ItemDefinition definition : items.values()) {
            String path = "items." + definition.getId() + ".";
            yaml.set(path + "name", definition.getName());
            yaml.set(path + "material", definition.getMaterial().name());
            if (definition.getModel() != null) {
                yaml.set(path + "model", definition.getModel());
            }
            yaml.set(path + "glow", definition.isGlow());
            yaml.set(path + "description", new ArrayList<>(definition.getDescription()));
            yaml.set(path + "on_right_click", new ArrayList<>(definition.getOnRightClick()));
            yaml.set(path + "on_left_click", new ArrayList<>(definition.getOnLeftClick()));
            yaml.set(path + "consume", definition.getConsume().name().toLowerCase(Locale.ROOT));
            yaml.set(path + "cooldown", definition.getCooldownSeconds());
            yaml.set(path + "cancel", definition.isCancel());
        }
        yaml.save(file);
    }

    public ItemDefinition get(String id) {
        return items.get(id);
    }

    public boolean contains(String id) {
        return items.containsKey(id);
    }

    public void put(ItemDefinition definition) {
        items.put(definition.getId(), definition);
    }

    public boolean remove(String id) {
        return items.remove(id) != null;
    }

    public List<String> ids() {
        return new ArrayList<>(items.keySet());
    }

    public Collection<ItemDefinition> all() {
        return List.copyOf(items.values());
    }
}
